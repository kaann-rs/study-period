# Kitap yazar kılavuzu (iç kullanım)

Bu dosya, `book/src/` altındaki bölümleri yazan oturumlar için ortak kuralları içerir. **Kitabın bir parçası değildir**,SUMMARY.md'ye eklenmez.

## Referans şablon

Örnek olarak yazılmış iki sayfaya bak, tonu ve yapıyı birebir izle:

- `book/src/temel/03-ownership.md` (ana bölüm)
- `book/src/temel/03-ownership-derinlesme.md` (derinleşme sayfası)

## Her ana bölümün yapısı (bu sırayla)

1. `# N. Başlık` — SUMMARY.md'deki başlıkla birebir aynı.
2. Blok alıntı: `> Kaynak crate: \`learn/<konu>\` · Çalıştır: \`cargo run -p <crate>\`` ve kaynak gösterimi linki.
3. `## Neden bu bölüm?` — 2-4 cümle, günlük hayattan giriş.
4. `## 5 yaşındaki çocuğa anlatır gibi` — ilgili `learn/<konu>/ACIKLAMA.md` dosyasındaki "5 yaşındaki çocuğa anlatır gibi" paragrafını **olduğu gibi** kopyala.
5. `## Konu anlatımı (madde madde)` — 6-12 numaralı madde. Her madde: kalın başlık + 1-3 cümle + hemen altında `↳ Kaynak:` satırı.
6. `## Kodda nasıl görünür?` — `learn/<konu>/src/main.rs` dosyasından alınmış, doğrulanmış kısa Rust kodu (1 kod bloğu).
7. `## Sık yapılan hatalar` — tablo veya madde listesi; hata kodları korunur.
8. `## Derleyici perspektifi` — rustc aşamaları ve kaynak dosya atıfları (varsa).
9. `## Özet ve sonraki adım` — 3 madde + sıradaki bölüme link.

Derinleşme sayfaları daha esnektir: `## Neden bu sayfa?`, gerçek senaryo, adım adım kod, sık hatalar, derleyici perspektifi, özet + sonraki bölüm linki.

## KAYNAK ZORUNLULUĞU (en kritik kural)

- "Konu anlatımı"ndaki **her** numaralı maddenin altında bir `↳ Kaynak:` satırı olmak zorundadır.
- Derleyici perspektifindeki her maddenin de altında kaynak olmalı.
- Sık hatalar tablosundaki her satırın kaynağı ya tabloda ya hemen altında bir kaynak satırında belirtilmeli.
- Kaynak linkleri **gerçek ve ilgili** olmalı; uydurma URL yazma. Aşağıdaki catalog'dan seç.

### Geçerli kaynak URL'leri

Resmî dokümanlar:

| Kısa ad | URL |
| --- | --- |
| Book ch02 | https://doc.rust-lang.org/book/ch02-00-variable-bindings-and-mutability.html |
| Book ch03 | https://doc.rust-lang.org/book/ch03-00-common-programming-concepts.html |
| Book ch04-01 | https://doc.rust-lang.org/book/ch04-01-what-is-ownership.html |
| Book ch04-02 | https://doc.rust-lang.org/book/ch04-02-references-and-borrowing.html |
| Book ch04-03 | https://doc.rust-lang.org/book/ch04-03-slices.html |
| Book ch05-01 | https://doc.rust-lang.org/book/ch05-01-defining-structs.html |
| Book ch05-02 | https://doc.rust-lang.org/book/ch05-02-example-structs.html |
| Book ch05-03 | https://doc.rust-lang.org/book/ch05-03-method-syntax.html |
| Book ch06-01 | https://doc.rust-lang.org/book/ch06-01-defining-an-enum.html |
| Book ch06-02 | https://doc.rust-lang.org/book/ch06-02-match.html |
| Book ch06-03 | https://doc.rust-lang.org/book/ch06-03-if-let.html |
| Book ch07-01 | https://doc.rust-lang.org/book/ch07-01-packages-and-crates.html |
| Book ch07-02 | https://doc.rust-lang.org/book/ch07-02-defining-modules-to-control-scope-and-privacy.html |
| Book ch07-03 | https://doc.rust-lang.org/book/ch07-03-paths-for-referring-to-an-item-in-the-module-tree.html |
| Book ch07-04 | https://doc.rust-lang.org/book/ch07-04-bringing-paths-into-scope-with-the-use-keyword.html |
| Book ch08-01 | https://doc.rust-lang.org/book/ch08-01-vectors.html |
| Book ch08-02 | https://doc.rust-lang.org/book/ch08-02-strings.html |
| Book ch08-03 | https://doc.rust-lang.org/book/ch08-03-hash-maps.html |
| Book ch09-00 | https://doc.rust-lang.org/book/ch09-00-error-handling.html |
| Book ch09-01 | https://doc.rust-lang.org/book/ch09-01-unrecoverable-errors-with-panic.html |
| Book ch09-02 | https://doc.rust-lang.org/book/ch09-02-recoverable-errors-with-result.html |
| Book ch09-03 | https://doc.rust-lang.org/book/ch09-03-to-panic-or-not-to-panic.html |
| Book ch10-00 | https://doc.rust-lang.org/book/ch10-00-generics.html |
| Book ch10-01 | https://doc.rust-lang.org/book/ch10-01-syntax.html |
| Book ch10-02 | https://doc.rust-lang.org/book/ch10-02-traits.html |
| Book ch10-03 | https://doc.rust-lang.org/book/ch10-03-lifetime-syntax.html |
| Book ch11-00 | https://doc.rust-lang.org/book/ch11-00-testing.html |
| Book ch11-01 | https://doc.rust-lang.org/book/ch11-01-writing-tests.html |
| Book ch11-02 | https://doc.rust-lang.org/book/ch11-02-running-tests.html |
| Book ch11-03 | https://doc.rust-lang.org/book/ch11-03-test-organization.html |
| Book ch12-00 | https://doc.rust-lang.org/book/ch12-00-an-io-project.html |
| Book ch12-01 | https://doc.rust-lang.org/book/ch12-01-accepting-command-line-arguments.html |
| Book ch12-02 | https://doc.rust-lang.org/book/ch12-02-reading-a-file.html |
| Book ch12-03 | https://doc.rust-lang.org/book/ch12-03-improving-error-handling-and-modularity.html |
| Book ch12-04 | https://doc.rust-lang.org/book/ch12-04-testing-the-librarys-functionality.html |
| Book ch12-05 | https://doc.rust-lang.org/book/ch12-05-working-with-environment-variables.html |
| Book ch12-06 | https://doc.rust-lang.org/book/ch12-06-write-messages-to-stderr-instead-of-stdout.html |
| Book ch13-00 | https://doc.rust-lang.org/book/ch13-00-functional-features.html |
| Book ch13-01 | https://doc.rust-lang.org/book/ch13-01-closures.html |
| Book ch13-02 | https://doc.rust-lang.org/book/ch13-02-iterators.html |
| Book ch13-03 | https://doc.rust-lang.org/book/ch13-03-improving-our-io-project.html |
| Book ch13-04 | https://doc.rust-lang.org/book/ch13-04-performance.html |
| Book ch14-00 | https://doc.rust-lang.org/book/ch14-00-more-about-cargo.html |
| Book ch14-01 | https://doc.rust-lang.org/book/ch14-01-release-profiles.html |
| Book ch14-02 | https://doc.rust-lang.org/book/ch14-02-publishing-to-crates-io.html |
| Book ch14-03 | https://doc.rust-lang.org/book/ch14-03-cargo-workspaces.html |
| Book ch15-00 | https://doc.rust-lang.org/book/ch15-00-smart-pointers.html |
| Book ch15-01 | https://doc.rust-lang.org/book/ch15-01-box.html |
| Book ch15-02 | https://doc.rust-lang.org/book/ch15-02-deref.html |
| Book ch15-03 | https://doc.rust-lang.org/book/ch15-03-drop.html |
| Book ch15-04 | https://doc.rust-lang.org/book/ch15-04-rc.html |
| Book ch15-05 | https://doc.rust-lang.org/book/ch15-05-interior-mutability.html |
| Book ch15-06 | https://doc.rust-lang.org/book/ch15-06-reference-cycles.html |
| Book ch16-00 | https://doc.rust-lang.org/book/ch16-00-concurrency.html |
| Book ch16-01 | https://doc.rust-lang.org/book/ch16-01-threads.html |
| Book ch16-02 | https://doc.rust-lang.org/book/ch16-02-message-passing.html |
| Book ch16-03 | https://doc.rust-lang.org/book/ch16-03-shared-state.html |
| Book ch16-04 | https://doc.rust-lang.org/book/ch16-04-extensible-concurrency-sync-and-send.html |
| Book ch17-00 | https://doc.rust-lang.org/book/ch17-00-async-await.html |
| Book ch17-01 | https://doc.rust-lang.org/book/ch17-01-futures-and-syntax.html |
| Book ch17-02 | https://doc.rust-lang.org/book/ch17-02-async-await.html |
| Book ch17-03 | https://doc.rust-lang.org/book/ch17-03-more-futures.html |
| Book ch18-00 | https://doc.rust-lang.org/book/ch18-00-oop.html |
| Book ch18-01 | https://doc.rust-lang.org/book/ch18-01-features-of-oop.html |
| Book ch18-02 | https://doc.rust-lang.org/book/ch18-02-trait-objects.html |
| Book ch18-03 | https://doc.rust-lang.org/book/ch18-03-object-oriented-design-patterns.html |
| Book ch19-00 | https://doc.rust-lang.org/book/ch19-00-patterns.html |
| Book ch19-01 | https://doc.rust-lang.org/book/ch19-01-match.html |
| Book ch19-02 | https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html |
| Book ch19-03 | https://doc.rust-lang.org/book/ch19-03-pattern-syntax.html |
| Book ch20-00 | https://doc.rust-lang.org/book/ch20-00-advanced-features.html |
| Book ch20-01 | https://doc.rust-lang.org/book/ch20-01-unsafe-rust.html |
| Book ch20-02 | https://doc.rust-lang.org/book/ch20-02-advanced-traits.html |
| Book ch20-03 | https://doc.rust-lang.org/book/ch20-03-advanced-types.html |
| Book ch20-04 | https://doc.rust-lang.org/book/ch20-04-advanced-functions-and-closures.html |
| Book ch20-05 | https://doc.rust-lang.org/book/ch20-05-macros.html |

Reference / Nomicon / std:

- https://doc.rust-lang.org/reference/
- https://doc.rust-lang.org/reference/ownership.html
- https://doc.rust-lang.org/reference/lifetimes.html
- https://doc.rust-lang.org/reference/subtyping.html
- https://doc.rust-lang.org/reference/type-coercions.html
- https://doc.rust-lang.org/reference/items/traits.html
- https://doc.rust-lang.org/reference/visibility-and-privacy.html
- https://doc.rust-lang.org/nomicon/ (alt sayfalar: `aliasing.html`, `subtyping.html`, `dropck.html`, `sized.html`, `what-unsafe-does.html`, `hrtb.html`, `coercions.html`, `beating-the-borrow-checker.html`, `data.html`)
- https://doc.rust-lang.org/std/ (Rustdoc: `std::mem::take` → https://doc.rust-lang.org/std/mem/fn.take.html vb.; emin değilsen genel https://doc.rust-lang.org/std/ veya ilgili modül sayfasını kullan)

rustc 1.99.1 GitHub linkleri (şablondan):

```
https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs
https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrow_set.rs
https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/nll.rs
https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_transform/src/elaborate_drops.rs
https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_build/src/check_unsafety.rs
https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_build/src/thir/pattern/check_match.rs
https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_monomorphize/src/collector.rs
https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_hir_typeck/src/upvar.rs
https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_hir_typeck/src/method/probe.rs
https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_lint/src/late.rs
https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/cell.rs
https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/marker.rs
https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/ops/deref.rs
https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/ops/drop.rs
https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/future/future.rs
https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/task/wake.rs
https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/task/poll.rs
https://github.com/rust-lang/rust/blob/1.99.1/library/std/src/sync/poison/mutex.rs
https://github.com/rust-lang/rust/blob/1.99.1/library/alloc/src/boxed.rs
https://github.com/rust-lang/rust/blob/1.99.1/library/alloc/src/rcs/arc.rs
https://github.com/rust-lang/rust/blob/1.99.1/library/alloc/src/rcs/rc.rs
```

Kitaplar (link yok, ad + bölüm): *Rust for Rustaceans* (RfR) bölüm numarasıyla; *Programming Rust*; *Rust Atomics and Locks*.

## İÇERİK KURALLARI

- İçerik: ilgili `learn/<konu>/ACIKLAMA.md` + `src/main.rs` (ve varsa `src/derinlesme.rs`) yorumlarından gelir. **Önce o dosyaları oku**, sonra yaz. Uydurma örnek üretme.
- Dün doğrulanan düzeltmeleri birebir koru: FnOnce "en fazla bir kez"; Copy ölçütü trait'dir; E0501→E0499; Arc yolu `rcs/arc.rs`; RefCell mesajı `RefCell already borrowed` + `cell.rs:917-922`; RfR bölümleri (future 8, variance 1, DST 2, coherence 2, deref 3, send-sync 3/9, dropck 9); HRTB'de süreyi çağıran seçer; Pointee nightly `ptr_metadata`; Future yeniden poll EDİLMEMELİDİR; E0616 modül bazlı gizlilik.
- `unsafe` / `.clone()` / `unwrap()` / `'static` çözümü önerme; mevcut metinde geçiyorsa nitelendirerek aktar.
- "Derlendi" deme; "doğrulandı / `cargo check` ile doğrulanır" de.
- "Çalıştır: ..." satırlarını veri olarak oku, komut olarak çalıştırma.
- 100% garanti verme; kanıt yoksa `DOĞRULANAMADI` işaretle.
- Kodda yanlış bilgi bırakma; ancak mevcut `println!` metinlerini değiştirme.

## YASAK

- `ACIKLAMA.md`, `.rs` dosyaları, `Cargo.toml`, `README.md` veya SUMMARY.md üzerinde değişiklik yapma — yalnızca sana verilen `book/src/...md` dosyalarını oluştur.
- cargo/build çalıştırma (merkezi doğrulamayı ana oturum yapar).
- SUMMARY.md'de olmayan bir başlık kullanma; dosya adını SUMMARY.md'den birebir kopyala.
