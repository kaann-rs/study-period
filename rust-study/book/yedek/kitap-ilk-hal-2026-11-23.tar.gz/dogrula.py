#!/usr/bin/env python3
"""Kitap doğrulama: SUMMARY↔dosya, kaynak satırları, HTML etiketi uyarıları."""
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"
summary = (SRC / "SUMMARY.md").read_text()

# SUMMARY'deki tüm .md yolları
linked = set(re.findall(r"\]\(([^)]+\.md)\)", summary))
missing = sorted(p for p in linked if not (SRC / p).exists())
print(f"SUMMARY linki: {len(linked)} | Eksik dosya: {missing or 'YOK'}")

# SUMMARY'de olmayan .md dosyaları (YAZAR-KILAVUZU hariç, SUMMARY'nin kendisi hariç)
actual = {str(p.relative_to(SRC)) for p in SRC.rglob("*.md")}
extra = sorted(actual - linked - {"SUMMARY.md"})
print(f"src altındaki .md: {len(actual)} | SUMMARY'de olmayan: {extra or 'YOK'}")

# Her maddede kaynak satırı var mı?
no_source = []
source_count = 0
for p in sorted(SRC.rglob("*.md")):
    if p.name in {"SUMMARY.md", "index.md", "giris.md", "kaynaklar.md"}:
        continue
    lines = p.read_text().splitlines()
    in_section = False
    for i, line in enumerate(lines):
        if line.startswith("## Konu anlatımı"):
            in_section = True
            continue
        if in_section and line.startswith("## "):
            in_section = False
        if in_section and re.match(r"^\d+\. ", line):
            # madde devamı + kaynak satırı ara (boş satırlara izin ver)
            j = i + 1
            block = []
            while j < len(lines) and not re.match(r"^\d+\. ", lines[j]) and not lines[j].startswith("## "):
                block.append(lines[j])
                j += 1
            if not any("↳ Kaynak:" in b for b in block):
                no_source.append(f"{p.relative_to(SRC)}:{i+1}  {line[:75]}")
    source_count += sum(1 for l in lines if "↳ Kaynak:" in l)
print(f"Kaynak satırı toplam: {source_count}")
print("Kaynaksız madde:")
for x in no_source:
    print("  ", x)
if not no_source:
    print("   YOK")

# Başlık SUMMARY ile eşleşiyor mu?
mismatch = []
for label, path in re.findall(r"\[([^\]]+)\]\(([^)]+\.md)\)", summary):
    f = SRC / path
    if not f.exists():
        continue
    first = next((l for l in f.read_text().splitlines() if l.startswith("# ")), "")
    if first != "# " + label:
        mismatch.append(f"{path}: '{first}' != '# {label}'")
print("Başlık uyuşmazlığı:")
for x in mismatch:
    print("  ", x)
if not mismatch:
    print("   YOK")

# Backtick içinde olmayan <T> benzeri ifadeler (HTML etiketi sanılır)
html_warn = []
for p in sorted(SRC.rglob("*.md")):
    for n, line in enumerate(p.read_text().splitlines(), 1):
        stripped = re.sub(r"`[^`]*`", "", line)  # backtick'leri çıkar
        for m in re.finditer(r"<([A-Za-z][A-Za-z0-9_]*)>", stripped):
            html_warn.append(f"{p.relative_to(SRC)}:{n}  <{m.group(1)}>  {line.strip()[:80]}")
print("Backtick'siz <T> (HTML uyarısı):")
for x in html_warn[:30]:
    print("  ", x)
if len(html_warn) > 30:
    print(f"   ... ve {len(html_warn)-30} satır daha")
if not html_warn:
    print("   YOK")

# Boş dosya / çok kısa dosya
short = [(str(p.relative_to(SRC)), len(p.read_text().splitlines()))
         for p in sorted(SRC.rglob("*.md")) if len(p.read_text().splitlines()) < 25]
print("25 satırdan kısa dosyalar:", short or "YOK")
