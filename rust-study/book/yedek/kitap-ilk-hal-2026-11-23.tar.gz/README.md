# Rust Yolculuğu — mdBook kaynakları

Bu dizin, `learn/` çalışmalarının kitap biçimine dönüştürülmüş hâlidir.

## Yapı

```
book/
├── book.toml          # mdBook yapılandırması
├── YAZAR-KILAVUZU.md  # iç kullanım: yazım ve kaynak kuralları
└── src/
    ├── SUMMARY.md     # kitap haritası (bölüm sırası)
    ├── index.md       # önsöz
    ├── giris.md       # nasıl kullanılır
    ├── kaynaklar.md   # kaynak gösterimi ve kısaltmalar
    ├── temel/         # 1–8. bölümler (+ derinleşme)
    ├── orta/          # 9–20. bölümler (+ derinleşme)
    └── ileri/         # 21–29. bölümler
```

## Derleme

mdBook kuruluysa:

```bash
cd book
mdbook build
```

Çıktı `book/book/` altına HTML olarak yazılır. Yerel önizleme için:

```bash
mdbook serve --open
```

mdBook kurulu değilse:

```bash
cargo install mdbook --locked
```

## Kaynak gösterimi

Anlatımdaki her maddenin altında `↳ Kaynak:` satırı vardır. Kısaltmalar ve URL kataloğu [`src/kaynaklar.md`](src/kaynaklar.md) ve [`YAZAR-KILAVUZU.md`](YAZAR-KILAVUZU.md) dosyalarındadır.

Derleyici kaynak linkleri **rustc 1.99.1** etiketini kullanır (yerel `guide/rust/` ağacıyla aynı sürüm).
