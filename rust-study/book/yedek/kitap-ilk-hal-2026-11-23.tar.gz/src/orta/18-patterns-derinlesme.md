# 18.1 Desenler: Derinleşme

> Kaynak dosya: `learn/patterns/src/derinlesme.rs` · Test: `cargo test -p patterns`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

Önceki sayfada desenin ne olduğunu ve hangi araçları içerdiğini gördük. Bu sayfada aynı araçlar bir araya gelir: kullanıcının yazdığı komutu ayıran küçük bir envanter programı, bağlama modları, dilim desenleri ve bütünlük denetiminin refactoring'teki rolü.

## Neden bu sayfa?

Bir komut satırını işlemek aslında şu sorulardır: kaç parça var, ilki ne, gerisi ne? Bunu `len()` ve indekslerle yazarsan bir satırı güncelleyip diğerini unutmak kolaydır; sonuç çalışma anında "index out of bounds" paniği olur. Dilim deseni uzunluk testiyle erişimi tek ifadede birleştirir, eksik durumları da derleyici gösterir.

## Gerçek senaryo: komut ayrıştırıcı

`ayristir` fonksiyonu boş satır, `listele`, `sil <ad>`, `ekle <ad> [adet]`, `not <metin>`, yanlış argüman ve bilinmeyen komut durumlarını ayırır. Özel biçimler yukarıda, genel yakalayıcılar aşağıdadır.

```rust
fn ayristir(satir: &str) -> Result<Komut, AyristirmaHatasi> {
    let parcalar: Vec<&str> = satir.split_whitespace().collect();
    match parcalar.as_slice() {
        [] => Err(AyristirmaHatasi::Bos),
        ["listele"] => Ok(Komut::Listele),
        ["sil", ad] => Ok(Komut::Sil { ad: ad.to_string() }),
        ["ekle", ad, adet] => {
            let Ok(adet @ 1..) = adet.parse::<u32>() else {
                return Err(AyristirmaHatasi::GecersizAdet(adet.to_string()));
            };
            Ok(Komut::Ekle { ad: ad.to_string(), adet })
        }
        ["not", ilk, kalan @ ..] => {
            let mut metin = ilk.to_string();
            for kelime in kalan {
                metin.push(' ');
                metin.push_str(kelime);
            }
            Ok(Komut::Not(metin))
        }
        [
            komut @ ("ekle" | "sil" | "listele" | "not"),
            argumanlar @ ..,
        ] => Err(AyristirmaHatasi::YanlisArguman {
            komut: komut.to_string(),
            verilen: argumanlar.len(),
        }),
        [bilinmeyen, ..] => Err(AyristirmaHatasi::Bilinmeyen(bilinmeyen.to_string())),
    }
}
```

1. Dilim deseni `Vec`'e değil, `as_slice()` ile alınan dilime uygulanır; `["ekle", ad]` hem uzunluğu (2) hem ilk elemanı test edip ikinciyi bağlar.
   ↳ Kaynak: [Book ch19-02 — Pattern Syntax](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html) · [Rustdoc — slice](https://doc.rust-lang.org/std/primitive.slice.html)

2. `kalan @ ..` geri kalan elemanları alt dilim olarak bağlar (boş da olabilir); `komut @ ("ekle" | "sil" | ...)` alternatiflerden biri tuttuysa hangisinin olduğunu saklar. String literal'larını derleyici göremez, bu yüzden `komut` listesini güncellemek bütünlük denetiminin kapsamı dışındadır.
   ↳ Kaynak: [Book ch19-02 — @ Bindings](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html) · [Book ch19-01 — Match](https://doc.rust-lang.org/book/ch19-01-match.html)

3. `let Ok(adet @ 1..) = adet.parse::<u32>() else { return Err(..) };` içinde sayı değilse hata kolu kontrolü devralır; tutarsa `adet` girinti almadan devam eder.
   ↳ Kaynak: [Book ch19-02 — Refutability](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html) · [Book ch19-03 — if let](https://doc.rust-lang.org/book/ch19-03-pattern-syntax.html)

## Bağlama modları: desen sahipliği nasıl etkiler?

Bir paketi açtığında içindekileri ya *alırsın* ya da onlara yalnız *bakarsın*. Desendeki her isim üç biçimden biriyle bağlanır: varsayılan `move` (tür `Copy` ise kopya), açık `ref` ve `ref mut`.

```rust
let mut kayit = Kayit { ad: String::from("vida"), adet: 10 };

let Kayit { ad, adet } = &kayit;      // ad: &String, adet: &u32; kayit yerinde
let Kayit { ref ad, adet } = kayit;  // ad ödünç, adet (u32) kopya

let Kayit { adet, .. } = &mut kayit; // adet: &mut u32, asıl alanı gösterir
*adet += 5;

let secili: &Option<String> = &Some(String::from("somun"));
match secili {
    Some(s) => println!("seçili: {s} ({} bayt)", s.len()), // s: &String
    None => println!("seçim yok"),
}
```

1. Değerin kendisi üzerinde eşleştirirsen parçalar dışarı taşınır; `&` üzerinde eşleştirirsen alt bağlamalar kendiliğinden ödünç gelir ve kayıt yerinde kalır. Buna *match ergonomics* denir; günlük kodda `ref` yazmak nadiren gerekir.
   ↳ Kaynak: [Reference](https://doc.rust-lang.org/reference/) · [Book ch19-02 — Pattern Syntax](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html)

2. Alanları farklı modlarla bağlamak gerektiğinde açık `ref` / `ref mut` yazılır; `&mut` üzerinde eşleşince `adet: &mut u32` olur ve `*adet += 5` asıl alanı değiştirir. Kopya üzerinde değişiklik yapmak ise asıl kaydı etkilemez.
   ↳ Kaynak: [Reference](https://doc.rust-lang.org/reference/) · [Book ch04-02 — References and Borrowing](https://doc.rust-lang.org/book/ch04-02-references-and-borrowing.html)

3. `&Some(s)` gibi referans desenini elle yazıp içini taşımak **E0507** verir: ödünç alınmış şeyin içi taşınamaz. Kaynak kod `&`'i yazmaz, ergonomics'in `s`'yi `&String` yapmasına bırakır; böylece yalnızca bakılır.
   ↳ Kaynak: [Book ch19-02 — Pattern Syntax](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html) · [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs)

## İç içe yapı çözme, `@` ve guard birlikte

`yorumla` fonksiyonu olayları üç katmanda açar: enum varyantı → struct alanları → literal veya aralık. En özel kol en üsttedir.

1. `karakter: harf @ ('a'..='z' | 'A'..='Z')` içinde parantez gerekir; parantez olmasaydı `@` yalnız ilk alternatife ait olur ve derleyici **E0408** ile reddederdi.
   ↳ Kaynak: [Book ch19-02 — @ Bindings](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html) · [Reference](https://doc.rust-lang.org/reference/)

2. `konum: nokta @ Nokta { x, y }` yanındaki `if x == y` guard'ı iki bağlamayı karşılaştırır; desenin kendisi değerleri sabitlerle karşılaştırır, bağlamaları birbiriyle değil.
   ↳ Kaynak: [Book ch19-02 — Match Guards](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html) · [Book ch19-01 — Match](https://doc.rust-lang.org/book/ch19-01-match.html)

3. Guard yerine aralık yazmak (`..=-1`, `0`, `1..`) üç kolun tüm `i32`'leri kapsadığını derleyiciye kanıtlar. `unsigned_abs`, `abs()`'in `i32::MIN` için taşması yerine mutlak değeri işaretsiz sayı olarak verir.
   ↳ Kaynak: [Rustdoc — i32::unsigned_abs](https://doc.rust-lang.org/std/primitive.i32.html#method.unsigned_abs) · [Book ch19-02 — Matching Ranges with ..=](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html)

4. Guard `|` zincirinin tamamına uygulanır: `1 | 2 if izinli` ifadesi `(1 | 2) if izinli` demektir, `1 | (2 if izinli)` değil.
   ↳ Kaynak: [Reference](https://doc.rust-lang.org/reference/) · [Book ch19-02 — Match Guards](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html)

## Dilim desenleri

```rust
fn ozetle(sayilar: &[i32]) -> String {
    match sayilar {
        [] => String::from("boş"),
        [tek] => format!("tek eleman: {tek}"),
        [ilk, son] => format!("iki eleman: {ilk} ve {son}"),
        [ilk, orta @ .., son] => format!("{ilk} … {son} (arada {} eleman)", orta.len()),
    }
}
```

1. Boş dilim de bir dilimdir; `[]` kolu yazılmazsa **E0004** gelir. Aynı dilim desende `..` yalnız bir kez geçebilir; iki tane olsaydı nerede bölüneceği belirsiz kalırdı.
   ↳ Kaynak: [Book ch19-02 — Pattern Syntax](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html) · [Book ch19-01 — Match](https://doc.rust-lang.org/book/ch19-01-match.html)

2. `[u8; 3]` için `[r, g, b]` reddedilemez bir desendir ve düz `let` ile kullanılır; dilimde aynı desen reddedilebilirdir (uzunluk 3 olmayabilir), bu yüzden `let ... else` gerekir.
   ↳ Kaynak: [Book ch19-02 — Refutability](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html) · [Reference](https://doc.rust-lang.org/reference/)

3. `match v` bir `Vec` üzerinde **E0529** verir; `v.as_slice()` veya `&v[..]` gerekir. `let [r, g] = renk;` ise 3 elemanlı dizi için **E0527**'dir; `[r, g, _]` ya da `[r, g, ..]` yazılır.
   ↳ Kaynak: [Rustdoc — Vec](https://doc.rust-lang.org/std/vec/struct.Vec.html) · [Rustdoc — slice](https://doc.rust-lang.org/std/primitive.slice.html)

## Bütünlük, `matches!` ve refactoring

1. `uygula()` içindeki `match komut` dört varyantı da adıyla sayar; `Komut`'a yeni bir varyant eklenince **E0004** gelir ve derleyicinin hata listesi güncellenmesi gereken yerleri gösterir. `_ =>` kolu olsaydı yeni komut sessizce oraya düşerdi: kendi enum'unda `_` yazmak bu korumadan vazgeçmektir.
   ↳ Kaynak: [Book ch19-01 — Match](https://doc.rust-lang.org/book/ch19-01-match.html) · [rustc 1.99.1 — check_match.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_build/src/thir/pattern/check_match.rs)

2. `matches!(değer, desen)` yalnız "tutuyor mu?" sorusunun evet/hayır cevabını verir ve guard da alır; `filter`, `any` gibi `bool` bekleyen yerlerde kullanılır. Makro içeride `_ => false` kolu olan bir `match`'e açıldığı için bütünlük korumasından bilerek vazgeçilmiş olur.
   ↳ Kaynak: [Rustdoc — matches!](https://doc.rust-lang.org/std/macro.matches.html) · [Book ch19-02 — Pattern Syntax](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html)

3. Closure parametresi de bir desendir: `.map(|(ad, adet)| Kayit { .. })` tuple'ı açar. Ayrıca `let Some(Kayit { ad, adet: adet @ 1.. }) = envanter.first() else { .. };` iç içe deseni tek satırda kullanır.
   ↳ Kaynak: [Book ch13-01 — Closures](https://doc.rust-lang.org/book/ch13-01-closures.html) · [Book ch19-02 — Pattern Syntax](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html)

## Sık yapılan hatalar

1. **Bakmak isterken taşımak (`E0382`).** `let Kayit { ad, adet } = kayit;` içinde `ad` dışarı taşınır; kaydı bütün olarak yazmak artık mümkün olmaz. Referans üzerinde eşleştirmek parçaları ödünç bırakır.
   ↳ Kaynak: [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs) · [Book ch19-02 — Pattern Syntax](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html)

2. **Kopyayı değiştirmeye çalışmak (`E0384`).** `Kayit { adet, .. }` ile bağlanan `adet`, asıl alanın kopyasıdır; `mut adet` yazılsa bile kayıt değişmez. `&mut` üzerinde eşleştirmek asıl alana işaret eder.
   ↳ Kaynak: [Book ch03 — Variable Bindings and Mutability](https://doc.rust-lang.org/book/ch03-00-common-programming-concepts.html) · [Reference](https://doc.rust-lang.org/reference/)

3. **Referansın ardındaki değeri almak (`E0507`).** `&Some(s)` deseni "referansı aç, sonra `s`'yi taşı" der; ödünç alınmış şeyin içi taşınamaz. Kaynak kod `&`'i yazmaz ve alt bağlamanın `&String` olmasına bırakır.
   ↳ Kaynak: [Book ch04-02 — References and Borrowing](https://doc.rust-lang.org/book/ch04-02-references-and-borrowing.html) · [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs)

4. **Alternatiflerde eksik bağlama veya `@` önceliği (`E0408`).** `Komut::Ekle { ad, .. } | Komut::Listele` içinde `ad` her alternatifte bağlı değildir; `harf @ 'a'..='z' | 'A'..='Z'` içinde ise `@` yalnız ilk alternatife bağlanır. Kolları ayırmak ya da alternatifleri parantezlemek gerekir.
   ↳ Kaynak: [Book ch19-02 — Pattern Syntax](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html) · [Reference](https://doc.rust-lang.org/reference/)

5. **Guard'larla bütünlük sağlamaya çalışmak (`E0004`).** `x if x < 0` ve `x if x >= 0` birlikte tüm sayıları kapsıyor gibi görünür; derleyici guard'ın içine bakmadığı için son kolu guardsız bırakmak veya aralık yazmak gerekir.
   ↳ Kaynak: [Book ch19-02 — Match Guards](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html) · [rustc 1.99.1 — check_match.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_build/src/thir/pattern/check_match.rs)

6. **Vec'i doğrudan desenle eşleştirmek (`E0529`).** Dilim deseni dizi/dilim üzerinde çalışır; `match v` yerine `match v.as_slice()` kullanılır.
   ↳ Kaynak: [Rustdoc — Vec](https://doc.rust-lang.org/std/vec/struct.Vec.html) · [Rustdoc — slice](https://doc.rust-lang.org/std/primitive.slice.html)

7. **Dizi uzunluğunu yanlış yazmak (`E0527`).** 3 elemanlı dizi için iki gözlu desen istenmez; `[r, g, _]` ya da `[r, g, ..]` kullanılır.
   ↳ Kaynak: [Book ch19-02 — Pattern Syntax](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html) · [Reference](https://doc.rust-lang.org/reference/)

## Derleyici perspektifi

- **Match ergonomics derleyici tarafından uygulanır.** Eşleştirilen değer bir referans, desen ise referans deseni değilse derleyici referansın içine iner ve alt bağlamaları otomatik `ref` / `ref mut` yapar.
  ↳ Kaynak: [Reference](https://doc.rust-lang.org/reference/) · [Book ch19-02 — Pattern Syntax](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html)

- **Bütünlük ve faydalılık analizi `check_match.rs` içinde yapılır.** Durumları kapsamayan kollar **E0004**, erişilemez kollar "unreachable pattern" uyarısı üretir; `_` ve `..` bu analizde "geri kalan her şey" anlamına gelir.
  ↳ Kaynak: [rustc 1.99.1 — check_match.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_build/src/thir/pattern/check_match.rs) · [rustc 1.99.1 — late.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_lint/src/late.rs)

- **Reddedilebilirlik aynı analiz ailesindendir.** `check_binding_is_irrefutable` (~657. satır) yerel bağlamaya konan desenin her değere uyup uymadığını denetler; uymuyorsa **E0005** ve `let-else` önerisi gelir.
  ↳ Kaynak: [rustc 1.99.1 — check_match.rs:657](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_build/src/thir/pattern/check_match.rs#L657) · [Book ch19-02 — Refutability](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html)

## Özet ve sonraki adım

- Dilim desenleri uzunluk ve içerik testini tek ifadede birleştirir; boş dilim dahil tüm durumları kapsamak gerekir.
- Bağlama modları sahipliği belirler: `&` üzerinde eşleşmek ödünç verir, `&mut` değiştirme hakkı verir, değerin kendisi üzerinde eşleşmek taşır.
- `matches!` ve `_` kolları pratik olsa da bütünlük denetiminin korumasını zayıflatır; varyantları adıyla saymak refactoring'i güvenli kılar.

Sıradaki bölüm: [19. Gelişmiş Özellikler](19-advanced-features.md).
