# 12.1 Closure ve Iterator'lar: Derinleşme

> Kaynak dosya: `learn/closures-iterators/src/derinlesme.rs` · Test: `cargo test -p closures-iterators`

Önceki sayfada üç yakalama biçimini, `Fn`/`FnMut`/`FnOnce` ayrımını ve `map`/`filter`/`collect`'i tek tek görmüştük. Bu sayfada aynı araçları gerçek bir **sipariş veri hattında** birlikte kullanıyoruz: satırları okuyor, bozuk olanları eliyor, süzüyor, grupluyor ve en sık çıkan beş borrow hatasının deyimsel çözümünü yazıyoruz.

## Neden bu sayfa?

Küçük bir closure yazmak kolaydır; zor olan onu bir API'den geçirip geri döndürmek, farklı durumlarda farklı closure üretmek ve zinciri tüketmeden yan etki beklemektir. Buradaki kural kâğıtları ve taşıma bandı benzetmesi aynen sürer: notun kaç kez uygulanabileceğini gövdesi belirler, bandın çalışması için birinin "sıradaki" demesi gerekir.

## Gövde trait'i belirler, `move` yalnız yakalama biçimini

İki ayrı soru vardır ve sık karıştırılır: (1) Değişken closure'a nasıl girer — `&`, `&mut` ya da değer (`move` bunu "değer"e zorlar)? (2) Gövde yakaladığıyla ne yapar — okur, değiştirir mi, dışarı mı taşır? Trait'i yalnızca ikinci soru belirler.

| Gövde | Yakalama | Trait | Kaç kez çağrılır? |
| --- | --- | --- | --- |
| `move \|\| ad.chars().count()` | değer (`move`), yalnız okuma | `Fn` | istediğin kadar |
| `\|\| { sayac += 1; sayac }` | `&mut` | `FnMut` | birden çok, özel erişimle |
| `\|\| not` (move'suz bile) | değer dışarı veriliyor | `FnOnce` | **en fazla bir kez** |

1. `move` yazmak closure'ı tek kullanımlık yapmaz: kataloğu çantana koyup her gün açıp okuyabilirsin. Kataloğü müşteriye verirsen, çantada taşımış olsan da olmasan da ikinci kez veremezsin.
   ↳ Kaynak: [Rustdoc — FnOnce](https://doc.rust-lang.org/std/ops/trait.FnOnce.html) · [rustc 1.99.1 — upvar.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_hir_typeck/src/upvar.rs)

2. Kapalı bir kutuya `&` ile bakarsan içini değiştiremezsin; `&mut` ile bakarsan başkası aynı anda bakamaz. Yakalama biçimi bu üç durumdan biridir; `move` yalnızca üçüncüsüne zorlar.
   ↳ Kaynak: [Book ch13-01 — Capturing the Environment](https://doc.rust-lang.org/book/ch13-01-closures.html) · [rustc 1.99.1 — upvar.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_hir_typeck/src/upvar.rs)

3. Parametre alırken işi gören **en gevşek** trait'i iste: `FnOnce` > `FnMut` > `Fn`. Böylece daha güçlü bir yetki isteyen closure da kabul edilir; API gereksiz kısıt dayatmaz.
   ↳ Kaynak: [Rustdoc — FnMut](https://doc.rust-lang.org/std/ops/trait.FnMut.html) · [Book ch13-01 — Closures as Parameters](https://doc.rust-lang.org/book/ch13-01-closures.html)

```rust
// learn/closures-iterators/src/derinlesme.rs — özet
fn iki_kez_cagir(f: impl Fn() -> usize) -> usize { f() + f() }
fn uc_kez_cagir(mut f: impl FnMut() -> u32) -> u32 { f(); f(); f() }
fn bir_kez_cagir(f: impl FnOnce() -> String) -> String { f() }

fn govde_traiti_belirler() {
    println!("-- 1. gövde trait'i belirler --");
    let ad = String::from("Ayşe");
    // move VAR ama gövde yalnız okuyor → Fn. `ad` closure'ın içine taşındı, orada yaşıyor.
    let uzunluk = move || ad.chars().count();
    println!("move + okuma  → Fn     : {}", iki_kez_cagir(uzunluk));

    let mut sayac = 0;
    // Gövde değiştiriyor → FnMut. (Fn bekleyen iki_kez_cagir'a verilemez: bkz. §7-b.)
    let artir = || { sayac += 1; sayac };
    println!("değiştirme    → FnMut  : {}", uc_kez_cagir(artir));

    let not = String::from("teslim edildi");
    // move YOK ama gövde `not`'u DÖNDÜRÜYOR (dışarı taşıyor) → yalnız FnOnce.
    let ver = || not;
    println!("dışarı taşıma → FnOnce : {}", bir_kez_cagir(ver));
}
```

## Gerçek senaryo: sipariş veri hattı

Banttan ham kayıtlar akar; her istasyon tek bir küçük iş yapar. `filter_map` bozuk satırları dönüştürüp atar, `fold` tek geçişte iki sonuç üretir, `partition` iki sepeti doldurur, `flat_map` her öğeden birkaç eleman çıkarır.

1. `satirdan` bir satırı `Option<Siparis>` yapar; eksik alan ya da sayı olmayan değer `None` döner. `ham.lines().filter_map(satirdan).collect()` ile bozuk satır sessizce elenir; 7 satırdan 6 sipariş okunur.
   ↳ Kaynak: [Rustdoc — Iterator::filter_map](https://doc.rust-lang.org/std/iter/trait.Iterator.html#method.filter_map) · [Book ch13-02 — Iterators](https://doc.rust-lang.org/book/ch13-02-iterators.html)

2. `fold((0, 0), |(a, t), s| (a + 1, t + s.tutar))` elde bir pusula tutar; `sum`/`count`/`max` bu desenin özel hâlidir. Boş listede `/` yerine `checked_div(...).unwrap_or(0)` kullanılır; sıfıra bölme paniği olmaz.
   ↳ Kaynak: [Rustdoc — Iterator::fold](https://doc.rust-lang.org/std/iter/trait.Iterator.html#method.fold) · [Rustdoc — u32::checked_div](https://doc.rust-lang.org/std/primitive.u32.html#method.checked_div)

3. `HashMap::entry(sehir).or_insert(0)` ile şehir kutuları açılır. `HashMap` gezinme sırası **rastgeledir**; gösterilecek veya sınanacak sonucu `sort_by_key` ile sıralamak gerekir.
   ↳ Kaynak: [Rustdoc — HashMap::entry](https://doc.rust-lang.org/std/collections/struct.HashMap.html#method.entry) · [Book ch08-03 — Hash Maps](https://doc.rust-lang.org/book/ch08-03-hash-maps.html)

4. `f64` `Ord` uygulamaz (NaN yüzünden), bu yüzden `max()` yoktur; `max_by(|a, b| a.total_cmp(b))` ile sırayı sen verirsin. BTreeSet'e `collect` ise tekil ve sıralı harfler üretir.
   ↳ Kaynak: [Rustdoc — f64::total_cmp](https://doc.rust-lang.org/std/primitive.f64.html#method.total_cmp) · [Rustdoc — BTreeSet](https://doc.rust-lang.org/std/collections/struct.BTreeSet.html)

5. `enumerate` sıra numarası ekler, `zip` iki akışı eşler ve **kısa olan bitince durur**, `take_while` şart ilk bozulduğunda bırakır, `windows(2)` örtüşen komşu çiftleri, `chunks(4)` örtüşmeyen parçaları verir. `peekable` + `next_if_eq`, ardışık gruplama yaparken sınırındaki öğeyi kaybetmeyi önler.
   ↳ Kaynak: [Rustdoc — Iterator](https://doc.rust-lang.org/std/iter/trait.Iterator.html) · [Rustdoc — Peekable](https://doc.rust-lang.org/std/iter/struct.Peekable.html)

## Closure döndürmek ve saklamak

1. `fn en_az(esik: u32) -> impl Fn(&Siparis) -> bool { move |s| s.tutar >= esik }` — `impl Fn` tek bir somut closure türü döner; tahsis yok, çağrı statik dispatch. `move` şart: `esik` bu fonksiyonun yereli, closure ondan uzun yaşar.
   ↳ Kaynak: [Book ch13-01 — Returning Closures](https://doc.rust-lang.org/book/ch13-01-closures.html) · [rustc 1.99.1 — upvar.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_hir_typeck/src/upvar.rs)

2. Duruma göre farklı closure döndüren kollar `impl Fn` olmaz: "no two closures, even if identical, have the same type" (**E0308**). Çözüm tür silmedir: `Box<dyn Fn>` — heap tahsisi + vtable dolaylaması karşılığında hepsi aynı türe girer.
   ↳ Kaynak: [Book ch18-02 — Trait Objects](https://doc.rust-lang.org/book/ch18-02-trait-objects.html) · [Reference — Trait objects](https://doc.rust-lang.org/reference/items/traits.html)

3. Struct alanında strateji tutmanın iki yolu vardır: generic `F: Fn(..)` (derleme anında sabit, sıfır maliyet; her kural ayrı `Fiyatlayici<F>` türüdür) ya da `Box<dyn Fn>` (çalışırken eklenir, hepsi aynı türdedir → tek `Vec`'te durur; geri çağrı listeleri bunu kullanır).
   ↳ Kaynak: [Book ch10-01 — Generic Data Types](https://doc.rust-lang.org/book/ch10-01-syntax.html) · [Book ch18-02 — Trait Objects](https://doc.rust-lang.org/book/ch18-02-trait-objects.html)

4. Alandaki closure'ı çağırırken parantez şarttır: `self.kural(tutar)` yazarsan derleyici `kural` adlı bir **metot** arar (**E0599**). Doğrusu `(self.kural)(tutar)` demektir.
   ↳ Kaynak: [Rustdoc — Fn](https://doc.rust-lang.org/std/ops/trait.Fn.html) · [rustc 1.99.1 — method/probe.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_hir_typeck/src/method/probe.rs)

## Sonsuz iterator, tembellik ve `collect`

1. `Fibonacci` tembel olduğu için sonsuz bir dizi olarak temsil edilebilir; ne kadarını istediğini tüketici (`take`, `take_while`, `find`) belirler. `next` içinde `checked_add(...)?` taşacağı anda `None` döner ve akış kendiliğinden kapanır — panik ya da sessiz taşma yoktur.
   ↳ Kaynak: [Rustdoc — Iterator](https://doc.rust-lang.org/std/iter/trait.Iterator.html) · [Rustdoc — u64::checked_add](https://doc.rust-lang.org/std/primitive.u64.html#method.checked_add)

2. Zincir **kurulduğunda** hiçbir closure çalışmaz. `inspect` ile izlenen örnekte "zincir kuruldu" satırı önce basılır; `take(2)` yüzünden 3. ve 4. öğe hiç işlenmez. Yan etki için `map` değil `for` ya da `for_each` kullanılır; tüketmeyen zincir `must_use` uyarısı verir (DOĞRULANDI).
   ↳ Kaynak: [Rustdoc — Iterator::inspect](https://doc.rust-lang.org/std/iter/trait.Iterator.html#method.inspect) · [rustc 1.99.1 — late.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_lint/src/late.rs)

3. `collect` hedef türden öğrenir: `let kareler: Vec<u32> = ...collect()`, turbofish `collect::<Vec<_>>()` ya da `String` hedefi. Tür yoksa **E0283** (type annotations needed) alınır; derleyici senin yerine tahmin yürütmez.
   ↳ Kaynak: [Rustdoc — FromIterator](https://doc.rust-lang.org/std/iter/trait.FromIterator.html) · [Rustdoc — Iterator::collect](https://doc.rust-lang.org/std/iter/trait.Iterator.html#method.collect)

4. `for x in &v` = `v.iter()`, `for x in &mut v` = `v.iter_mut()`, `for x in v` = `v.into_iter()`. `iter()` `&T` üretir; `filter`'ın closure'ı ona bir `&` daha ekler (`|ad: &&String|`). `into_iter` sahipliği alır, sonrasında `adlar` kullanılamaz (**E0382**).
   ↳ Kaynak: [Rustdoc — IntoIterator](https://doc.rust-lang.org/std/iter/trait.IntoIterator.html) · [Book ch13-02 — The `into_iter` Method](https://doc.rust-lang.org/book/ch13-02-iterators.html)

## Sık yapılan beş hata ve deyimsel çözümü

1. **FnOnce closure'ı iki kez çağırmak (`E0382`).** `let ver = move || etiket; ver(); ver();` ikinci çağrıda closure'ın kendisini tüketir. Değeri dışarı taşıma; kopyasını ya da referansını verirsen closure `Fn` olur ve `ver(), ver()` çalışır.
   ↳ Kaynak: [Rustdoc — FnOnce](https://doc.rust-lang.org/std/ops/trait.FnOnce.html) · [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs)

2. **FnMut closure'ı `Fn` bekleyen yere vermek (`E0525`).** "expected a closure that implements the `Fn` trait, but this closure only implements `FnMut`". Alan taraf gerçekten paylaşımlı çağırmak zorunda değilse imzayı `FnMut`'a gevşet; kural: en gevşek trait'i iste.
   ↳ Kaynak: [Rustdoc — FnMut](https://doc.rust-lang.org/std/ops/trait.FnMut.html) · [Book ch13-01 — Closures as Parameters](https://doc.rust-lang.org/book/ch13-01-closures.html)

3. **Closure `&mut` yakalamışken dışarıdan okumak (`E0502`).** Ödünç, closure'ın **son kullanımında** biter (NLL): önce `ekle(4); ekle(5);`, sonra `v.len()` yaz. Araya okuma sokarsan bakan ve yazan aynı anda olur.
   ↳ Kaynak: [Book ch04-02 — NLL](https://doc.rust-lang.org/book/ch04-02-references-and-borrowing.html) · [rustc 1.99.1 — nll.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/nll.rs)

4. **Aynı değişkeni değiştiren iki closure'ı canlı tutmak (`E0499`).** `let mut a = || v.push(1); let mut b = || v.push(2);` derleyici iki ödüncü aynı anda kabul etmez. Değişkeni yakalamak yerine parametre olarak al: `|hedef: &mut Vec<i32>| hedef.push(6)` hiçbir şey ödünç tutmaz. "Mutable variable is already captured by a closure" ayrı bir durumdur, burada görülmez.
   ↳ Kaynak: [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs) · [Rustdoc — FnMut](https://doc.rust-lang.org/std/ops/trait.FnMut.html)

5. **Yereli ödünç alan closure'ı döndürmek (`E0373`).** `fn esik_ustu() -> impl Fn(u32) -> bool { let esik = 10; |x| x > esik }` — closure, fonksiyon bitince yok olacak `esik`'e bakıyor. `move` ile sahipliği closure'a ver; `en_az` tam olarak bunu yapar.
   ↳ Kaynak: [Book ch13-01 — Moving Captured Values Out of the Closure](https://doc.rust-lang.org/book/ch13-01-closures.html) · [rustc 1.99.1 — upvar.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_hir_typeck/src/upvar.rs)

## Derleyici perspektifi

- **Capture mode kararı** `rustc_hir_typeck/src/upvar.rs` içinde verilir; Edition 2021+ ile yakalama ayrıktır (disjoint, RFC 2229). `s.a`'yı kullanan closure tüm `s`'i yakalamaz, böylece gereksiz çakışmalar azalır.
  ↳ Kaynak: [rustc 1.99.1 — upvar.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_hir_typeck/src/upvar.rs) · [Book ch13-01](https://doc.rust-lang.org/book/ch13-01-closures.html)

- **Her closure'ın türü benzersizdir.** Aynı görünen iki closure bile ayrı türdür; farklı kollardan dönüş `E0308` verir. `Box<dyn Fn>` türü gizleyip çağrıyı vtable üzerinden yapar; `impl Fn` ise tek somut türü statik çağırır.
  ↳ Kaynak: [Reference — Trait objects](https://doc.rust-lang.org/reference/items/traits.html) · [rustc 1.99.1 — collector.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_monomorphize/src/collector.rs)

- **`next` tek zorunlu metottur** (`library/core/src/iter/traits/iterator.rs:78`); `filter_map`, `fold`, `partition`, `flat_map`, `zip`, `take`, `windows` hepsi onun üstündeki varsayılan metotlardır.
  ↳ Kaynak: [rustc 1.99.1 — iterator.rs:78](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/iter/traits/iterator.rs#L78) · [Rustdoc — Iterator](https://doc.rust-lang.org/std/iter/trait.Iterator.html)

- **Tembellik ve `must_use`** aynı olayın iki yüzüdür: adaptörler yeni iterator struct'ı döndürür, tüketici `next()` çağırınca iş yapılır; tüketmeyen zincir için uyarı DOĞRULANDI. Performans nitelendirmesi "çoğu zaman"dır; bu oturumda assembly ölçümü yapılmadı (DOĞRULANAMADI).
  ↳ Kaynak: [rustc 1.99.1 — late.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_lint/src/late.rs) · [Book ch13-04 — Performance](https://doc.rust-lang.org/book/ch13-04-performance.html)

> **Bağlantı:** `Box<dyn Fn>` bir `Box`'tır; bir closure'ı birden çok sahibe vermek `Rc<dyn Fn>`, yakalanan durumu paylaşarak değiştirmek `Rc<RefCell<..>>` ister. `thread::spawn(move || ..)` ise `F: FnOnce() -> T + Send + 'static` ister — buradaki `move` ve `E0373` orada her satırda karşına çıkar.
> ↳ Kaynak: [Book ch16-01 — Threads](https://doc.rust-lang.org/book/ch16-01-threads.html) · [Rustdoc — thread::spawn](https://doc.rust-lang.org/std/thread/fn.spawn.html)

## Özet ve sonraki adım

- Trait'i gövde belirler, `move` yalnız yakalama biçimini değiştirir: `move` + okuma hâlâ `Fn`'dir.
- Döndürürken tek tür → `impl Fn`, çok tür → `Box<dyn Fn>`; adaptör tembel, tüketici çalıştırır.
- Beş klasik borrow hatasının deyimsel çözümü vardır; bu bağlamda **E0499** görülür.

Sıradaki bölüm: [13. Cargo ve Crate'ler](13-cargo-and-crates.md).
