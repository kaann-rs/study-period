# 10. Test Yazma

> Kaynak crate: `learn/writing-tests` · Test: `cargo test -p writing-tests` · Çalıştır: `cargo run -p writing-tests`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

## Neden bu bölüm?

Elle denemek unutulur: bugün çalışan kod, yarın yapılan bir değişiklikle sessizce bozulabilir. Yazılı test ise her değişiklikte eskiden çalışan şeyi hâlâ çalışıp çalışmadığını saniyeler içinde söyler. Rust'ta bunun için ayrı bir framework kurmana gerek yoktur; dil ve cargo testi içerir.

## 5 yaşındaki çocuğa anlatır gibi

Oyuncak atölyesinde küçük sınavlar var: "kutuya 2 ve 3 koyarsan 5 çıkmalı". Bunları bir kez yazarsın, öğretmen her sabah senin yerine kontrol eder. Yanlış olursa hangi sınavın kaldığını söyler.

## Konu anlatımı (madde madde)

1. **Test dile ve cargo'ya gömülüdür.** `#[test]` koyduğun fonksiyon ayrı bir sınavdır; `assert_eq!` sınavın sorusudur. Ayrı bir framework veya test paketi kurulmaz.
   ↳ Kaynak: [Book ch11-01 — Writing Tests](https://doc.rust-lang.org/book/ch11-01-writing-tests.html) · [Book ch11-00 — Testing](https://doc.rust-lang.org/book/ch11-00-testing.html)

2. **`#[cfg(test)]` modülü yalnız test derlemesinde vardır.** `cargo test` crate'i `--test` yapılandırmasıyla derler; normal `cargo build`/`run`'da bu modül hiç yoktur. Böylece test kodu ve yalnız testlerde kullanılan `dev-dependencies` üretim ikilisine girmez.
   ↳ Kaynak: [Book ch11-03 — Test Organization](https://doc.rust-lang.org/book/ch11-03-test-organization.html) · [Reference](https://doc.rust-lang.org/reference/)

3. **`use super::*;` birim testinin private öğelere erişmesini sağlar.** Test modülü üst modülün çocuğudur; çocuk modül üstteki öğeleri (private olanlar dahil) görebilir. Atölye içindeki kalite kontrolcü, müşteriye gösterilmeyen aleti eline alıp deneyebilir.
   ↳ Kaynak: [Book ch11-03 — The Tests Module](https://doc.rust-lang.org/book/ch11-03-test-organization.html#the-tests-module-and-cfgtest) · [Reference — Visibility and Privacy](https://doc.rust-lang.org/reference/visibility-and-privacy.html)

4. **`assert!` ailesi beklentiyi yazar.** `assert!(koşul)` "doğru olmalı", `assert_eq!(a, b)` "eşit olmalı", `assert_ne!(a, b)` "eşit OLMAMALI" der. Tutmayınca `panic!` çağrılır; `assert_eq!` iki değeri de basar, ek argümanlar `format!` gibi özel hata mesajıdır.
   ↳ Kaynak: [Book ch11-01 — Checking Results with assert!](https://doc.rust-lang.org/book/ch11-01-writing-tests.html#checking-results-with-the-assert-macro) · [Rustdoc — assert_eq!](https://doc.rust-lang.org/std/macro.assert_eq.html)

5. **`#[should_panic]` beklentiyi tersine çevirir.** İçindeki kod paniklerse test geçer, paniklemezse düşer. `expected = "negatif olamaz"` alt dizgisi belirtilirse yalnız o mesajla paniklemek kabul edilir; herhangi bir nedenle paniklemek yeterli olmaz.
   ↳ Kaynak: [Book ch11-01 — Using #[should_panic]](https://doc.rust-lang.org/book/ch11-01-writing-tests.html#using-should_panic-to-test-for-panics)

6. **`#[ignore]` testi kenara ayırır.** Uzun süren veya isteğe bağlı test silinmez, normal koşuda atlanır; `cargo test -- --ignored` yalnız onları, `--include-ignored` tümünü çalıştırır.
   ↳ Kaynak: [Book ch11-02 — Running Tests](https://doc.rust-lang.org/book/ch11-02-running-tests.html)

7. **Bir test `Result<(), E>` döndürebilir.** `Ok(())` geçti, `Err(..)` düştü sayılır; faydası testin içinde `?` kullanabilmektir.
   ↳ Kaynak: [Book ch11-01 — Using Result<T, E> in Tests](https://doc.rust-lang.org/book/ch11-01-writing-tests.html#using-resultt-e-in-tests) · [Rustdoc — Result](https://doc.rust-lang.org/std/result/enum.Result.html)

8. **Entegrasyon testleri `tests/` dizininde ayrı crate'lerdir.** Crate'e bir kullanıcı gibi yalnız public API'dan `use writing_tests::...` ile erişilir; `kirp` gibi private öğeler görünmez. Her `tests/` dosyası kendi test ikilisi olarak derlenir; bu dosyalarda `#[cfg(test)]`/`mod` gerekmez.
   ↳ Kaynak: [Book ch11-03 — Integration Tests](https://doc.rust-lang.org/book/ch11-03-test-organization.html#integration-tests) · [Reference — Visibility and Privacy](https://doc.rust-lang.org/reference/visibility-and-privacy.html)

9. **`main` entegrasyon testine doğrudan import edilemez.** Test edilebilir mantık `lib.rs`'e konur, `main` ince bir vitrin olarak kalır. Salt-ikili crate'in `tests/` dosyaları public API göremez; bu yüzden entegrasyon testi için crate'in bir lib hedefi olmalıdır. Bu crate'de `main.rs` yalnız `use writing_tests::{kelime_say, topla, yas_dogrula};` ile üç fonksiyonu çağırır.
   ↳ Kaynak: [Book ch11-03 — Integration Tests](https://doc.rust-lang.org/book/ch11-03-test-organization.html#integration-tests) · [Book ch07-01 — Packages and Crates](https://doc.rust-lang.org/book/ch07-01-packages-and-crates.html)

10. **Koşucu (libtest) testleri varsayılan olarak paralel çalıştırır.** Bu yüzden testler birbirinden bağımsız olmalı; paylaşılan dosya/global duruma dokunanlar çakışabilir. `cargo test -- --test-threads=1` seri yapar, `cargo test topla` adında "topla" geçenleri süzer, `--show-output` başarılı testlerin gizlenen stdout'unu gösterir.
    ↳ Kaynak: [Book ch11-02 — Running Tests](https://doc.rust-lang.org/book/ch11-02-running-tests.html)

## Kodda nasıl görünür?

```rust
// src/lib.rs — birim testi: üst modülün private öğelerine erişir
#[cfg(test)]
mod testler {
    use super::*;

    #[test]
    fn topla_calisir() {
        assert_eq!(topla(2, 3), 5);
        assert_ne!(topla(2, 2), 5);
    }

    #[test]
    #[should_panic(expected = "negatif olamaz")]
    fn negatif_yas_panikler() {
        yas_dogrula(-1);
    }
}

// tests/entegrasyon.rs — ayrı crate, yalnız public API
use writing_tests::{kelime_say, topla};

#[test]
fn dışarıdan_topla() {
    assert_eq!(topla(40, 2), 42);
}
```

## Sık yapılan hatalar

| Yanlış kullanım | Hata | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| `tests/entegrasyon.rs` içinde `use writing_tests::kirp;` | derlenmez | `kirp` private; entegrasyon testi yalnız public API'yı görür. Private için birim testi yaz. | [Reference — Visibility and Privacy](https://doc.rust-lang.org/reference/visibility-and-privacy.html) |
| Arama mantığını `main.rs`'e koymak | test edilemez | `main` entegrasyon testine import edilemez; mantığı `lib.rs`'e taşı. | [Book ch11-03](https://doc.rust-lang.org/book/ch11-03-test-organization.html) |
| Paylaşılan dosyaya yazan paralel testler | aralıklı hata | Testler bağımsız olmalı; gerekirse `cargo test -- --test-threads=1`. | [Book ch11-02](https://doc.rust-lang.org/book/ch11-02-running-tests.html) |
| `#[ignore]` koyup `--ignored` kullanmayı unutmak | test koşmaz | Normal koşuda atlanır; `--ignored` veya `--include-ignored` gerekir. | [Book ch11-02](https://doc.rust-lang.org/book/ch11-02-running-tests.html) |
| `#[should_panic]` olan testin paniklememesi | test düşer | Beklenen davranış paniktir; `expected = "..."` ile mesajı da sıkılaştır. | [Book ch11-01](https://doc.rust-lang.org/book/ch11-01-writing-tests.html) |

## Derleyici perspektifi

- `cargo test`, crate'i `--test` yapılandırmasıyla derler; `cfg(test)` açıktır, normal build'de kapalıdır. Test kodu ve test-only bağımlılıklar üretim ikilisine girmez; `#[cfg(test)]` bunu derleme anında ayırır.
  ↳ Kaynak: [Book ch11-03 — cfg(test)](https://doc.rust-lang.org/book/ch11-03-test-organization.html#the-tests-module-and-cfgtest) · [Reference](https://doc.rust-lang.org/reference/)

- `#[test]` fonksiyonları derleyicinin ürettiği test koşucusu (libtest) ile bir araya gelir. Koşucu testleri bulur, varsayılan olarak paralel çalıştırır ve her testin paniğini kendi içinde izole yakalar; biri düşünce ötekiler koşmaya devam eder. Başarılı testin stdout'u gizlenir.
  ↳ Kaynak: [Book ch11-02 — Running Tests](https://doc.rust-lang.org/book/ch11-02-running-tests.html)

- `assert!` / `assert_eq!` koşul tutmazsa `panic!` çağırır; `#[should_panic]` bu mantığı tersine çevirir. Yani testin "düşme" mekanizması paniktir, özel bir test hatası türü değildir.
  ↳ Kaynak: [Book ch11-01 — Writing Tests](https://doc.rust-lang.org/book/ch11-01-writing-tests.html) · [Rustdoc — panic!](https://doc.rust-lang.org/std/macro.panic.html)

- Birim testleri `src` içinde özel modülde, entegrasyon testleri `tests/` altında ayrı crate'lerdedir. Bu ayrım "dışarıdan görünen davranış"ı iç ayrıntıdan bağımsız sınamanı sağlar.
  ↳ Kaynak: [Book ch11-03 — Test Organization](https://doc.rust-lang.org/book/ch11-03-test-organization.html)

## Özet ve sonraki adım

- `#[test]` + `assert!` ailesi testi yazar; `#[should_panic]`, `#[ignore]` ve `Result` dönen testler özel durumları kapsar.
- Birim testleri private'a erişir; entegrasyon testleri yalnız public API'yı görür, `main` import edilemez.
- Testler paralel koşar ve `cfg(test)` sayesinde üretim ikilisine sızmaz.

Sıradaki bölüm: [11. minigrep: Gerçek Bir Program](11-minigrep.md) — buraya kadar gördüğün Result, lifetime, trait, closure/iterator ve testleri tek bir komut satırı aracında birleştireceğiz.
