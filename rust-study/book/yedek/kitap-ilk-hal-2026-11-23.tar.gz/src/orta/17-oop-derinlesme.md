# 17.1 OOP: Derinleşme

> Kaynak dosya: `learn/oop/src/derinlesme.rs` · Test: `cargo test -p oop`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

Önceki sayfada `Vec<Box<dyn Ciz>>` ile heterojen listeyi gördük; statik/dinamik dispatch temeli Böl. 10'da, fat pointer'ın iç yüzü [22. Boyut, DST ve Şişman İşaretçi](../ileri/22-sized-dst.md) sayfasındadır. Burada tasarım kararlarına iniyoruz.

## Neden bu sayfa?

Gerçek sistemlerde türler yazıldığı gün belli olmaz: eklentiler, sürücüler, sonradan eklenen kanallar. Çekirdek kod onları bilmeden çalışmalı, yalnızca sözleşmeyi (trait'i) tanımalı. Aynı problemi dyn, generic ve enum ile çözüp "yeni türü kim ekleyecek?" sorusuna göre seçim yapmayı öğreneceğiz.

## Gerçek senaryo: genişletilebilir bildirim sistemi

`Kanal` trait'i üç şeyi birden kullanır: varsayılan metot (şablon metot), kanca (hook) ve supertrait'ler. `gonder` algoritmanın iskeletidir; `bicimle` her kanalın farklı yaptığı adımdır; `azami_uzunluk` isteğe bağlı kancadır (varsayılan "sınır yok", SMS onu 12'ye çeker).

```rust
pub trait Kanal: Debug + Any + KanalKlonla {
    fn ad(&self) -> &'static str;
    fn bicimle(&self, mesaj: &str) -> String;

    fn azami_uzunluk(&self) -> Option<usize> { None } // kanca

    fn gonder(&self, mesaj: &str) -> String { // şablon metot
        let govde: String = match self.azami_uzunluk() {
            Some(sinir) => mesaj.chars().take(sinir).collect(),
            None => mesaj.to_string(),
        };
        format!("[{}] {}", self.ad(), self.bicimle(&govde))
    }

    fn etiketli(self, etiket: &'static str) -> Etiketli<Self>
    where
        Self: Sized,
    {
        Etiketli { ic: self, etiket }
    }
}

#[derive(Default, Clone)]
struct Dagitici {
    kanallar: HashMap<String, Box<dyn Kanal>>,
}
impl Dagitici {
    fn kaydet(&mut self, kanal: impl Kanal) {
        self.kanallar.insert(kanal.ad().to_string(), Box::new(kanal));
    }
    fn gonder(&self, kanal_adi: &str, mesaj: &str) -> Option<String> {
        self.kanallar.get(kanal_adi).map(|k| k.gonder(mesaj))
    }
}
```

1. **Paylaşılan şey davranıştır, alan değil.** Trait'in verisi yoktur; ihtiyaç duyduğu her şeyi zorunlu metotlardan ister. Kalıtımlı dillerde taban sınıfın metodudur bu; Rust'ta varsayılan trait metodu olur.
   ↳ Kaynak: [Book ch10-02 — Traits](https://doc.rust-lang.org/book/ch10-02-traits.html) · [Book ch18-01 — Features of OOP](https://doc.rust-lang.org/book/ch18-01-features-of-oop.html)

2. **Supertrait'ler ön şarttır.** `Kanal: Debug + Any + KanalKlonla` sayesinde kutu `{:?}` ile basılabilir, `dyn Any`'e upcast yapılabilir ve kutu klonlanabilir. `Any` uygulayan türler `'static` olmak zorundadır; bu, gizli ömür sınırının da kaynağıdır.
   ↳ Kaynak: [Reference — Trait objects](https://doc.rust-lang.org/reference/items/traits.html) · [Rustdoc — Any](https://doc.rust-lang.org/std/any/trait.Any.html)

3. **`where Self: Sized` metotu vtable'ın dışında bırakır.** Dönüş türünde `Etiketli<Self>` geçtiği için bu metot dyn-uyumsuzdur; kısıt sayesinde trait yine `dyn Kanal` olarak kullanılabilir, metot yalnız somut türlerde çağrılır. `Iterator::map/filter` aynı numarayla `dyn Iterator`'ı mümkün kılar.
   ↳ Kaynak: [Reference — Trait objects](https://doc.rust-lang.org/reference/items/traits.html) · [Rustdoc — Iterator](https://doc.rust-lang.org/std/iter/trait.Iterator.html)

4. **Yeni kanal çekirdeğe dokunmaz.** `Webhook` için `impl Kanal` yazmak yeterlidir; `Dagitici`, `Kanal` ve diğer kanallarda tek satır değişmez. Başka bir crate'te de yazılabilirdi — eklenti mimarisinin özü budur.
   ↳ Kaynak: [Book ch18-02 — Trait Objects](https://doc.rust-lang.org/book/ch18-02-trait-objects.html) · [Book ch18-01 — Features of OOP](https://doc.rust-lang.org/book/ch18-01-features-of-oop.html)

## Aynı problem, üç çözüm: dyn / generic / enum

| | `dyn Trait` | `generic<K: Kanal>` | `enum` |
| --- | --- | --- | --- |
| Tür kümesi | AÇIK (dışarıdan eklenir) | açık, ama çağrıda TEK tür | KAPALI (yazar belirler) |
| Heterojen liste | evet | hayır | evet |
| Çağrı | vtable, inline edilemez | statik, inline edilebilir | `match` dallanması, inline |
| Kullanan kod | tek kopya | tür başına kopya | tek kopya |
| Yeni TÜR | kolay (yeni `impl`) | kolay (yeni `impl`) | her `match`'e dokunulur |
| Yeni İŞLEM | trait'e + her impl'e | trait'e + her impl'e | kolay (yeni fn + match) |

↳ Kaynak: [Book ch18-02 — Trait Objects](https://doc.rust-lang.org/book/ch18-02-trait-objects.html) · [Book ch10-01 — Generic Data Types](https://doc.rust-lang.org/book/ch10-01-syntax.html) · [Book ch06-01 — Defining an Enum](https://doc.rust-lang.org/book/ch06-01-defining-an-enum.html)

1. Pratik ölçüt: türleri **kim** genişletecek? Kullanıcı/eklenti → dyn. Sen ekleyeceksen ve küme küçükse → enum. Tek tür ve sıcak döngü → generic.
   ↳ Kaynak: [Book ch18-02 — Trait Objects](https://doc.rust-lang.org/book/ch18-02-trait-objects.html) · [Book ch10-01 — Generic Data Types](https://doc.rust-lang.org/book/ch10-01-syntax.html)

2. Enum çözümünde `match` bütünlük (exhaustiveness) denetimi yapar: yeni varyant eklenince derleyici güncellenmesi gereken her yeri gösterir. Bu gücün asıl aracı Böl. 18'deki desenlerdir.
   ↳ Kaynak: [Book ch06-02 — match](https://doc.rust-lang.org/book/ch06-02-match.html) · [rustc 1.99.1 — check_match.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_build/src/thir/pattern/check_match.rs)

## Hangi işaretçi?

- `&dyn Kanal` — yalnız kullanacaksan (parametre); tahsis yok, sahiplik yok, varsayılan tercih.
- `Box<dyn Kanal>` — sahip olacaksan (alan, koleksiyon, dönüş değeri); tek sahip.
- `Rc<dyn Kanal>` — aynı nesne birden çok sahip-te, tek thread (Böl. 14).
- `Arc<dyn Kanal + Send + Sync>` — aynısı thread'ler arası (Böl. 15).

↳ Kaynak: [Book ch15-04 — `Rc<T>`](https://doc.rust-lang.org/book/ch15-04-rc.html) · [Book ch16-03 — Shared-State Concurrency](https://doc.rust-lang.org/book/ch16-03-shared-state.html) · [Rustdoc — Box](https://doc.rust-lang.org/std/boxed/struct.Box.html)

1. `dyn Kanal` tek başına `Send`/`Sync` değildir: auto trait'ler tür silinince sızmaz. `+ Send + Sync` yazan taraf sözü verir; aksi halde `Box<dyn Kanal>`'ı thread'e taşımak **E0277** ile derlenmez.
   ↳ Kaynak: [rustc 1.99.1 — marker.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/marker.rs) · [Book ch16-04 — Sync and Send](https://doc.rust-lang.org/book/ch16-04-extensible-concurrency-sync-and-send.html)

## Trait object'ın gizli ömür sınırı

Her `dyn Trait` aslında `dyn Trait + 'ömür` biçimindedir; yazmazsan derleyici doldurur. `Box<dyn Sablon>` = `Box<dyn Sablon + 'static>` demektir, yani içine referans tutan tür konamaz.

```rust
trait Sablon { fn uygula(&self, mesaj: &str) -> String; }
struct Onek<'a>(&'a str); // referans tutan tür
impl Sablon for Onek<'_> {
    fn uygula(&self, mesaj: &str) -> String { format!("{}{mesaj}", self.0) }
}

// ✗ fn sablon_kutula(o: &str) -> Box<dyn Sablon> { Box::new(Onek(o)) }
//   "returning this value requires that `'1` must outlive `'static`" (E-kodu yok)
// ✓ sınırı açıkça gevşet: kutu, ödünç yaşadığı sürece geçerli.
fn sablon_kutula(onek: &str) -> Box<dyn Sablon + '_> {
    Box::new(Onek(onek))
}
```

1. Tür silinince derleyici "kutunun içindeki şey bir yere ödünç bağlı mı?" sorusunu somut türden okuyamaz; bilgi dyn'in üstündeki bu sınırda taşınır. Etiket olmasaydı kutu, ödünç geri verildikten sonra da onu gösterebilirdi.
   ↳ Kaynak: [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html) · [Nomicon — HRTB](https://doc.rust-lang.org/nomicon/hrtb.html)

2. Aynı kök neden kodlu hâliyle de görünür: yereli ödünç alan `Onek`'i `Vec<Box<dyn Sablon>>`'a itip yerel düştükten sonra kullanmak **E0597** verir (`s does not live long enough`).
   ↳ Kaynak: [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs) · [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html)

## Upcasting ve `dyn Any`: downcast ne zaman kokudur?

Upcasting, `&dyn Kanal`'ı `&dyn Debug` ya da `&dyn Any` gibi bir supertrait object'e dönüştürmektir (Rust 1.86'dan beri kararlı; öncesinde elle `fn as_any(&self) -> &dyn Any` yazılırdı). `dyn Any` ise çalışma anında "sen aslında şu tür müsün?" sorusunu sordurur.

1. **Koku:** genel koda `if Sms ise …` yazmak. Açık küme vaadini bozar: `Sms`'i saran `Etiketli<Sms>`'i ve yarın eklenecek her kısa-mesaj kanalını kaçırır. Doğru soru "sınırın var mı?" diye trait'e sorulur (`kanal.azami_uzunluk().is_some()`).
   ↳ Kaynak: [Rustdoc — Any](https://doc.rust-lang.org/std/any/trait.Any.html) · [Book ch18-02 — Trait Objects](https://doc.rust-lang.org/book/ch18-02-trait-objects.html)

2. **Meşru kullanım:** türü gerçekten bilinmeyen kaplar (tür → değer haritaları, eklentinin kendi durumunu geri alması) ve `Box<dyn Error>`'dan belirli bir hatayı ayıklamaktır.
   ↳ Kaynak: [Rustdoc — Any](https://doc.rust-lang.org/std/any/trait.Any.html) · [Book ch09-02 — Result](https://doc.rust-lang.org/book/ch09-02-recoverable-errors-with-result.html)

## Kalıtım yerine bileşim + `Box<dyn Kanal>` klonlama

Kalıtımlı dilde "AcilSms extends Sms" yazılırdı. Rust'ta sarmalayıcı kullanılır: `Etiketli<K>`, başka bir kanalı **alan** olarak tutar, işin çoğunu ona **devreder**, yalnız bir adımı değiştirir. Tek bir taban türe bağlı olmadığı için her `Kanal`'ı sarabilir ve sarmalayıcılar iç içe geçebilir. Bedeli: devredilen metotları elle yazarsın.

```rust
#[derive(Debug, Clone)]
pub struct Etiketli<K> { ic: K, etiket: &'static str }

impl<K: Kanal + Clone> Kanal for Etiketli<K> {
    fn ad(&self) -> &'static str { self.ic.ad() }
    fn bicimle(&self, mesaj: &str) -> String {
        format!("{} {}", self.etiket, self.ic.bicimle(mesaj))
    }
    fn azami_uzunluk(&self) -> Option<usize> { self.ic.azami_uzunluk() }
}

pub trait KanalKlonla {
    fn kutu_klonu(&self) -> Box<dyn Kanal>;
}
impl<T: Kanal + Clone> KanalKlonla for T {
    fn kutu_klonu(&self) -> Box<dyn Kanal> { Box::new(self.clone()) }
}
impl Clone for Box<dyn Kanal> {
    fn clone(&self) -> Self { (**self).kutu_klonu() }
}
```

1. `Clone::clone` `Self` döndürdüğü için `trait Kanal: Clone` yazmak trait'i dyn-uyumsuz yapar (**E0038**). Çözüm, Self yerine kutu döndüren dyn-uyumlu bir metot ve onu her tür için bir kerede yazan blanket impl'dir.
   ↳ Kaynak: [Book ch10-02 — Traits](https://doc.rust-lang.org/book/ch10-02-traits.html) · [Rustdoc — Clone](https://doc.rust-lang.org/std/clone/trait.Clone.html) · [Reference — Trait objects](https://doc.rust-lang.org/reference/items/traits.html)

2. `(**self).kutu_klonu()` açık yazılır: ileride `impl Kanal for Box<dyn Kanal>` eklenirse `self.kutu_klonu()` kutunun kendi blanket impl'ini bulur ve sonsuz özyineleme olur.
   ↳ Kaynak: [Rustdoc — Deref](https://doc.rust-lang.org/std/ops/trait.Deref.html) · [Book ch15-02 — Deref](https://doc.rust-lang.org/book/ch15-02-deref.html)

3. Artık `Box<dyn Kanal>` klonlanabilir; onu alan olarak tutan `Dagitici` de `derive(Clone)` yapabilir. `HashMap<String, Box<dyn Kanal>>` klonu bağımsızdır: yedekteki kaydı değiştirmek aslı etkilemez.
   ↳ Kaynak: [Rustdoc — Clone](https://doc.rust-lang.org/std/clone/trait.Clone.html) · [Book ch08-03 — Hash Maps](https://doc.rust-lang.org/book/ch08-03-hash-maps.html)

## Sık yapılan hatalar

| Kod / durum | Hata | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| `trait Kanal { fn kopya(&self) -> Self; }` + `&dyn Kanal` | **E0038** | Self/generic metot dyn-uyumsuz; `where Self: Sized` ile dışarıda bırak. | [Reference — Trait objects](https://doc.rust-lang.org/reference/items/traits.html) |
| `kutu.etiketli("x")` — `Self: Sized` metot trait object'te | derlenmez | Metot vtable'da yok; somut türde çağrılmalı. Birebir mesaj sürüye bağlı, **DOĞRULANAMADI**. | [Reference — Trait objects](https://doc.rust-lang.org/reference/items/traits.html) |
| `let v: Vec<dyn Kanal> = Vec::new();` | **E0277** | `dyn Kanal` DST'dir; `Vec<Box<dyn Kanal>>` kullan (ayrıntı: ileri-sized-dst). | [Nomicon — Sized](https://doc.rust-lang.org/nomicon/sized.html) |
| `kutu.clone()` — trait'te klon desteği yokken | **E0599** | `dyn Kanal: Clone` sağlanmıyor; `trait Kanal: Clone` da E0038 verir. `kutu_klonu` çözümü. | [Rustdoc — Clone](https://doc.rust-lang.org/std/clone/trait.Clone.html) |
| Yereli ödünç alan `Onek` kutudan sonra kullanılıyor | **E0597** | Gizli `'static` sınırı; `Box<dyn Sablon + '_>` yaz. | [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html) |
| `SabitKanal`'a yeni varyant, `match` güncellenmedi | **E0004** | Bütünlük denetimi kolu ister; dyn çözümünde sıfır yer dokunulur. | [Book ch06-02 — match](https://doc.rust-lang.org/book/ch06-02-match.html) · [check_match.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_build/src/thir/pattern/check_match.rs) |

## Derleyici perspektifi

- **Dyn uyumluluğu ve vtable.** `Self` dönen/generic metotlar vtable'a giremez (**E0038**); `where Self: Sized` onları dışarıda bırakır. Fat pointer'ın iki kelime olmasının nedeni Böl. 10 ve [ileri-sized-dst](../ileri/22-sized-dst.md) sayfasındadır; Böl. 15 bu konunun yeri değildir.
  ↳ Kaynak: [Reference — Trait objects](https://doc.rust-lang.org/reference/items/traits.html) · [Nomicon — Sized](https://doc.rust-lang.org/nomicon/sized.html)

- **Gizli ömür sınırı tür silmeyle gelir.** Somut tür bilinmediği için ödünç bilgisi `dyn Trait + 'a` üstünde taşınır; `'static` varsayılandır ve referans tutan türlerin kutulanmasını engeller.
  ↳ Kaynak: [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html) · [Nomicon — HRTB](https://doc.rust-lang.org/nomicon/hrtb.html)

- **Monomorphization ile dyn'in maliyeti farklıdır.** Generic her tür için kopya üretir (`collector.rs`), dyn tek kopya + vtable dolaylaması kullanır; sıcak yolda generic, açık kümede dyn tercih edilir.
  ↳ Kaynak: [rustc 1.99.1 — collector.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_monomorphize/src/collector.rs) · [Book ch10-01](https://doc.rust-lang.org/book/ch10-01-syntax.html)

- **Bütünlük denetimi enum'u güçlü kılar.** Yeni varyant eklendiğinde `rustc_mir_build/src/thir/pattern/check_match.rs` eksik kolları bulur; dyn tarafında böyle bir derleme zamanı listesi yoktur, sorumluluk yeni `impl`'dedir.
  ↳ Kaynak: [rustc 1.99.1 — check_match.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_build/src/thir/pattern/check_match.rs) · [Book ch06-02](https://doc.rust-lang.org/book/ch06-02-match.html)

## Özet ve sonraki adım

- Soru "dyn mı generic mi" değil, "tür kümesini kim genişletecek ve liste heterojen mi?".
- dyn; `Send`/`Sync` ve ömür bilgisini kendiliğinden taşımaz: `+ Send`, `+ 'a` yazılır.
- Downcast yerine trait'e metot ekle; kalıtım yerine sar ve devret; `Box<dyn>` klonu blanket impl ile çözülür.

Bir sonraki bölüm: [18. Desenler (Patterns)](18-patterns.md). Enum çözümünün gücü `match`'ten gelir; bütünlük denetimi, iç içe desenler ve guard'lar orada anlatılır.
