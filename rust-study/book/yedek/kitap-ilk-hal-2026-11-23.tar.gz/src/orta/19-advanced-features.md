# 19. Gelişmiş Özellikler

> Kaynak crate: `learn/advanced-features` · Çalıştır: `cargo run -p advanced-features`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

## Neden bu bölüm?

Rust'ın atölyesinde seyrek çıkan ama güçlü aletler durur: çıplak işaretçi, operatör aşırı yükleme, newtype, fonksiyon işaretçisi ve makro. Bunların ortak noktası güç ile güvenlik dengesidir: keskin kısmı küçük ve anlaşılır bir yerde tutup dışarıya alışılmış bir kullanım bırakmak. Bu bölümde o aletlerin ne işe yaradığını ve sınırlarını görüyoruz.

## 5 yaşındaki çocuğa anlatır gibi

Atölyede keskin bir makas var. Usta onu yalnız küçük bir kutunun içinde kullanır, sana sadece güvenli sapını uzatır. Sen sapı tutarsın, dişine dokunmazsın. Zor kısım saklanır, kolay kısım sana verilir.

## Konu anlatımı (madde madde)

1. **Beş başlık altında toplanır.** Unsafe Rust, gelişmiş trait'ler, gelişmiş tipler, fonksiyon işaretçileri ve closure döndürme, makrolar. Ortak tema güçlü araçları güvenli soyutlamaların arkasında tutmaktır.
   ↳ Kaynak: [Book ch20-00 — Advanced Features](https://doc.rust-lang.org/book/ch20-00-advanced-features.html)

2. **`unsafe`, "buranın doğruluğunu derleyici değil ben garanti ediyorum" demektir.** Çıplak işaretçi (`*const T`, `*mut T`) oluşturmak güvenli bir işlemdir; adrese gidip orada durana bakmak (dereference) unsafe kabul edilir, çünkü adres null veya sarkmış olabilir.
   ↳ Kaynak: [Book ch20-01 — Unsafe Rust](https://doc.rust-lang.org/book/ch20-01-unsafe-rust.html) · [Nomicon — What Unsafe Does](https://doc.rust-lang.org/nomicon/what-unsafe-does.html)

3. **Unsafe yalnız beş işlemi açar:** raw pointer dereference, unsafe fonksiyon/metot çağırma, değiştirilebilir `static` erişimi, unsafe trait uygulama ve union alanı okuma. Borrow checker'ı kapatmaz; geri kalan her şey normal kurallara tabidir. Bu beş işlem `unsafe` bloğu olmadan **E0133** ile reddedilir, çünkü doğruluklarını yalnızca insan garanti edebilir; ihlal tanımsız davranış (UB) demektir.
   ↳ Kaynak: [Book ch20-01 — Unsafe Rust](https://doc.rust-lang.org/book/ch20-01-unsafe-rust.html) · [rustc 1.99.1 — check_unsafety.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_build/src/check_unsafety.rs)

4. **Kaynak kodda `ikiye_bol` küçük bir unsafe bloğu içerir.** Dilim uzunluğu `assert!(orta <= uzunluk)` ile doğrulanır ve iki çakışmayan bölge kurulur; "bunlar çakışmıyor" bilgisi derleyicinin göremeyeceği bir koşuldur ve sorumluluk yazanda kalır. Kaynak metnin aktardığı kullanım biçimi, bu tür blokları küçük tutup güvenli bir API arkasında saklamaktır; std'nin pek çok parçası (örneğin `split_at_mut`) bu deseni izler.
   ↳ Kaynak: [Book ch20-01 — Unsafe Rust](https://doc.rust-lang.org/book/ch20-01-unsafe-rust.html) · [Nomicon — What Unsafe Does](https://doc.rust-lang.org/nomicon/what-unsafe-does.html)

5. **Operatörler de trait'tir.** `Add<Rhs = Self>` içindeki `Rhs` varsayılan tip parametresidir; `type Output` ise sonucun türünü adlandıran associated type'tır. `impl Add for Metre` yazınca `Metre(3) + Metre(4)`, aslında yazdığımız `add` fonksiyonunu çağırır.
   ↳ Kaynak: [Book ch20-02 — Advanced Traits](https://doc.rust-lang.org/book/ch20-02-advanced-traits.html) · [Rustdoc — Add](https://doc.rust-lang.org/std/ops/trait.Add.html)

6. **Newtype, var olan bir türü tek alanlı kendi türünle sarmaktır.** Ne `Display` ne `Vec` bizim olduğu için `impl Display for Vec<String>` yazılamaz (orphan rule); `Sarmal(Vec<String>)` kendi türümüz olduğundan `Display` uygulaması serbesttir. Aynı sarmal `Metre` ile `Saniye`'nin karışmasını da engeller; çalışma anında ek maliyeti yoktur.
   ↳ Kaynak: [Book ch20-02 — Using Newtypes to Implement External Traits](https://doc.rust-lang.org/book/ch20-02-advanced-traits.html) · [Reference — Traits](https://doc.rust-lang.org/reference/items/traits.html)

7. **Tip takma adı newtype değildir.** `type Metin = String;` yalnızca uzun imzalar için lakap verir, yeni bir tür oluşturmaz; newtype ise gerçekten ayrı bir türdür.
   ↳ Kaynak: [Book ch20-03 — Type Aliases](https://doc.rust-lang.org/book/ch20-03-advanced-types.html) · [Reference](https://doc.rust-lang.org/reference/)

8. **Fonksiyon işaretçisi (`fn`) fonksiyonu değer gibi taşır.** `uygula(f: fn(i32) -> i32, x: i32)` çağrıya `carp_iki` adı verilebilir; dışarıdan değişken yakalayan closure ise `fn` işaretçisine dönüşmez. Bu, `Fn`/`FnMut`/`FnOnce` trait'lerinden ayrı bir araçtır.
   ↳ Kaynak: [Book ch20-04 — Function Pointers](https://doc.rust-lang.org/book/ch20-04-advanced-functions-and-closures.html) · [Book ch13-01 — Closures](https://doc.rust-lang.org/book/ch13-01-closures.html)

9. **Closure döndürmenin iki yolu vardır.** Her closure'ın türü ayrı ve adsızdır: `impl Fn` tek somut (adı bilinmeyen) türü ifade eder ve en ucuzudur; `Box<dyn Fn>` farklı closure'ları aynı imzadan döndürmek gerektiğinde heap'te bir kutu kullanır.
   ↳ Kaynak: [Book ch20-04 — Returning Closures](https://doc.rust-lang.org/book/ch20-04-advanced-functions-and-closures.html) · [Book ch18-02 — Trait Objects](https://doc.rust-lang.org/book/ch18-02-trait-objects.html)

10. **Makrolar kod üreten koddur.** `macro_rules!` desenlerle çalışan bildirimsel makrodur; bu dosyadaki `benim_vec!` çağrıldığı yere `push` çağrıları yerleştirir. Prosedürel makrolar ise `TokenStream` alıp `TokenStream` üreten fonksiyonlardır; ayrıntı bir sonraki bölümde.
    ↳ Kaynak: [Book ch20-05 — Macros](https://doc.rust-lang.org/book/ch20-05-macros.html) · [Book ch19-00 — Patterns and Matching](https://doc.rust-lang.org/book/ch19-00-patterns.html)

11. **Never türü (`!`) ve DST bu bölümün gelişmiş tiplerindendir.** `panic!()` gibi hiç dönmeyen ifadelerin türü `!`'dır ve her türe zorlanabilir; bu yüzden `match`'in bir kolu `panic!()` olsa bile kalan kolun türüyle uyuşur. `str`, `[T]`, `dyn Trait` gibi boyu derlemede bilinmeyen DST'ler hep bir işaretçi arkasında kullanılır; varsayılan `T: Sized` kısıtı `?Sized` ile gevşetilebilir.
    ↳ Kaynak: [Book ch20-03 — The Never Type and Dynamically Sized Types](https://doc.rust-lang.org/book/ch20-03-advanced-types.html) · [Reference — Subtyping](https://doc.rust-lang.org/reference/subtyping.html)

## Kodda nasıl görünür?

```rust
use std::fmt;

// 1. Bildirimsel makro: desen → kod şablonu
macro_rules! benim_vec {
    ( $( $x:expr ),* ) => {{
        let mut v = Vec::new();
        $( v.push($x); )*
        v
    }};
}

// 2. Tip takma adı: yeni tür DEĞİL
type Metin = String;

// 3. Fonksiyon işaretçisi: fonksiyonu değer gibi verir
fn uygula(f: fn(i32) -> i32, x: i32) -> i32 { f(x) }
fn carp_iki(x: i32) -> i32 { x * 2 }

// 4. Newtype: yeni tür, dış trait'i bağlamayı sağlar
struct Sarmal(Vec<String>);
impl fmt::Display for Sarmal {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "[{}]", self.0.join(", "))
    }
}
```

## Sık yapılan hatalar

| Kod / durum | Sonuç | Neden | Kaynak |
| --- | --- | --- | --- |
| `*r;` ifadesini `unsafe` bloğu dışında yazmak | **E0133** | Raw pointer dereference yalnız beş unsafe işlemden biridir; doğruluğu insan garanti eder. | [check_unsafety.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_build/src/check_unsafety.rs) · [Book ch20-01](https://doc.rust-lang.org/book/ch20-01-unsafe-rust.html) |
| `impl fmt::Display for Vec<String>` | derlenmez | Ne trait ne tip bizim olduğu için orphan rule engeller; newtype ile sarılır. | [Book ch20-02](https://doc.rust-lang.org/book/ch20-02-advanced-traits.html) · [Reference — Traits](https://doc.rust-lang.org/reference/items/traits.html) |
| `Metre(3) + 4` | derlenmez | `Add<Metre>` uygulandı, düz sayıyla toplama için ayrı `Add<Rhs>` gerekir. | [Rustdoc — Add](https://doc.rust-lang.org/std/ops/trait.Add.html) · [Book ch20-02](https://doc.rust-lang.org/book/ch20-02-advanced-traits.html) |
| `uygula(|x| x + yirmi, 1)` | derlenmez | Değişken yakalayan closure `fn` işaretçisine dönüşmez; `fn` ile `Fn` aynı şey değildir. | [Book ch20-04](https://doc.rust-lang.org/book/ch20-04-advanced-functions-and-closures.html) · [Book ch13-01](https://doc.rust-lang.org/book/ch13-01-closures.html) |
| `type Metin = String;` ile yeni tür sanmak | yanlış anlama | Tip takma adı yeni tür yaratmaz; newtype yaratır. | [Book ch20-03](https://doc.rust-lang.org/book/ch20-03-advanced-types.html) · [Reference](https://doc.rust-lang.org/reference/) |
| Unsafe'in borrow checker'ı kapattığını sanmak | yanlış anlama | Unsafe yalnız beş işlemi açar; ödünç kuralları dışarıda geçerli kalır. | [Book ch20-01](https://doc.rust-lang.org/book/ch20-01-unsafe-rust.html) · [Nomicon](https://doc.rust-lang.org/nomicon/what-unsafe-does.html) |

## Derleyici perspektifi

- **Unsafe denetimi MIR aşamasında yapılır.** `check_unsafety.rs` beş işlemi `unsafe` bloğu dışında gördüğünde **E0133** üretir; ihlalin sonucu UB'dir (null/sarkmış/hizasız işaretçi, aliasing ihlali, veri yarışı).
  ↳ Kaynak: [rustc 1.99.1 — check_unsafety.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_build/src/check_unsafety.rs) · [Nomicon — What Unsafe Does](https://doc.rust-lang.org/nomicon/what-unsafe-does.html)

- **Varsayılan tip parametresi impl'ı sadeleştirir.** `Add<Rhs = Self>` sayesinde `impl Add for Metre` yazınca `Rhs` otomatik `Metre` olur; `Output` associated type'ı çağrı yerinde çözülür.
  ↳ Kaynak: [Rustdoc — Add](https://doc.rust-lang.org/std/ops/trait.Add.html) · [Reference — Traits](https://doc.rust-lang.org/reference/items/traits.html)

- **Newtype'ın çalışma anı maliyeti yoktur.** Tek alanlı sarmal derleyici tarafından optimize edilir; aynı zamanda orphan rule'u aşar ve türleri birbirinden ayırır.
  ↳ Kaynak: [Book ch20-02 — Advanced Traits](https://doc.rust-lang.org/book/ch20-02-advanced-traits.html) · [Book ch20-03 — Advanced Types](https://doc.rust-lang.org/book/ch20-03-advanced-types.html)

- **Makrolar fonksiyonlardan önce açılır (expand).** Derleyici makro çağrısını gerçek koda çevirir; prosedürel makrolar bu sırada `TokenStream` alıp `TokenStream` döndürür ve ayrı bir crate'te yazılır.
  ↳ Kaynak: [Book ch20-05 — Macros](https://doc.rust-lang.org/book/ch20-05-macros.html) · [Reference](https://doc.rust-lang.org/reference/)

## Özet ve sonraki adım

- Unsafe yalnız beş işlemi açar, ödünç kurallarını kapatmaz; sorumluluk ve UB riski yazanda kalır.
- Newtype yeni tür yaratır, tip takma adı lakaptır; `fn` işaretçisi, closure trait'leri ve makro birbirinden ayrı araçlardır.
- Operatörler trait'tir; `!` her türe zorlanabilir, DST'ler işaretçi arkasında tutulur.

Sıradaki bölüm [20. Makrolar](20-macros.md), bu sayfada adı geçen prosedürel makroyu kendi crate'i ve entegrasyon testiyle birlikte ele alır.
