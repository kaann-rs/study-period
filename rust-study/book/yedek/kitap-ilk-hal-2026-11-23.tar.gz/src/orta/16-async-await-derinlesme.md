# 16.1 Async / Await: Derinleşme

> Kaynak dosya: `learn/async-await/src/derinlesme.rs` · Test: `cargo test -p async-await`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

Önceki sayfada çalıştırıcının kendisini yazdık (`block_on` ve elle Future'lar). Bu sayfada o çalıştırıcıyı kullanarak async kod yazarken verilen gündelik kararlara bakıyoruz.

## Neden bu sayfa?

İş kartı yazmak işi başlatmaz; bu yüzden `.await`'i unutmak sessiz bir hatadır. Birbirinden bağımsız işleri arka arkaya değil birlikte beklersen toplam süre en uzun işin süresine iner. Ölçerek göreceğiz: aynı sonuç, yarı süre.

## Future tembeldir: çağırmak başlatmaz

JavaScript'te `fetch()` çağrıldığı an istek yola çıkar; Rust'ta `getir()` hiçbir şey yapmaz, dönen Future işin kendisidir.

```rust
type Gunluk = RefCell<Vec<String>>;

async fn kaydet(gunluk: &Gunluk, mesaj: &str) {
    gunluk.borrow_mut().push(mesaj.to_string());
}

fn tembellik() {
    let gunluk = Gunluk::default();
    let bekleyen = kaydet(&gunluk, "çalıştım"); // future üretildi, gövde çalışmadı
    println!("çağrıdan sonra = {}", gunluk.borrow().len()); // 0
    block_on(bekleyen); // şimdi biri poll etti → 1 kayıt
    // kaydet(&gunluk, "kayboldum"); // derlenir ama hiçbir şey yapmaz (yalnız uyarı)
}
```

1. Bedel şudur: `.await`'i unutmak derleme hatası değil `unused_must_use` uyarısıdır; bu uyarıyı hata gibi okumak gerekir. Değer bekleyen yerde `let n: u32 = sayi_getir();` yazsaydın `E0308` alırdın.
   ↳ Kaynak: [rustc 1.99.1 — late.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_lint/src/late.rs) · [Rustdoc — Future](https://doc.rust-lang.org/std/future/trait.Future.html)

2. Future sıradan bir değerdir: istersen düşürürsün (iptal = drop) ya da çağıran sıralı/eşzamanlı/zaman aşımlı koşmaya karar verir. Sıfır maliyet ve denetim sende; gizli görev ya da tahsis yoktur.
   ↳ Kaynak: [Book ch17-01 — Futures and the Async Syntax](https://doc.rust-lang.org/book/ch17-01-futures-and-syntax.html) · [Rustdoc — Future](https://doc.rust-lang.org/std/future/trait.Future.html)

## Sıralı mı, eşzamanlı mı? — join aslında nedir?

Alt alta iki `.await` **sıralıdır**: ikincisi birincisi bitmeden başlamaz bile. Bağımsız işlerde bu, async'in bütün kazancını çöpe atar. Eşzamanlılık için future'lar önce üretilir, sonra hepsini aynı anda yoklayan bir birleştiriciye (join) verilir.

```rust
pub async fn ikisini_bekle<A: Future, B: Future>(a: A, b: B) -> (A::Output, B::Output) {
    let mut a = pin!(a); // kapsama sabitle, heap tahsisi yok
    let mut b = pin!(b);
    let mut a_sonuc = None;
    let mut b_sonuc = None;
    poll_fn(|cx| {
        // Ready demiş Future YENİDEN POLL EDİLMEZ: sözleşme gereği davranış
        // belirsizdir (panik edebilir); sonucu Option'da saklıyoruz.
        if a_sonuc.is_none() && let Poll::Ready(v) = a.as_mut().poll(cx) {
            a_sonuc = Some(v);
        }
        if b_sonuc.is_none() && let Poll::Ready(v) = b.as_mut().poll(cx) {
            b_sonuc = Some(v);
        }
        match (a_sonuc.take(), b_sonuc.take()) {
            (Some(x), Some(y)) => Poll::Ready((x, y)),
            (x, y) => {
                a_sonuc = x;
                b_sonuc = y;
                Poll::Pending
            }
        }
    })
    .await
}
```

1. Sihir yoktur: her turda A'ya ve B'ye sırayla bakılır; biri `Pending` dönerse hemen ötekine geçilir. Biri bitince sonucu `Option`'a konur ve bir daha bakılmaz — "eşzamanlılık" tam olarak budur.
   ↳ Kaynak: [Rustdoc — Future::poll](https://doc.rust-lang.org/std/future/trait.Future.html#tymethod.poll) · [rustc 1.99.1 — future.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/future/future.rs)

2. Gecikmeler "tur" cinsinden ölçülür: sıralı `3 + 2 (+1) = 6` tur, eşzamanlı `max(3, 2) (+1) = 4` tur. Tek thread vardır; kazanç paralellikten değil beklemenin üst üste binmesindendir.
   ↳ Kaynak: [Book ch17-00 — Async-Await](https://doc.rust-lang.org/book/ch17-00-async-await.html) · [Rustdoc — Future](https://doc.rust-lang.org/std/future/trait.Future.html)

3. `poll_fn` her yoklamada closure'ı çağırır; elle `impl Future for ...` yazmanın kısa yoludur. `Waker::noop()` çalınca hiçbir şey yapmaz; bu dosyada alt future'lar kendini uyandırdığı için yeterlidir.
   ↳ Kaynak: [Rustdoc — poll_fn](https://doc.rust-lang.org/std/future/fn.poll_fn.html) · [rustc 1.99.1 — wake.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/task/wake.rs)

## Gerçek senaryo: asenkron API istemcisi

Profıl sayfası için üç ayrı servise istek atıyoruz (kullanıcı, siparişler, öneriler). Ağ yerine gecikmeli sahte sunucu var; kodun şekli gerçek bir HTTP istemcisiyle aynıdır: `async fn` + `Result` + `?`.

```rust
pub async fn getir(yol: &str) -> Result<String, ApiHatasi> {
    let (gecikme, cevap) = match yol {
        "/kullanici/1" => (2, Ok("Ada")),
        "/kullanici/1/siparisler" => (4, Ok("3 sipariş")),
        "/kullanici/1/oneriler" => (3, Ok("klavye, fare")),
        "/bakim" => (1, Err(ApiHatasi::SunucuHatasi(503))),
        _ => (1, Err(ApiHatasi::Bulunamadi(yol.to_string()))),
    };
    Gecikme { kalan: gecikme }.await;
    cevap.map(String::from)
}

pub type KutuluFuture<'a, T> = Pin<Box<dyn Future<Output = T> + 'a>>;

pub async fn profil_eszamanli(id: u32) -> Result<String, ApiHatasi> {
    let yollar = [
        format!("/kullanici/{id}"),
        format!("/kullanici/{id}/siparisler"),
        format!("/kullanici/{id}/oneriler"),
    ];
    let gorevler: Vec<KutuluFuture<_>> = yollar
        .iter()
        .map(|yol| Box::pin(getir(yol)) as KutuluFuture<_>)
        .collect();
    let parcalar = hepsini_bekle(gorevler).await.into_iter()
        .collect::<Result<Vec<_>, _>>()?;
    Ok(parcalar.join(" | "))
}
```

1. `?` async fn içinde de aynen çalışır: `Err` gelirse future o noktada hata ile tamamlanır. Sıralı sürümde ilk başarısız istek beklemeyi keser; eşzamanlı sürümde sonuçlar toplandıktan sonra `collect::<Result<Vec<_>, _>>()` ilk `Err`'de durur.
   ↳ Kaynak: [Book ch09-02 — Recoverable Errors with Result](https://doc.rust-lang.org/book/ch09-02-recoverable-errors-with-result.html) · [Rustdoc — Iterator::collect](https://doc.rust-lang.org/std/iter/trait.Iterator.html#method.collect)

2. `&str` parametresi await boyunca ödünçte kalır; üretilen future bu referansı içinde taşır ve gizli bir ömür alır. Future'ı saklayacak ya da başka göreve vereceksen sahipli değer (ve `async move`) gerekir.
   ↳ Kaynak: [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html) · [rustc 1.99.1 — upvar.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_hir_typeck/src/upvar.rs)

3. Her `async fn` çağrısı farklı ve adsız bir tür üretir; `Vec` tek tür tutar. Bu yüzden `dyn Future`'a silinir; `dyn` boyutsuzdur (DST), kutu gerekir, poll için de Pin gerekir: `Pin<Box<dyn Future<Output = T> + 'a>>` kalıbı buradan gelir.
   ↳ Kaynak: [Nomicon — Sized](https://doc.rust-lang.org/nomicon/sized.html) · [rustc 1.99.1 — boxed.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/alloc/src/boxed.rs)

4. Sonuçlar görev **sırasıyla** döner, bitiş sırasıyla değil; çağıran için çıktı öngörülebilir olur. Ölçüm: `2 + 4 + 3 (+1) = 10` tura karşı `max(2, 4, 3) (+1) = 5` tur — aynı sonuç, yarı süre.
   ↳ Kaynak: [Book ch17-03 — More Futures](https://doc.rust-lang.org/book/ch17-03-more-futures.html) · [Rustdoc — Future](https://doc.rust-lang.org/std/future/trait.Future.html)

## Pin'in gündelik yüzü: `pin!` mi, `Box::pin` mi?

`.await` yazdığın sürece Pin'i görmezsin; derleyici alt future'ı senin yerine sabitler. Pin ancak bir future'ı elle poll ettiğinde ya da koleksiyonda sakladığında ortaya çıkar.

- `pin!(fut)` — bulunduğun kapsama/async fn'in durumuna sabitler; **tahsis yoktur**, ama değer o kapsamdan dışarı çıkamaz.
- `Box::pin(fut)` — heap'e koyup sabitler; bir tahsis maliyeti vardır, karşılığında kutuyu taşıyabilir ve `dyn Future`'a silebilirsin (taşınan kutudur, içindeki future değil).

↳ Kaynak: [Rustdoc — std::pin](https://doc.rust-lang.org/std/pin/index.html) · [Rustdoc — Box::pin](https://doc.rust-lang.org/std/boxed/struct.Box.html#method.pin) · [Book ch17-03 — More Futures](https://doc.rust-lang.org/book/ch17-03-more-futures.html)

## Sık yapılan hatalar

| Kod / durum | Hata | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| `fn main() { f().await; }` | **E0728** | Senkron/async geçişi tek noktada: `block_on` (tokio'da `#[tokio::main]`). | [Book ch17-02](https://doc.rust-lang.org/book/ch17-02-async-await.html) |
| `fn f() -> impl Future<Output=usize> { let s = String::from("a"); async { s.len() } }` | **E0373** | Blok tembeldir; `s` döndükten sonra ölür. `async move { s.len() }` kullan. | [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html) · [Rustdoc — Future](https://doc.rust-lang.org/std/future/trait.Future.html) |
| `async fn say(n: u32) -> u32 { say(n-1).await }` | **E0733** | State machine kendini içerir, sonsuz boyut olur; özyineli çağrıyı `Box::pin` ile kutula. | [Book ch17-03](https://doc.rust-lang.org/book/ch17-03-more-futures.html) · [Nomicon — Sized](https://doc.rust-lang.org/nomicon/sized.html) |
| Sabitlenmemiş `fut.poll(&mut cx)` | **E0599** | `help: consider pinning the expression`; `pin!` ya da `Box::pin`. | [Rustdoc — std::pin](https://doc.rust-lang.org/std/pin/index.html) |
| `let n: u32 = sayi_getir();` | **E0308** | Future beklenen `u32` değildir; `.await` ekle. | [Book ch17-01](https://doc.rust-lang.org/book/ch17-01-futures-and-syntax.html) |
| `async fn kotu() { thread::sleep(d); }` | derlenir, **yanlış çalışır** | Thread gerçekten uyur, diğer görevler durur; runtime'ın async zamanlayıcısını kullan. | [Book ch17-00](https://doc.rust-lang.org/book/ch17-00-async-await.html) |

## Derleyici perspektifi

- **`#[must_use]` uyarısı `compiler/rustc_lint/src/late.rs`'tedir.** Future üreten bir değer yok sayıldığında `unused implementer of Future that must be used` uyarısı çıkar; kod derlenir ve çalışır ama o satır hiçbir şey yapmaz.
  ↳ Kaynak: [rustc 1.99.1 — late.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_lint/src/late.rs) · [Rustdoc — Future](https://doc.rust-lang.org/std/future/trait.Future.html)

- **Tür silme ve DST.** `Vec<KutuluFuture<_>>`, `Pin<Box<dyn Future<Output=T> + 'a>>` kullanır: `dyn` boyutsuzdur, kutu sabit boyutlu işaretçi sağlar, Pin içindekinin yerinden oynamayacağını söyler.
  ↳ Kaynak: [Nomicon — Sized](https://doc.rust-lang.org/nomicon/sized.html) · [rustc 1.99.1 — boxed.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/alloc/src/boxed.rs)

- **Yakalama ve ömürler.** `rustc_hir_typeck/src/upvar.rs` async gövdelerin hangi çevresel değişkenleri yakaladığını belirler; referans yakalayan future'ın ömrü, çağıran onu canlı tuttuğu sürece uzanır.
  ↳ Kaynak: [rustc 1.99.1 — upvar.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_hir_typeck/src/upvar.rs) · [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html)

- **Poll sözleşmesi değişmez.** `Ready` dönmüş bir Future yeniden poll EDİLMEMELİDİR; `core/src/future/future.rs` ve `task/poll.rs` bu sözleşmenin tanımını taşır. Waker tabanlı uyandırma sayesinde busy-wait yoktur.
  ↳ Kaynak: [rustc 1.99.1 — future.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/future/future.rs) · [rustc 1.99.1 — poll.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/task/poll.rs)

## Özet ve sonraki adım

- Future tembeldir; çağırmak başlatmaz, `.await`/poll başlatır, düşürmek iptal eder.
- Bağımsız işlerde join benzeri birleştirici gerekir: sıralı 10 tur yerine eşzamanlı 5 tur.
- Pin yalnız elle poll ve saklamada görünür; `?`, `dyn Future` ve `async move` gündelik araçlardır.

Bir sonraki bölüm: [17. Nesne Yönelimli Özellikler](17-oop.md). Burada trait object'lerle çalışma anı polimorfizmini ve tür sistemiyle ifade edilen durumları göreceğiz.
