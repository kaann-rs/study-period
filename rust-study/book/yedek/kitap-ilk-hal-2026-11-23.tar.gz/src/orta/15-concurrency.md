# 15. Eşzamanlılık

> Kaynak crate: `learn/concurrency` · Çalıştır: `cargo run -p concurrency`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

## Neden bu bölüm?

Bir program işini birkaç kola bölebilir; tıpkı mutfakta birden fazla aşçının çalışması gibi. İki aşçı aynı tencereye aynı anda el atarsa yemek bozulur — programda buna veri yarışı denir ve Rust bunu derleme zamanında engeller. Bu bölümde iş parçacığı, kanal, kilit ve paylaşımlı sahipliğin dört temel aracını göreceğiz.

## 5 yaşındaki çocuğa anlatır gibi

Mutfağa üç aşçı girdi. Biri tuz atarken diğeri aynı tencereyi karıştırırsa yemek bozulur. Bu yüzden tencereyi alan önce "ben kullanıyorum" der, bitirince bırakır. Aşçılar birbirine not da geçebilir; notu kutuya koyar, öteki alır.

## Konu anlatımı (madde madde)

1. **Eşzamanlılık (concurrency) ile paralellik (parallelism) aynı şey değildir.** Eşzamanlılık birden çok işin aynı dönemde ilerlemesidir; paralellik ise gerçekten aynı anda, birden çok çekirdekte koşmaktır. Tek thread'de sırayla ilerleyen işler de eşzamanlı sayılır.
   ↳ Kaynak: [Book ch16-00 — Fearless Concurrency](https://doc.rust-lang.org/book/ch16-00-concurrency.html) · [Rust by Example — Threads](https://doc.rust-lang.org/rust-by-example/std_misc/threads.html)

2. **`thread::spawn` yeni bir iş parçacığı başlatır, `join` bitmesini bekler.** Closure içinde yazdığın kod ayrı bir kolda koşar; `JoinHandle::join()` thread'in sonucunu `Result` olarak döndürür (panik olduysa `Err`).
   ↳ Kaynak: [Book ch16-01 — Using Threads to Run Code Simultaneously](https://doc.rust-lang.org/book/ch16-01-threads.html) · [Rustdoc — thread::spawn](https://doc.rust-lang.org/std/thread/fn.spawn.html)

3. **Thread'e verilen closure çoğu zaman `move` ister.** Thread, onu doğuran fonksiyondan daha uzun yaşayabilir; ödünç alınan yerel veri sarkardı (dangling). `move` sahipliği closure'a geçirir, böylece veri sahibsiz kalmaz.
   ↳ Kaynak: [Book ch16-01 — move closures](https://doc.rust-lang.org/book/ch16-01-threads.html) · [Reference — Ownership and borrowing](https://doc.rust-lang.org/reference/ownership.html)

4. **Kanal (channel), veriyi thread'ler arasında taşır: "paylaşma, mesajlaş".** `mpsc` çok gönderen (multi-producer), tek alıcı (single-consumer) demektir; `tx.send(v)` değerin sahipliğini karşıya geçirir, `rx.recv()` alır.
   ↳ Kaynak: [Book ch16-02 — Using Message Passing to Transfer Data Between Threads](https://doc.rust-lang.org/book/ch16-02-message-passing.html) · [Rustdoc — std::sync::mpsc](https://doc.rust-lang.org/std/sync/mpsc/index.html)

5. **Kanal kapanışı sahiplikle olur.** `tx.clone()` ile birçok gönderen olabilir; alıcı `rx.iter()` döngüsü ancak bütün gönderenler düşünce biter. Orijinal `tx`'i `drop()` etmeyi unutursan program asılı kalır.
   ↳ Kaynak: [Book ch16-02 — mpsc Channel](https://doc.rust-lang.org/book/ch16-02-message-passing.html) · [Rustdoc — mpsc::Sender](https://doc.rust-lang.org/std/sync/mpsc/struct.Sender.html)

6. **Paylaşımlı durum `Arc<Mutex<T>>` ile kurulur.** `Arc` atomic sayaçlı paylaşımlı sahiplik verir; `Mutex<T>` veriyi kilidin arkasına koyar ve aynı anda yalnız bir thread'in girmesini sağlar. Arc "kaç sahip var", Mutex "şu anda kim erişir" sorularını ayrı ayrı çözer.
   ↳ Kaynak: [Book ch16-03 — Shared-State Concurrency](https://doc.rust-lang.org/book/ch16-03-shared-state.html) · [Rustdoc — Mutex](https://doc.rust-lang.org/std/sync/struct.Mutex.html)

7. **Kilit, `MutexGuard` düştüğünde otomatik bırakılır.** `lock()` bir guard döner; kapsam sonunda guard yok olunca kilit açılır (RAII). Kilidi tutan thread panik ederse Mutex "zehirlenir" (poison) ve sonraki `lock()` `Err` döner.
   ↳ Kaynak: [rustc 1.99.1 — poison/mutex.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/std/src/sync/poison/mutex.rs) · [Book ch16-03 — Poisoning](https://doc.rust-lang.org/book/ch16-03-shared-state.html)

8. **Derleyici iki görünmez etiket arar: `Send` ve `Sync`.** `Send` "tür başka thread'e güvenle taşınabilir", `Sync` "aynı türe birden çok thread'den güvenle bakılabilir" demektir. İkisi de `unsafe auto trait`'tir; alanları uygunsa derleyici bunları kendiliğinden uygular.
   ↳ Kaynak: [Book ch16-04 — Extensible Concurrency with Sync and Send](https://doc.rust-lang.org/book/ch16-04-extensible-concurrency-sync-and-send.html) · [rustc 1.99.1 — marker.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/marker.rs)

9. **`Rc` thread'ler arasına geçemez, `Arc` geçer.** Rc'nin sayacı atomik olmadığı için iki thread aynı anda klonlayıp düşürürse sayaç bozulur; bu yüzden Rc bilinçli olarak `!Send`'dir. Arc aynı API'yi atomik sayaçla sunar (uygulama `library/alloc/src/rcs/arc.rs`'tedir; `sync.rs` yeniden dışa aktarır).
   ↳ Kaynak: [Rustdoc — Arc](https://doc.rust-lang.org/std/sync/struct.Arc.html) · [rustc 1.99.1 — rcs/arc.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/alloc/src/rcs/arc.rs) · [Book ch16-04](https://doc.rust-lang.org/book/ch16-04-extensible-concurrency-sync-and-send.html)

10. **Rust veri yarışını önler, deadlock'u önlemez.** Veri yarışı "paylaşımlı + değiştirilebilir + eşzamanlamasız erişim"tir; Aliasing XOR Mutability kuralı thread sınırına da taşınır. İki thread'in birbirinin kilidini sonsuza dek beklemesi ise çalışma anı mantık hatasıdır ve derleyiciyi ilgilendirmez.
    ↳ Kaynak: [Book ch16-00 — Fearless Concurrency](https://doc.rust-lang.org/book/ch16-00-concurrency.html) · [Nomicon — Aliasing](https://doc.rust-lang.org/nomicon/aliasing.html) · *Rust Atomics and Locks* (kitap)

## Kodda nasıl görünür?

```rust
use std::sync::mpsc;
use std::sync::{Arc, Mutex};
use std::thread;

fn threadler() {
    let veri = vec![1, 2, 3];
    // move: sahiplik thread'e geçer — ödünç olsa dangling olurdu.
    let tutamac = thread::spawn(move || veri.iter().sum::<i32>());
    let sonuc = tutamac.join().unwrap(); // bitmesini bekle, sonucu al
    println!("thread topladı = {sonuc}");
}

fn kanallar() {
    let (tx, rx) = mpsc::channel();
    for id in 0..3 {
        let tx = tx.clone();
        thread::spawn(move || {
            tx.send(format!("thread {id} selam")).unwrap();
        });
    }
    drop(tx); // bütün gönderenler kapanmazsa rx.iter() bitmez
    let mut mesajlar: Vec<String> = rx.iter().collect();
    mesajlar.sort(); // varış sırası belirsiz
    println!("kanaldan gelenler (sıralı): {mesajlar:?}");
}

fn paylasimli_durum() {
    let sayac = Arc::new(Mutex::new(0));
    let mut tutamaclar = vec![];
    for _ in 0..10 {
        let sayac = Arc::clone(&sayac);
        tutamaclar.push(thread::spawn(move || {
            let mut n = sayac.lock().unwrap(); // guard: çıkınca kilit açılır
            *n += 1;
        }));
    }
    for t in tutamaclar {
        t.join().unwrap();
    }
    println!("Arc<Mutex> sayaç = {}", *sayac.lock().unwrap()); // 10
}
```

## Sık yapılan hatalar

| Kod / durum | Hata | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| `println!("{m:?}")` — Arc klonlanmadan thread'e taşındıktan sonra | **E0382** | `Arc` `Copy` değildir; taşımadan önce `Arc::clone(&m)` yap. | [Book ch16-03](https://doc.rust-lang.org/book/ch16-03-shared-state.html) · [Rustdoc — Arc](https://doc.rust-lang.org/std/sync/struct.Arc.html) |
| `Arc::new(vec![1])` içinde `v.push(2)` | **E0596** | Arc yalnız `&T` verir; değişim için `Arc<Mutex<Vec<_>>>` kullan. | [Book ch16-03](https://doc.rust-lang.org/book/ch16-03-shared-state.html) · [Rustdoc — Mutex](https://doc.rust-lang.org/std/sync/struct.Mutex.html) |
| `thread::spawn(move || …)` içinde `Rc` yakalamak | **E0277** | `Rc` `Send` değil; atomik sayaçlı `Arc`'e geç. | [Book ch16-04](https://doc.rust-lang.org/book/ch16-04-extensible-concurrency-sync-and-send.html) · [marker.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/marker.rs) |
| `kapsam.spawn(move \|\| println!("{}", *g))` — `MutexGuard` taşınıyor | **E0277** | `MutexGuard` `!Send`'dir; kilidi veriye dokunacak thread'in içinde al. | [poison/mutex.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/std/src/sync/poison/mutex.rs) · [Book ch16-03](https://doc.rust-lang.org/book/ch16-03-shared-state.html) |
| `tx.send(mesaj); println!("{mesaj}");` | **E0382** | `send` sahipliği alıcıya taşır; gönderdikten sonra o veri artık sende değil. | [Book ch16-02](https://doc.rust-lang.org/book/ch16-02-message-passing.html) |
| İki thread, iki kilidi ters sırayla alıyor | derlenir, çalışma anı **deadlock** | Rust veri yarışını önler, kilit sırasını denetlemez; her yerde aynı sırayla al. | [Book ch16-03](https://doc.rust-lang.org/book/ch16-03-shared-state.html) · *Rust Atomics and Locks* (kitap) |

## Derleyici perspektifi

- **`Send` ve `Sync` `unsafe auto trait`'tir.** `library/core/src/marker.rs` içinde tanımlıdırlar; derleyici tüm alanları uygun olan bir türe bunları otomatik uygular. `thread::spawn`'a verilen closure'ın yakaladığı her şey `Send` olmak zorundadır.
  ↳ Kaynak: [rustc 1.99.1 — marker.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/marker.rs) · [Book ch16-04](https://doc.rust-lang.org/book/ch16-04-extensible-concurrency-sync-and-send.html)

- **Rc'nin sayacı atomik değildir.** İki thread'in eşzamanlı `clone`/drop'u sayacı bozup erken serbest bırakmaya ya da sızıntıya yol açar; bu yüzden `E0277` derleme hatası alınır. Arc aynı işi atomik sayaçla yapar; gerçek uygulama `library/alloc/src/rcs/arc.rs`'tedir (`sync.rs` yeniden dışa aktarır).
  ↳ Kaynak: [rustc 1.99.1 — rcs/arc.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/alloc/src/rcs/arc.rs) · [Book ch15-04 — `Rc<T>`](https://doc.rust-lang.org/book/ch15-04-rc.html)

- **Mutex kilit + veriyi birlikte tutar.** `library/std/src/sync/poison/mutex.rs` içindeki `lock()` bir `MutexGuard` döner; guard'ın `Drop'`u kilidi bırakır. Panik durumunda "poison" işareti konur, sonraki `lock()` `Err` verir.
  ↳ Kaynak: [rustc 1.99.1 — poison/mutex.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/std/src/sync/poison/mutex.rs) · [Reference — Destructors](https://doc.rust-lang.org/reference/destructors.html)

- **Thread sınırı, ödünç kuralının uzantısıdır.** Aliasing XOR Mutability tek thread'de de geçerlidir; `Send`/`Sync` bu denetimi thread sınırına taşır. ihlal derleme hatasıdır, deadlock ve mantıksal yarış değil.
  ↳ Kaynak: [Nomicon — Aliasing](https://doc.rust-lang.org/nomicon/aliasing.html) · [Reference — Ownership](https://doc.rust-lang.org/reference/ownership.html)

## Özet ve sonraki adım

- `spawn` + `join` işi böler; `move` sahipliği thread'e geçirir, kanal veriyi taşır.
- `Arc<Mutex<T>>` yerinde paylaşım sağlar; `Send`/`Sync` etiketleri veri yarışını derlemede engeller.
- Poison, deadlock ve kilit çekişmesi derleyicinin kapsamı dışındaki çalışma anı meseleleridir.

Bir sonraki sayfada [15.1 Eşzamanlılık: Derinleşme](15-concurrency-derinlesme.md) bölümünde `thread::scope`, işçi havuzu, kısa kritik bölge ve atomik sayaçları göreceğiz.
