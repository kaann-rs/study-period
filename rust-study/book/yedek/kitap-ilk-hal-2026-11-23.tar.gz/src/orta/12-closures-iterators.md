# 12. Closure ve Iterator'lar

> Kaynak crate: `learn/closures-iterators` · Çalıştır: `cargo run -p closures-iterators`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

## Neden bu bölüm?

Bir listedeki her sayının karesini almak ya da yalnızca bazılarını seçmek için her seferinde uzun döngüler yazmak yorar. Closure, o küçük işi yazıldığı yerdeki değişkenlerle birlikte taşır; iterator ise elemanları tek tek, istendikçe verir. Kargo şubesinin görev notları ile taşıma bandı gibi: not hatırlar, bant paketleri getirir, istasyonlar dönüştürür.

## 5 yaşındaki çocuğa anlatır gibi

Önce bir not yaz: "kırmızı olanları ayır". Not cebinde durur, hatırlar. Sonra taşıma bandı paketleri tek tek önünden geçirir; sen kırmızıları alırsın, mavileri geçersin. En sonda hepsini bir kutuya koyarsın.

## Konu anlatımı (madde madde)

1. **Closure, ortamını yakalayan adsız fonksiyondur.** `|parametreler| gövde` biçiminde yazılır ve türler çoğunlukla çıkarılır. Sıradan `fn` yalnızca kendisine parametre olarak verileni görür; closure yazıldığı yerdeki değişkenleri de kullanabilir.
   ↳ Kaynak: [Book ch13-01 — Closures](https://doc.rust-lang.org/book/ch13-01-closures.html) · [Book ch13-00 — Functional Language Features](https://doc.rust-lang.org/book/ch13-00-functional-features.html)

2. **Üç yakalama biçimi vardır: paylaşımlı ödünç, değiştiren ödünç ve `move`.** Yalnız okuyan closure `&` ile, değiştiren `&mut` ile (closure'ın kendisi de `mut` olur) yakalar; `move` değeri içine taşır. Derleyici gövdeye bakarak karar verir ve gerektiğinden fazlasını almaz; `move` yazarsan sahipliği sen zorlarsın.
   ↳ Kaynak: [Book ch13-01 — Capturing the Environment with Closures](https://doc.rust-lang.org/book/ch13-01-closures.html) · [rustc 1.99.1 — upvar.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_hir_typeck/src/upvar.rs)

3. **Gövde `Fn`, `FnMut` veya `FnOnce` trait'ini belirler.** `Fn` yakalananı yalnız okur, `FnMut` değiştirir, `FnOnce` **en fazla bir kez** çağrılabilir çünkü yakalananı dışarı taşıyabilir. Her closure ayrıca `FnOnce` trait'ini uygular (`Fn ⊂ FnMut ⊂ FnOnce`); trait seçimi borrow davranışının doğrudan yansımasıdır.
   ↳ Kaynak: [Rustdoc — FnOnce](https://doc.rust-lang.org/std/ops/trait.FnOnce.html) · [rustc 1.99.1 — core/src/ops/function.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/ops/function.rs) · [Book ch13-01](https://doc.rust-lang.org/book/ch13-01-closures.html)

4. **API yazarken işi gören en gevşek trait istenir.** `FnOnce` en gevşek kısıttır ve sonucu döndürebilir; `Fn` en katıdır ve closure'ı birden çok kez paylaşımlı çağırır. `FnMut` tutan bir closure, `Fn` bekleyen bir fonksiyona verilemez; kısıtı imzaya taşımak yetkiyi görünür kılar.
   ↳ Kaynak: [Rustdoc — FnMut](https://doc.rust-lang.org/std/ops/trait.FnMut.html) · [Book ch13-01 — Closures as Parameters](https://doc.rust-lang.org/book/ch13-01-closures.html)

5. **Iterator'ın tek zorunlu metodu `next()`tir.** Sıradaki eleman varsa `Some(eleman)`, bittiyse `None` döner. `map`, `filter`, `sum`, `zip` gibi yüzlerce metot bu tek metodun üstüne kurulmuş varsayılan metotlardır.
   ↳ Kaynak: [Book ch13-02 — Iterators](https://doc.rust-lang.org/book/ch13-02-iterators.html) · [rustc 1.99.1 — iterator.rs:78](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/iter/traits/iterator.rs#L78)

6. **Adaptörler tembeldir (lazy), tüketici çalıştırır.** `map` ve `filter` yeni bir iterator döndürür, iş yapmaz; zincir ancak `collect`, `sum` veya `for` gibi bir tüketici `next()` çağırmaya başlayınca akar. Tüketmezsen derleyici "iterators are lazy" / `must_use` uyarısı verir (DOĞRULANDI).
   ↳ Kaynak: [Book ch13-02 — Processing a Series of Items with Iterators](https://doc.rust-lang.org/book/ch13-02-iterators.html) · [rustc 1.99.1 — late.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_lint/src/late.rs)

7. **`iter`, `iter_mut`, `into_iter` sahiplik açısından ayrılır.** Sırasıyla `&T`, `&mut T` ve `T` verir; ilk ikisinde koleksiyon yerinde kalır, `into_iter` sahipliği devralır ve koleksiyonu tüketir. Bu ayrım closure'ın üç yakalama biçimiyle aynıdır: bak, değiştir, sahiplen.
   ↳ Kaynak: [Book ch13-02 — The `into_iter` Method](https://doc.rust-lang.org/book/ch13-02-iterators.html) · [Rustdoc — IntoIterator](https://doc.rust-lang.org/std/iter/trait.IntoIterator.html)

8. **Kendi iterator'ını yazmak için yalnız `next()` gerekir.** `impl Iterator` içinde `type Item` ve `fn next(&mut self) -> Option<Self::Item>` yazınca `map`/`filter`/`sum`/`zip` varsayılan metotlar olarak hazır gelir; tek satır bile yazmana gerek kalmaz.
   ↳ Kaynak: [Rustdoc — Iterator](https://doc.rust-lang.org/std/iter/trait.Iterator.html) · [Book ch13-02 — Creating Our Own Iterators](https://doc.rust-lang.org/book/ch13-02-iterators.html)

9. **Edition 2021+ ile yakalama ayrık (disjoint) yapılır.** Closure `s.a` alanını kullanıyorsa tüm `s`'i değil yalnız o alanı yakalar; bu gereksiz borrow çakışmalarını azaltır. Karar `rustc_hir_typeck/src/upvar.rs` içinde verilir.
   ↳ Kaynak: [rustc 1.99.1 — upvar.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_hir_typeck/src/upvar.rs) · [Book ch13-01](https://doc.rust-lang.org/book/ch13-01-closures.html)

10. **Performans nitelendirmesi: "çoğu zaman" sıfır maliyet.** Adaptörler generiktir; optimize derlemelerde (ör. `--release`) LLVM inline ile zincir çoğu zaman elle yazılmış bir döngüyle aynı koda iner. `opt-level = 0` derlemesinde dolaylama kalabilir; "aynı makine kodu" garanti değildir ve bu karşılaştırma için assembly ölçümü yapılmadı (DOĞRULANAMADI).
    ↳ Kaynak: [Book ch13-04 — Performance](https://doc.rust-lang.org/book/ch13-04-performance.html) · [rustc 1.99.1 — collector.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_monomorphize/src/collector.rs)

## Kodda nasıl görünür?

```rust
// learn/closures-iterators/src/main.rs — ilgili satırlar (özet)
fn closurelar() {
    let kare = |x: i32| x * x;
    println!("kare(5) = {}", kare(5));

    let liste = vec![1, 2, 3];
    let yazdir = || println!("yakaladı (&): {liste:?}");
    yazdir();
    yazdir(); // & yakaladığı için birden çok kez çağrılabilir; liste hâlâ kullanılabilir
    println!("liste hâlâ burada: {liste:?}");

    let mut sayac = vec![1, 2, 3];
    let mut ekle = || sayac.push(4);
    ekle();
    println!("ekle sonrası: {sayac:?}");
}

fn uygula_fn<F: Fn()>(f: F) {
    f();
    f();
}
fn hesapla_sonra_calistir<F: FnOnce() -> i32>(f: F) -> i32 {
    f()
}

fn iteratorlar() {
    let v = vec![1, 2, 3, 4, 5];
    let mut it = v.iter();
    println!("next: {:?} {:?}", it.next(), it.next()); // Some(1) Some(2)

    let sonuc: Vec<i32> = v
        .iter() // &i32 verir
        .map(|x| x * 2) // adaptör: her öğeyi dönüştür (tembel)
        .filter(|x| x % 3 != 0) // adaptör: ele (tembel)
        .collect(); // TÜKETİCİ: şimdi gerçekten çalışır
    println!("map+filter+collect: {sonuc:?}"); // [2, 4, 8, 10]
}
```

## Sık yapılan hatalar

1. **`move` sonrası yakalananı kullanmak (`E0382`).** `let tasi = move || println!("{sahip}");` yazınca `sahip` closure'a taşınır; dışarıdan `println!("{sahip}")` yazılmaz. Paylaşımlı ödünçle yakala ya da sahipliği açıkça geri al.
   ↳ Kaynak: [Book ch13-01](https://doc.rust-lang.org/book/ch13-01-closures.html) · [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs)

2. **`FnMut` closure'ı `Fn` bekleyen yere vermek (`E0525`).** Değiştiren closure paylaşımlı çağrılamaz; API yazıyorsan imzayı `FnMut` (ya da uygunsa `FnOnce`) olacak şekilde gevşet.
   ↳ Kaynak: [Rustdoc — FnMut](https://doc.rust-lang.org/std/ops/trait.FnMut.html) · [Book ch13-01](https://doc.rust-lang.org/book/ch13-01-closures.html)

3. **Yereli ödünç alan closure'ı fonksiyondan döndürmek (`E0373`).** Closure, fonksiyon bitince yok olacak bir değişkene bakıyor olabilir; `move` ile yakaladığını içine taşı.
   ↳ Kaynak: [Book ch13-01 — Moving Captured Values Out of the Closure](https://doc.rust-lang.org/book/ch13-01-closures.html) · [rustc 1.99.1 — upvar.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_hir_typeck/src/upvar.rs)

4. **Zinciri tüketmemek (`must_use` / "iterators are lazy" uyarısı).** `v.iter().map(|x| println!("{x}"));` hiçbir şey yazdırmaz. Sonuç istiyorsan `collect`/`sum`, yan etki istiyorsan `for` veya `for_each` kullan.
   ↳ Kaynak: [Book ch13-02](https://doc.rust-lang.org/book/ch13-02-iterators.html) · [rustc 1.99.1 — late.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_lint/src/late.rs)

5. **`collect()` hedef türsüz (`E0283`).** Aynı elemanlardan `Vec`, `String` gibi birçok kap kurulabilir; değişkenin türünü yaz (`let v: Vec<i32> = ...collect()`) ya da turbofish kullan (`collect::<Vec<_>>()`).
   ↳ Kaynak: [Rustdoc — Iterator::collect](https://doc.rust-lang.org/std/iter/trait.Iterator.html#method.collect) · [Rustdoc — FromIterator](https://doc.rust-lang.org/std/iter/trait.FromIterator.html)

## Derleyici perspektifi

- **Closure = veri + kod.** Derleyici her closure için yakaladığı değişkenleri alan olarak tutan isimsiz bir struct üretir ve ona `Fn`/`FnMut`/`FnOnce` uygular; capture mode kararını `rustc_hir_typeck/src/upvar.rs` verir.
  ↳ Kaynak: [rustc 1.99.1 — upvar.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_hir_typeck/src/upvar.rs) · [Book ch13-01](https://doc.rust-lang.org/book/ch13-01-closures.html)

- **Trait seçimi gövdeden gelir.** Yakalananı dışarı taşıyan gövde yalnız `FnOnce` olur (ikinci çağrı `E0382`); değiştiren `FnMut`, yalnız okuyan `Fn` üretir. Böylece aliasing + mutation kuralı tür düzeyinde korunur.
  ↳ Kaynak: [rustc 1.99.1 — core/src/ops/function.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/ops/function.rs) · [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs)

- **`next` imzası sabittir.** `fn next(&mut self) -> Option<Self::Item>` (`library/core/src/iter/traits/iterator.rs:78`); `map`/`filter`/`sum`/`zip` bu metodun üstündeki varsayılan metotlardır.
  ↳ Kaynak: [rustc 1.99.1 — iterator.rs:78](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/iter/traits/iterator.rs#L78) · [Rustdoc — Iterator](https://doc.rust-lang.org/std/iter/trait.Iterator.html)

- **Tembellik gerçek işi tüketiciye bırakır.** Adaptörler yeni iterator struct'ı döndürür; zincir `collect`/`sum`/`for` `next()` çağırınca akar. Tüketmeyen zincir için `must_use` uyarısı DOĞRULANDI.
  ↳ Kaynak: [Book ch13-02](https://doc.rust-lang.org/book/ch13-02-iterators.html) · [rustc 1.99.1 — late.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_lint/src/late.rs)

- **Maliyet çoğu zaman optimize edilir.** Monomorphization closure'ı somutlaştırır, `--release` içinde LLVM inline uygular; `opt-level = 0` derlemesinde dolaylama kalabilir. "Elle yazılmış döngüyle aynı makine kodu" iddiası için ölçüm yapılmadı (DOĞRULANAMADI).
  ↳ Kaynak: [rustc 1.99.1 — collector.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_monomorphize/src/collector.rs) · [Book ch13-04 — Performance](https://doc.rust-lang.org/book/ch13-04-performance.html)

> **Doğruluk notu:** "Iterator zinciri runtime'da hiç ek yük getirmez" iddiası mutlaktır. Book ch13-04 "in many cases" der; optimize derlemelerde çoğu zaman aynı koda iner, `opt-level = 0` derlemesinde dolaylama kalabilir. Assembly ölçümü bu oturumda yapılmadı (DOĞRULANAMADI).
> ↳ Kaynak: [Book ch13-04 — Performance](https://doc.rust-lang.org/book/ch13-04-performance.html) · [Cargo profiles](https://doc.rust-lang.org/cargo/reference/profiles.html)

## Özet ve sonraki adım

- Closure ortamını yakalar; gövde `Fn`/`FnMut`/`FnOnce` seçimini belirler. `FnOnce` **en fazla bir kez** çağrılabilir.
- Iterator tembeldir: adaptörler zinciri kurar, tüketici çalıştırır; `next()` tek zorunlu metottur.
- Performans çoğu zaman sıfır maliyetlidir; "aynı makine kodu" garanti değildir.

Bir sonraki sayfada [12.1 Closure ve Iterator'lar: Derinleşme](12-closures-iterators-derinlesme.md) bölümünde gövde–trait ilişkisini gerçek bir sipariş veri hattında ve beş klasik borrow hatasının çözümünde göreceğiz.
