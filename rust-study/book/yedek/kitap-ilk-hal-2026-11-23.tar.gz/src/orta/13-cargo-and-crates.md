# 13. Cargo ve Crate'ler

> Kaynak crate: `learn/cargo-and-crates` · Çalıştır: `cargo run -p cargo-and-crates`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

## Neden bu bölüm?

Kodunu yazıp bitirdikten sonra onu başkalarının da kullanabileceği bir pakete çevirmen gerekir. Cargo bu paketi derler, test eder, dokümanını üretir ve sürümlerini yönetir. Bu crate'te küçük bir renk karıştırma kütüphanesi var: kılavuz kodun içinde yazılı, kılavuzdaki örnekler test olarak koşar ve iç raflar `pub use` ile önden kısa bir kapıya bağlanır.

## 5 yaşındaki çocuğa anlatır gibi

Boya seti alıyorsun. Kapağında nasıl kullanılacağı yazılı; yazan örnekleri denemek de mümkün. İçinde onlarca göz var ama sen sadece "karıştır" düğmesine basıyorsun. Kimin hangi gözü açtığını bilmen gerekmiyor.

## Konu anlatımı (madde madde)

1. **Package (paket) ile crate ayrıdır.** Package bir `Cargo.toml` ile tanımlanan kutudur; crate ise derlenen birimdir — ya bir kütüphane (`lib.rs`) ya da bir program (`main.rs`). Bu örnekte ikisi bir aradadır: `main` kütüphaneyi kullanır.
   ↳ Kaynak: [Book ch07-01 — Packages and Crates](https://doc.rust-lang.org/book/ch07-01-packages-and-crates.html) · [Book ch14-00 — More About Cargo](https://doc.rust-lang.org/book/ch14-00-more-about-cargo.html)

2. **`Cargo.toml` ayarları, `Cargo.lock` kesin sürümleri tutar.** Bağımlılık sürümleri lock dosyasında sabitlenir; böylece aynı workspace'i kullanan herkes aynı sürümü alır. crates.io paketlerin yayımlandığı, docs.rs dokümanların yayımlandığı yerdir.
   ↳ Kaynak: [Book ch07-01 — The Cargo.toml File](https://doc.rust-lang.org/book/ch07-01-packages-and-crates.html) · [Book ch14-02 — Publishing to crates.io](https://doc.rust-lang.org/book/ch14-02-publishing-to-crates-io.html)

3. **Bu repo bir workspace'tir.** Kök `Cargo.toml` üyeleri `members`/`exclude` ile toplar; tüm crate'ler tek `target/` ve tek `Cargo.lock` paylaşır. Ortak bağımlılık bir kez derlenir, sürümler tutarlı kalır.
   ↳ Kaynak: [Book ch14-03 — Cargo Workspaces](https://doc.rust-lang.org/book/ch14-03-cargo-workspaces.html) · [Book ch14-00 — More About Cargo](https://doc.rust-lang.org/book/ch14-00-more-about-cargo.html)

4. **`//!` içinde bulunduğu öğeyi, `///` kendisinden sonrakini belgeler.** İkisi de Markdown'dır; `cargo doc` bunu HTML'e çevirir. Bu dosyanın başındaki `//!` crate'in tamamını, `karistir`ın üstündeki `///` o fonksiyonu anlatır.
   ↳ Kaynak: [Book ch14-02 — Documenting Your API](https://doc.rust-lang.org/book/ch14-02-publishing-to-crates-io.html) · [Book ch14-02 — Documentation as Tests](https://doc.rust-lang.org/book/ch14-02-publishing-to-crates-io.html)

5. **Doc-test, kılavuzdaki örnek kodun gerçekten koşmasıdır.** `///` içindeki üç ters tırnak bloğu `cargo test` tarafından ayrı bir program olarak derlenip çalıştırılır. Kod değişip örnek eski kalırsa test düşer; kılavuz ile kod birbirinden ayrı düşemez.
   ↳ Kaynak: [Book ch14-02 — Documentation as Tests](https://doc.rust-lang.org/book/ch14-02-publishing-to-crates-io.html) · [Book ch11-01 — Writing Tests](https://doc.rust-lang.org/book/ch11-01-writing-tests.html)

6. **`pub use` içerideki öğeyi gizlemez, ona ek bir kapı açar.** `pub use islem::karistir;` ve `pub use turler::{BirincilRenk, IkincilRenk};` sayesinde kullanıcı kökten `use cargo_and_crates::{BirincilRenk, karistir};` yazabilir. Uzun yol (`cargo_and_crates::turler::BirincilRenk`) da çalışmaya devam eder: iç düzen ile public API ayrışır.
   ↳ Kaynak: [Book ch07-04 — `pub use` for Re-exporting](https://doc.rust-lang.org/book/ch07-04-bringing-paths-into-scope-with-the-use-keyword.html) · [Book ch07-02 — Modules](https://doc.rust-lang.org/book/ch07-02-defining-modules-to-control-scope-and-privacy.html)

7. **Rust'ta 5 namespace vardır: Type, Value, Macro, Lifetime, Label.** "İki namespace" ya da "üç namespace" yanlıştır; bu örnekte çakışmayı önleyenler **TÜR** ve **DEĞER** namespace'leridir. Makro namespace'i de önemlidir, ama sayı üç değildir. `pub use` bir öğeyi bu namespace'lerde görünür kılar.
   ↳ Kaynak: [Reference — namespaces](https://doc.rust-lang.org/reference/names/namespaces.html) · [rustc-dev-guide — name resolution](https://rustc-dev-guide.rust-lang.org/name-resolution.html)

8. **Profiller derleme ayar takımıdır.** `cargo build` = dev profili (`opt-level = 0`, hızlı derleme), `cargo build --release` = release profili (`opt-level = 3`, yavaş derleme, hızlı kod). `opt-level` yalnız `0–3` değil, boyut için `"s"` ve `"z"` değerlerini de alır.
   ↳ Kaynak: [Book ch14-01 — Release Profiles](https://doc.rust-lang.org/book/ch14-01-release-profiles.html) · [Cargo reference — opt-level](https://doc.rust-lang.org/cargo/reference/profiles.html#opt-level)

9. **Profil ayarları workspace köküne yazılır.** `[profile.dev]` / `[profile.release]` üye crate'in `Cargo.toml`'unda yazılırsa yok sayılır ya da uyarı verir; bu yüzden ayarlar kökte durur. Ölçümler hep `--release` ile yapılır, dev ikilisi gerçek hızı yansıtmaz.
   ↳ Kaynak: [Book ch14-01 — Release Profiles](https://doc.rust-lang.org/book/ch14-01-release-profiles.html) · [Book ch14-03 — Cargo Workspaces](https://doc.rust-lang.org/book/ch14-03-cargo-workspaces.html)

10. **İki test birlikte koşar.** `cargo test -p cargo-and-crates` hem `#[cfg(test)] mod testler` içindeki birim testleri hem de doc-test'leri çalıştırır. `cargo doc -p cargo-and-crates --open` dokümanı tarayıcıda açar; `cargo install` ise bir ikiliyi `~/.cargo/bin`'e kurar.
    ↳ Kaynak: [Book ch11-03 — Test Organization](https://doc.rust-lang.org/book/ch11-03-test-organization.html) · [Book ch14-02 — Documentation as Tests](https://doc.rust-lang.org/book/ch14-02-publishing-to-crates-io.html) · [Book ch14-00 — More About Cargo](https://doc.rust-lang.org/book/ch14-00-more-about-cargo.html)

## Kodda nasıl görünür?

```rust
// learn/cargo-and-crates/src/main.rs — kütüphaneyi KÖK'ten (pub use sayesinde) kullanıyoruz
use cargo_and_crates::{BirincilRenk, karistir};

fn main() {
    for (a, b) in [
        (BirincilRenk::Kirmizi, BirincilRenk::Sari),
        (BirincilRenk::Sari, BirincilRenk::Mavi),
        (BirincilRenk::Kirmizi, BirincilRenk::Mavi),
        (BirincilRenk::Mavi, BirincilRenk::Mavi),
    ] {
        println!("{a:?} + {b:?} = {:?}", karistir(a, b));
    }
    println!("(doküman: cargo doc -p cargo-and-crates --open · testler: cargo test -p cargo-and-crates)");
}

// learn/cargo-and-crates/src/lib.rs — kılavuzun kendisi testtir (doc-test)
/// İki birincil rengi karıştırıp ikincil rengi döndürür.
///
/// Aynı renk iki kez verilirse `None` döner (karışım tanımsız).
/// ```
/// use cargo_and_crates::{BirincilRenk, IkincilRenk, karistir};
/// assert_eq!(karistir(BirincilRenk::Kirmizi, BirincilRenk::Sari), Some(IkincilRenk::Turuncu));
/// assert_eq!(karistir(BirincilRenk::Mavi, BirincilRenk::Mavi), None);
/// ```
pub fn karistir(a: BirincilRenk, b: BirincilRenk) -> Option<IkincilRenk> { /* ... */ }

// ---- pub use: YENİDEN DIŞA AKTARMA ----
pub use islem::karistir;
pub use turler::{BirincilRenk, IkincilRenk};
```

## Sık yapılan hatalar

1. **`pub use` iç modülü gizler sanmak.** Gizlemez: `cargo_and_crates::turler::BirincilRenk` hâlâ çalışır, üstüne kısa yol eklenir. "`use cargo_and_crates::Mor;`" ise kökte böyle bir öğe olmadığı için derlenmez.
   ↳ Kaynak: [Book ch07-04 — `pub use` for Re-exporting](https://doc.rust-lang.org/book/ch07-04-bringing-paths-into-scope-with-the-use-keyword.html) · [Reference — Visibility and privacy](https://doc.rust-lang.org/reference/visibility-and-privacy.html)

2. **`opt-level` yalnız `0–3`'tür sanmak.** Eksik: boyut için `"s"` ve `"z"` de geçerlidir. Derleme süresi ile çalışma hızı arasındaki denge bu değerle kurulur.
   ↳ Kaynak: [Cargo reference — opt-level](https://doc.rust-lang.org/cargo/reference/profiles.html#opt-level) · [Book ch14-01 — Release Profiles](https://doc.rust-lang.org/book/ch14-01-release-profiles.html)

3. **Profil ayarını üye crate'e koymak.** Workspace'te ayar kök `Cargo.toml`'da olmalı; üyede yazılan yok sayılır/uyarı verir. Bu yüzden örnek crate profil ayarı içermez.
   ↳ Kaynak: [Book ch14-03 — Cargo Workspaces](https://doc.rust-lang.org/book/ch14-03-cargo-workspaces.html) · [Book ch14-01 — Release Profiles](https://doc.rust-lang.org/book/ch14-01-release-profiles.html)

4. **Doc-test'i "sadece yorum" sanmak.** Üç ters tırnak içindeki kod `cargo test`te koşar; `assert_eq!` düşerse ya da kod derlenmezse test başarısız olur. Kılavuz ile kod senkron kalmaya zorlanır.
   ↳ Kaynak: [Book ch14-02 — Documentation as Tests](https://doc.rust-lang.org/book/ch14-02-publishing-to-crates-io.html)

5. **Namespace sayısını iki ya da üç sanmak.** Reference Type, Value, Macro, Lifetime, Label olmak üzere **5** namespace sayar; "üç" düzeltmesi de yanlıştır.
   ↳ Kaynak: [Reference — namespaces](https://doc.rust-lang.org/reference/names/namespaces.html) · [rustc-dev-guide — name resolution](https://rustc-dev-guide.rust-lang.org/name-resolution.html)

## Derleyici perspektifi

- **Doc-test'in mekaniği:** rustdoc `///` içindeki kod bloklarını toplar, her birini ayrı bir crate olarak derleyip çalıştırır. Bu örnekte `main` yazılmamıştır; doc-test onu sarar. `cargo test -p cargo-and-crates` bu oturumda çalıştırılmadı; kaynak dosyadaki "doğrulandı" notu önceki denetimlere aittir (DOĞRULANAMADI).
  ↳ Kaynak: [Book ch14-02 — Documentation as Tests](https://doc.rust-lang.org/book/ch14-02-publishing-to-crates-io.html) · [Book ch11-01 — Writing Tests](https://doc.rust-lang.org/book/ch11-01-writing-tests.html)

- **`//!` / `///` ayrımı** yalnız yorum stili değil, bağlama kararıdır: biri dosyanın (crate'in) içine, öteki sonraki öğeye bağlanır. İkisi de Markdown; `cargo doc` HTML üretir ve docs.rs bunu otomatik yayımlar.
  ↳ Kaynak: [Book ch14-02 — Documenting Your API](https://doc.rust-lang.org/book/ch14-02-publishing-to-crates-io.html) · [Book ch14-02 — Publishing to crates.io](https://doc.rust-lang.org/book/ch14-02-publishing-to-crates-io.html)

- **`pub use` bir yeniden dışa aktarmadır (re-export).** İç modül düzeni senin işindir; kullanıcı ezberlemesin. İsim çözümlemesi `rustc_resolve` aşamasında yapılır; görünürlüğün kendisi ayrı bir denetimdir. Namespace'ler Type/Value/Macro/Lifetime/Label olmak üzere beştir.
  ↳ Kaynak: [rustc 1.99.1 — late.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_resolve/src/late.rs) · [Reference — namespaces](https://doc.rust-lang.org/reference/names/namespaces.html)

- **Profil değerleri derleyiciye gider.** `opt-level = 0` hızlı derleme, `3` hızlı çalışan kod, `"s"`/`"z"` küçük ikili üretir. `dev` varsayılan olarak 0, `release` 3'tür; ayarlar workspace kökünde okunur.
  ↳ Kaynak: [Cargo reference — profiles](https://doc.rust-lang.org/cargo/reference/profiles.html) · [Book ch14-01 — Release Profiles](https://doc.rust-lang.org/book/ch14-01-release-profiles.html)

> **Pratik not:** Kaynak dosyalardaki `cargo run -p ...`, `cargo test -p ...`, `cargo doc ...` satırları veri olarak okundu; bu oturumda hiçbiri çalıştırılmadı. Sonuçlar için komutları kendi ortamında çalıştır.
> ↳ Kaynak: [Book ch11-02 — Running Tests](https://doc.rust-lang.org/book/ch11-02-running-tests.html) · [Book ch14-01 — Release Profiles](https://doc.rust-lang.org/book/ch14-01-release-profiles.html)

## Özet ve sonraki adım

- Package kutudur, crate derleme birimidir; workspace tek `target/` ve tek `Cargo.lock` paylaşır.
- `//!`/`///` doküman yazar, doc-test örnekleri koşar; `pub use` gizlemez, kısa kapı açar.
- Profiller `opt-level = 0–3` ve boyut için `"s"`/`"z"` alır; Rust'ta **5 namespace** vardır.

Sıradaki bölüm: [14. Akıllı İşaretçiler](14-smart-pointers.md).
