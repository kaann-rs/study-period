# 14.1 Akıllı İşaretçiler: Derinleşme

> Kaynak dosya: `learn/smart-pointers/src/derinlesme.rs` · Test: `cargo test -p smart-pointers`

Önceki sayfada her işaretçiyi tek başına tanıttık; Weak ve referans döngüsü yalnız yorumda kalmıştı. Bu sayfada araçları **birlikte**, gerçek bir veri yapısında kullanıyoruz: ebeveynini bilen bir dizin ağacı kuruyor, döngünün sızdırdığını sayaçla ölçüyor, `Cell`/`RefCell` ile içeriden kayıt tutan bir test ikizi yazıyor ve `Rc::make_mut` ile "paylaşılıyorsa kopyala" yöntemini görüyoruz.

## Neden bu sayfa?

Doğru kutuyu üç soruyla seçersin: kaç sahip var, değer değişecek mi, biri sahip olmadan yalnız yerini bilmek istiyor mu? Üçüncü soruyu atlarsan iki veri birbirini canlı tutar ve hiçbiri çöpe atılamaz. Benzetmeler yine okulda: sınıf öğrenci listesinin sahibidir, öğrenci hangi sınıfta olduğunu bilir ama sınıfı açık tutmaz.

## Seçim tablosu: kaç sahip, değişecek mi, thread?

| Soru | Cevap | Araç |
| --- | --- | --- |
| Kaç sahip? | tek | `Box<T>` (heap + tek sahip; bedeli bir tahsis) |
| Kaç sahip? | çok, tek thread | `Rc<T>` (sayaçlı paylaşım; sayaç sıradan tam sayı) |
| Kaç sahip? | çok, çok thread | `Arc<T>` (sayaç atomik) |
| Değişecek mi? | hayır | `Rc<T>` / `Arc<T>` yeter |
| Değişecek mi? | evet, küçük `Copy` değer | `Cell<T>` (al–değiştir–geri koy, panik yok) |
| Değişecek mi? | evet, genel değer | `RefCell<T>` (çalışma anı borrow sayacı, ihlalde panik) |
| Sahip olmadan bilmek? | evet | `Weak<T>` (sayacı artırmaz, önce `upgrade()` sorar) |

1. Sık görülen birleşimler bu cevapların çarpımıdır: `Rc<RefCell<T>>` (çok sahip + değişir, tek thread), `Arc<Mutex<T>>` (çok thread'li hâli), `Rc<T> + Weak<T>` (ağaç/graf).
   ↳ Kaynak: [Book ch15-05 — `Rc<RefCell<T>>`](https://doc.rust-lang.org/book/ch15-05-interior-mutability.html) · [Book ch15-06 — `Weak<T>`](https://doc.rust-lang.org/book/ch15-06-reference-cycles.html) · [rustc 1.99.1 — arc.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/alloc/src/rcs/arc.rs)

2. Bunlar ilk tercih değil, **kaçış kapılarıdır**. Önce "veriyi tek sahipte toplayıp ötekilere `&` veremez miyim?" diye sor. `Rc<RefCell<...>>` her yere yayılırsa derleyicinin derleme anında yakalayacağı hatalar çalışma anı paniklerine dönüşür.
   ↳ Kaynak: [Book ch15-00 — Smart Pointers](https://doc.rust-lang.org/book/ch15-00-smart-pointers.html) · [Book ch15-05 — Interior Mutability](https://doc.rust-lang.org/book/ch15-05-interior-mutability.html)

## Gerçek senaryo: ebeveynini bilen dizin ağacı

Bir dosya sistemi ağacında her dizin çocuklarına **sahiptir**, ama her çocuk ebeveynini de **bilmelidir** (tam yolu üretmek için). İki yön de `Rc` olsaydı birbirini canlı tutarlardı. Sahiplik yönü `Rc`, geri yön `Weak` olur:

- ebeveyn → çocuk: `Rc` — "sahibim"
- çocuk → ebeveyn: `Weak` — "kim olduğunu biliyorum ama seni canlı tutmuyorum"

1. Alan türlerini içten dışa oku: `RefCell<Weak<Dizin>>` = sonradan değiştirilebilen (RefCell), sahip olmayan (Weak) bir Dizin işareti. `cocuklar: RefCell<Vec<Rc<Dizin>>>` ise `&self` ile çocuk ekleyebilmeyi sağlar.
   ↳ Kaynak: [Book ch15-06 — Creating a Tree Data Structure](https://doc.rust-lang.org/book/ch15-06-reference-cycles.html) · [Rustdoc — RefCell](https://doc.rust-lang.org/std/cell/struct.RefCell.html)

2. `cocuk_ekle` üç adımda çalışır: `Rc::downgrade(ebeveyn)` güçlü sayaca dokunmadan Weak üretir (weak sayaç +1); Weak çocuğun `ebeveyn` hücresine yazılır; çocuğun `Rc`'si ebeveynin listesine **taşınır** — çocuğun tek güçlü sahibi artık ebeveyn.
   ↳ Kaynak: [Rustdoc — Rc::downgrade](https://doc.rust-lang.org/std/rc/struct.Rc.html#method.downgrade) · [Rustdoc — RefCell::borrow_mut](https://doc.rust-lang.org/std/cell/struct.RefCell.html#method.borrow_mut)

3. `tam_yol`, `self.ebeveyn.borrow().upgrade()` ile "ebeveyn hâlâ duruyor mu?" diye sorar: `Some(ebeveyn)` gelirse yolu birleştirir, `None` gelirse kök ya da sahipsiz düğüm olarak yalnızca kendi adını döndürür. Sarkan işaretçi imkânsızdır.
   ↳ Kaynak: [Rustdoc — Weak::upgrade](https://doc.rust-lang.org/std/rc/struct.Weak.html#method.upgrade) · [Book ch15-06 — Weak Reference to Parent](https://doc.rust-lang.org/book/ch15-06-reference-cycles.html)

```rust
// learn/smart-pointers/src/derinlesme.rs — özet
pub struct Dizin {
    ad: String,
    ebeveyn: RefCell<Weak<Dizin>>, // sonradan atanacağı için RefCell
    cocuklar: RefCell<Vec<Rc<Dizin>>>, // &self ile çocuk ekleyebilmek için RefCell
}

pub fn cocuk_ekle(ebeveyn: &Rc<Dizin>, cocuk: Rc<Dizin>) {
    *cocuk.ebeveyn.borrow_mut() = Rc::downgrade(ebeveyn);
    ebeveyn.cocuklar.borrow_mut().push(cocuk);
}

pub fn tam_yol(&self) -> String {
    match self.ebeveyn.borrow().upgrade() {
        Some(ebeveyn) => format!("{}/{}", ebeveyn.tam_yol(), self.ad),
        None => self.ad.clone(), // kök (ya da ebeveyni düşmüş, sahipsiz düğüm)
    }
}
```

4. Örnekte `kaan` düğümünün yolu `/home/kaan` çıkar; `Rc::strong_count(&home)` 2 (yerel `home` + kök'ün listesi), `Rc::weak_count` 1'dir (kaan'ın geri işareti). `kok` ve `home` düşürülünce güçlü sayaç 0'a iner ve home serbest kalır — kaan'daki Weak onu kurtaramaz, istenen de budur; yol `kaan` olur.
   ↳ Kaynak: [Rustdoc — Rc::strong_count](https://doc.rust-lang.org/std/rc/struct.Rc.html#method.strong_count) · [Rustdoc — Rc::weak_count](https://doc.rust-lang.org/std/rc/struct.Rc.html#method.weak_count)

## Referans döngüsünü gözle görmek

`Dugum`, düşüş sayacı olarak paylaşılan bir `Rc<Cell<u32>>` tutar; `Drop` uygulaması sayacı bir artırır. Böylece "kaç düğüm gerçekten düştü?" sorusunu ölçebiliriz (ideali 2).

1. `cift_olustur(false)` — iki yön de `Rc`: kapsam sonunda `b` adı düşer, sayacı 2'den 1'e iner (a tutuyor); `a` adı düşer, sayacı 2'den 1'e iner (b tutuyor). İkisine ulaşan kimse kalmadı ama ikisi de 1'de takılı: **düşen düğüm = 0, sızıntı**.
   ↳ Kaynak: [Book ch15-06 — Reference Cycles Can Leak Memory](https://doc.rust-lang.org/book/ch15-06-reference-cycles.html) · [Rustdoc — Rc](https://doc.rust-lang.org/std/rc/struct.Rc.html)

2. `cift_olustur(true)` — geri yön `Weak`: `a` adı düşünce güçlü sayaç 1'den 0'a iner, a düşer ve elindeki `b` Rc'sini bırakır; `b` adı da düşmüştü, sayaç 0 → b düşer. **Düşen düğüm = 2**, zincir çözülür.
   ↳ Kaynak: [Rustdoc — Rc::downgrade](https://doc.rust-lang.org/std/rc/struct.Rc.html#method.downgrade) · [Rustdoc — Weak](https://doc.rust-lang.org/std/rc/struct.Weak.html)

3. Kural: döngü kurabilen işaretlerden **en az biri Weak** olmalı — sahiplik taşımayan (geri/yan/gözlemci) kenar. Sızıntı Rust'ta güvenli sayılır: bellek bozulmaz, yalnız geri verilmez.
   ↳ Kaynak: [Book ch15-06 — Avoiding Reference Cycles](https://doc.rust-lang.org/book/ch15-06-reference-cycles.html) · [rustc 1.99.1 — rc.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/alloc/src/rcs/rc.rs)

## İç değişkenlik: `Cell` ve `RefCell`

Bazen bir işlem mantıksal olarak salt okunurdur (çağıran açısından hiçbir şey değişmez) ama gerçekleştirim içeride bir kayıt güncellemek ister: çağrı sayacı, önbellek, denetim kaydı. Metodu `&mut self` yaparsak bu iç ayrıntı imzaya sızar ve iki okuyucu bile olamaz.

| Hücre | Nasıl çalışır | Ne zaman |
| --- | --- | --- |
| `Cell<T>` | değeri kopyalayarak okur/yazar (`get`/`set`); içine referans vermez, panik etmez | küçük `Copy` değerler (sayaç, bayrak) |
| `RefCell<T>` | içine referans verir (`borrow`/`borrow_mut`); kuralı çalışma anında sayaçla denetler | yerinde değiştirilen `Vec`, `String`, `HashMap` |

1. `Bildirimci` trait'i `fn gonder(&self, mesaj: &str)` ister: gönderen taraf "bildirim göndermek beni değiştirmez" varsayar. Test ikizi `KayitliBildirimci` mesajları `RefCell<Vec<String>>` içinde, çağrı sayısını `Cell<u32>` içinde tutar — trait'i test uğruna `&mut self` yapmak üretim tasarımını teste kurban etmek olurdu.
   ↳ Kaynak: [Book ch15-05 — Interior Mutability](https://doc.rust-lang.org/book/ch15-05-interior-mutability.html) · [Rustdoc — Cell](https://doc.rust-lang.org/std/cell/struct.Cell.html)

2. `gonder` içinde `self.cagri.set(self.cagri.get() + 1)` ve `self.mesajlar.borrow_mut().push(...)` çalışır. Dönen `RefMut` geçicidir; ifade bitince bırakılır. `bildirimci` değişkeninin `mut` olmasına gerek yoktur — yine de içine kayıt düşer.
   ↳ Kaynak: [Rustdoc — RefCell::borrow_mut](https://doc.rust-lang.org/std/cell/struct.RefCell.html#method.borrow_mut) · [Rustdoc — Cell::set](https://doc.rust-lang.org/std/cell/struct.Cell.html#method.set)

3. `KotaTakibi` `%75`'te uyarı, `%100`'de hata gönderir. `sinir.max(1)` sıfıra bölme paniğini önler; `saturating_add` ve `u64` çarpımı debug/release farkından kaynaklanan taşmayı engeller.
   ↳ Kaynak: [Rustdoc — u32::saturating_add](https://doc.rust-lang.org/std/primitive.u32.html#method.saturating_add) · [Rustdoc — Cell](https://doc.rust-lang.org/std/cell/struct.Cell.html)

## RefCell tuzakları

1. **Bir borrow canlıyken ikincisini istemek → çalışma anı paniği.** Derleme anında hata yoktur; bedel budur. `try_borrow_mut()` aynı durumu panik yerine `Result` olarak verir. İhlal mesajı **`RefCell already borrowed`** (`core/src/cell.rs:917-922`).
   ↳ Kaynak: [rustc 1.99.1 — cell.rs:917-922](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/cell.rs#L917-L922) · [Rustdoc — RefCell::try_borrow_mut](https://doc.rust-lang.org/std/cell/struct.RefCell.html#method.try_borrow_mut)

2. **Borrow'u uzun tutmak.** `for x in liste.borrow().iter() { liste.borrow_mut().push(*x); }` panikler. Çözüm: borrow'ları dar tut — `let eklenecek: Vec<i32> = liste.borrow().iter().map(|x| x * 10).collect();` ile değeri kopyala, borrow kapanınca `liste.borrow_mut().extend(eklenecek);` yaz.
   ↳ Kaynak: [Book ch15-05 — Borrowing Rules at Runtime](https://doc.rust-lang.org/book/ch15-05-interior-mutability.html) · [Rustdoc — RefCell](https://doc.rust-lang.org/std/cell/struct.RefCell.html)

3. **Geçici guard'dan referans kaçırmak (`E0716`).** `let ilk = liste.borrow().first().unwrap();` derlenmez: referans, satır sonunda ölen `Ref` guard'a bağlıdır. `i32` kopyalanabilir olduğu için `let ilk = *liste.borrow().first().unwrap();` doğrudur; ya da guard'ı bir değişkene bağla.
   ↳ Kaynak: [Rustdoc — Ref](https://doc.rust-lang.org/std/cell/struct.Ref.html) · [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs)

4. **`Rc`'yi doğrudan değiştirmeye çalışmak (`E0594` / `E0596`).** `Rc` yalnız `Deref` uygular, `DerefMut` uygulamaz. `Rc<RefCell<T>>` ya da `Rc::make_mut` kullan.
   ↳ Kaynak: [Rustdoc — Rc](https://doc.rust-lang.org/std/rc/struct.Rc.html) · [Rustdoc — Rc::make_mut](https://doc.rust-lang.org/std/rc/struct.Rc.html#method.make_mut)

5. **`Rc<RefCell<T>>`'yi thread'e taşımak (`E0277`).** `Arc<RefCell<i32>>` de yetmez: `RefCell`'in borrow sayacı atomik değildir. Çok thread'li karşılık `Arc<Mutex<T>>`dir; bunun kök nedeni `Send`/`Sync` sınırlarıdır.
   ↳ Kaynak: [Rustdoc — Send](https://doc.rust-lang.org/std/marker/trait.Send.html) · [rustc 1.99.1 — arc.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/alloc/src/rcs/arc.rs) · [rustc 1.99.1 — marker.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/marker.rs)

## `Rc::make_mut`: paylaşılıyorsa kopyala

Senaryo: birçok bileşenin paylaştığı yapılandırma. Çoğu yalnız okur; biri kendi kopyasını değiştirmek isterse ötekiler etkilenmemelidir. `RefCell` burada yanlış araçtır, çünkü herkes değişikliği görür. `Rc::make_mut(&mut rc)` şunu yapar:

1. Tek sahip bizsek doğrudan `&mut T` verir — kopya yoktur. Başka sahipler varsa veriyi klonlar, bizim `Rc`'mizi yeni kopyaya çevirir ve ona `&mut` verir.
   ↳ Kaynak: [Rustdoc — Rc::make_mut](https://doc.rust-lang.org/std/rc/struct.Rc.html#method.make_mut) · [Rustdoc — Rc::ptr_eq](https://doc.rust-lang.org/std/rc/struct.Rc.html#method.ptr_eq)

2. Örnekte `varsayilan` ile `kullanici_ayari` önce aynı veriyi paylaşır (`ptr_eq` → true). `make_mut` ile `"tema=açık"` → `"tema=koyu"` yazılınca klonlanır (`ptr_eq` → false), varsayılan dokunulmaz. İkinci `make_mut` çağrısında artık tek sahip olduğu için kopya yapılmaz.
   ↳ Kaynak: [Rustdoc — Rc::make_mut](https://doc.rust-lang.org/std/rc/struct.Rc.html#method.make_mut) · [Book ch15-04 — `Rc<T>`](https://doc.rust-lang.org/book/ch15-04-rc.html)

## Derleyici perspektifi

- **Her işaretçi güvenliği başka yerde öder:** Box derleme anında (bedelsiz), Rc çalışma anında bir sayaçla, RefCell çalışma anında borrow sayacı + olası panikle, Weak her erişimde bir "yaşıyor mu?" sorusuyla. Bedelsiz olan yetiyorsa bedelli olana geçme.
  ↳ Kaynak: [rustc 1.99.1 — rc.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/alloc/src/rcs/rc.rs) · [rustc 1.99.1 — cell.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/cell.rs)

- **Güçlü ve zayıf sayaç ayrılır.** `Rc::downgrade` güçlü sayaca dokunmaz; `strong_count` 0'a inince veri düşer, `weak_count` ise düğümün yerini bilen işaretçileri sayar. `upgrade()` o an geçici bir güçlü sahiplik alır, bu yüzden kullanım sırasında veri düşemez.
  ↳ Kaynak: [rustc 1.99.1 — rc.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/alloc/src/rcs/rc.rs) · [Rustdoc — Weak::upgrade](https://doc.rust-lang.org/std/rc/struct.Weak.html#method.upgrade)

- **Cell/RefCell'in altındaki ilkel `UnsafeCell`'dir.** Bu, iç değişkenliğin güvenli yüzüdür: derleyici `&T` arkasına yazmayı yalnızca hücrenin denetimiyle izin verir. Hatalı kullanımda bellek bozulması değil panik olur.
  ↳ Kaynak: [rustc 1.99.1 — cell.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/cell.rs) · [Reference — Interior mutability](https://doc.rust-lang.org/reference/interior-mutability.html)

- **`Rc` ve `RefCell` tek thread içindir.** Sayaçlar atomik olmadığı için `Send`/`Sync` sınırları derleme anında taşımayı reddeder (`E0277`). Çok thread için `Arc` yolu `library/alloc/src/rcs/arc.rs`'tir; kilitlerle birlikte kullanılır.
  ↳ Kaynak: [rustc 1.99.1 — arc.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/alloc/src/rcs/arc.rs) · [rustc 1.99.1 — marker.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/marker.rs)

> **Alıştırma notu:** Kaynak dosyada üç alıştırma var: `Dizin`'e döngüyle `derinlik()` eklemek; `Weak<dyn Bildirimci>` tutan bir olay yayıncısı yazmak; ve `cift_olustur(false)`'un neden 0 döndürdüğünü sayaçlar üzerinden adım adım göstermek. Çözümler verilmez; `cargo test -p smart-pointers` ile kendin sına (bu oturumda çalıştırılmadı — DOĞRULANAMADI).
> ↳ Kaynak: [Book ch11-02 — Running Tests](https://doc.rust-lang.org/book/ch11-02-running-tests.html) · [Book ch15-06 — Reference Cycles](https://doc.rust-lang.org/book/ch15-06-reference-cycles.html)

## Özet ve sonraki adım

- Ağaçta sahiplik yönü `Rc`, geri yön `Weak`, değişen liste `RefCell` olur; `upgrade()` sarkan işaretçiyi imkânsız kılar.
- İki yönlü `Rc` döngüsü sızdırır (düşen düğüm 0); bir yönü `Weak` yapınca 2 düğüm de düşer.
- `Cell` panik etmez, `RefCell` edebilir; `Rc::make_mut` yalnız paylaşılıyorsa kopyalar.

Sıradaki bölüm: [15. Eşzamanlılık](15-concurrency.md).
