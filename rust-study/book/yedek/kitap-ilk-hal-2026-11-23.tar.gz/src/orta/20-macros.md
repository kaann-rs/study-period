# 20. Makrolar

> Kaynak crate: `learn/macros` · Test: `cargo test -p macros`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

## Neden bu bölüm?

Bir damgayı bir kez hazırlarsın, sonra her bastığında aynı yazı senin yerine çıkar. Makro da kod yazan koddur: çağrıldığı yere, derlemeden önce başka kod yerleştirir. Bu bölümde prosedürel makronun nasıl yazıldığını ve damgayı hazırlayan crate ile damgayı kullanan crate'in neden ayrı olduğunu görüyoruz.

## 5 yaşındaki çocuğa anlatır gibi

Bir lastik damga yaptırıyorsun. Atölye damgayı hazırlar, sen kâğıda basarsın. Bastığında yıldız çıkarsa şaşırma; sen çizmedin, damga çizdi.

## Konu anlatımı (madde madde)

1. **Makro, kod yazan koddur.** Çağrıldığı yere derlemeden önce kod yerleştirir; adının sonundaki `!` "bu bir fonksiyon değil, makro" işaretidir.
   ↳ Kaynak: [Book ch20-05 — Macros](https://doc.rust-lang.org/book/ch20-05-macros.html) · [Reference](https://doc.rust-lang.org/reference/)

2. **İki makro ailesi vardır.** Bildirimsel makro `macro_rules!` ile desen → kod şablonu kurar; prosedürel makro ise kod parçalarını (token) alıp yerine yenilerini koyan bir fonksiyondur.
   ↳ Kaynak: [Book ch20-05 — Declarative Macros](https://doc.rust-lang.org/book/ch20-05-macros.html) · [Book ch20-05 — Procedural Macros](https://doc.rust-lang.org/book/ch20-05-macros.html)

3. **Token, kaynak kodun en küçük parçasıdır.** Bir ad, sayı veya parantez token'dır; art arda dizilenleri `TokenStream` oluşturur. Makronun aldığı ve döndürdüğü şey bu akıştır.
   ↳ Kaynak: [Reference](https://doc.rust-lang.org/reference/) · [Book ch20-05 — Procedural Macros](https://doc.rust-lang.org/book/ch20-05-macros.html)

4. **Bu crate'deki makro sıradan bir Rust fonksiyonu olarak yazılmıştır.** `#[proc_macro]` ile işaretli `cevap_uret(_girdi: TokenStream)` girdiye bakmaz; `"fn cevap() -> u32 { 42 }"` dizesini ayrıştırıp (parse) `TokenStream` olarak döndürür. Gerçek makrolar girdiyi okuyup ona göre kod üretir.
   ↳ Kaynak: [Book ch20-05 — Procedural Macros](https://doc.rust-lang.org/book/ch20-05-macros.html) · kaynak dosya: `learn/macros/src/lib.rs`

5. **Proc-macro kısıtı lib hedefindedir.** Bu crate'in lib hedefi proc-macro tipindedir: proc-macro dışında öğe dışa aktaramaz, ancak özel fonksiyonlar ve ayrı bir binary hedefi yazılabilir. Makroyu yalnızca **başka bir crate** kullanabilir; bu dosyada `fn main` bulunmaması bir tercihtir, zorunluluk değildir.
   ↳ Kaynak: [Book ch20-05 — Procedural Macros](https://doc.rust-lang.org/book/ch20-05-macros.html) · [Reference](https://doc.rust-lang.org/reference/)

6. **Entegrasyon testi ayrı bir crate gibi derlenir.** `tests/kullanim.rs`, `use macros::cevap_uret;` ile makroyu içe aktarır; `cevap_uret!();` satırı derlenirken `fn cevap() -> u32 { 42 }` üretir. Dosyada `cevap` yazılı olmasa bile çağrılabilir.
   ↳ Kaynak: [Book ch11-03 — Test Organization](https://doc.rust-lang.org/book/ch11-03-test-organization.html) · kaynak dosya: `learn/macros/tests/kullanim.rs`

7. **Genişleme derleme anında olur.** Makro çağrısı çalışma anında bir işlem değildir; derleyici onu kendi ürettiği kodla değiştirir. Bu yüzden `#[derive(Debug)]` gibi "tür başına kod yazma" işleri fonksiyonla değil makroyla yapılır.
   ↳ Kaynak: [Book ch20-05 — Macros](https://doc.rust-lang.org/book/ch20-05-macros.html) · [Book ch20-02 — Advanced Traits](https://doc.rust-lang.org/book/ch20-02-advanced-traits.html)

8. **Fonksiyondan farkı imza ve zamandır.** Fonksiyon çalışma anında çağrılır ve sabit imza ister; makro derleme anında kod üretir ve değişken sayıda argüman alabilir. `macro_rules!` bildirimsel, `#[proc_macro]` prosedürel taraftır; ikisi aynı şey değildir.
   ↳ Kaynak: [Book ch20-05 — Macros](https://doc.rust-lang.org/book/ch20-05-macros.html) · [Book ch03 — Common Programming Concepts](https://doc.rust-lang.org/book/ch03-00-common-programming-concepts.html)

9. **Prosedürel makronun üç alt türü vardır.** `#[derive]` (örneğin `derive(Debug)`), öznitelik makrosu (örneğin `#[route(...)]`) ve fonksiyon-benzeri makro (örneğin `sql!(...)`). Bu crate'deki `cevap_uret!` son gruptandır.
   ↳ Kaynak: [Book ch20-05 — Procedural Macros](https://doc.rust-lang.org/book/ch20-05-macros.html) · [Reference](https://doc.rust-lang.org/reference/)

## Kodda nasıl görünür?

```rust
// learn/macros/src/lib.rs
use proc_macro::TokenStream;

#[proc_macro]
pub fn cevap_uret(_girdi: TokenStream) -> TokenStream {
    "fn cevap() -> u32 { 42 }".parse().unwrap()
}

// learn/macros/tests/kullanim.rs
use macros::cevap_uret;

cevap_uret!();

#[test]
fn cevap_42_doner() {
    assert_eq!(cevap(), 42);
}
```

## Sık yapılan hatalar

| Kod / durum | Sonuç | Neden | Kaynak |
| --- | --- | --- | --- |
| `cevap_uret!()` çağrısını `src/lib.rs` içine yazmak | derlenmez | Prosedürel makro tanımlandığı crate'te kullanılamaz; çağrı `tests/` altında yapılır. | [Book ch20-05](https://doc.rust-lang.org/book/ch20-05-macros.html) · `learn/macros/src/lib.rs` |
| Proc-macro lib hedefinden başka öğe dışa aktarmaya çalışmak | derlenmez | Bu hedef proc-macro dışında öğe dışa aktaramaz; özel fonksiyon ve ayrı binary hedefi yazılabilir. | [Book ch20-05](https://doc.rust-lang.org/book/ch20-05-macros.html) · [Reference](https://doc.rust-lang.org/reference/) |
| `assert_eq!(cevap(), 42);` satırını `cevap_uret!();` olmadan yazmak | derlenmez | `cevap` dosyada tanımlı değildir; onu makro üretir. | `learn/macros/tests/kullanim.rs` · [Book ch20-05](https://doc.rust-lang.org/book/ch20-05-macros.html) |
| `macro_rules!` ile prosedürel makroyu karıştırmak | yanlış anlama | İlki desen şablonu, ikincisi `TokenStream` alan fonksiyondur. | [Book ch20-05](https://doc.rust-lang.org/book/ch20-05-macros.html) · [Reference](https://doc.rust-lang.org/reference/) |

## Derleyici perspektifi

- **Makrolar fonksiyonlardan önce açılır.** Derleyici makro çağrısını gerçek koda çevirir; çalışma anında makro çağrısı kalmaz.
  ↳ Kaynak: [Book ch20-05 — Macros](https://doc.rust-lang.org/book/ch20-05-macros.html) · [Reference](https://doc.rust-lang.org/reference/)

- **Prosedürel makro `TokenStream` → `TokenStream` dönüşümüdür.** Kaynak kod token'lara ayrılır, fonksiyon yeni token'lar üretir ve derleyici bunu çağrı yerine enjekte eder.
  ↳ Kaynak: [Book ch20-05 — Procedural Macros](https://doc.rust-lang.org/book/ch20-05-macros.html) · [Reference](https://doc.rust-lang.org/reference/)

- **Her entegrasyon testi ayrı bir crate'tir.** Bu yüzden `tests/kullanim.rs` prosedürel makroyu kullanabilir; makro kendi crate'inin içinde kullanılamaz.
  ↳ Kaynak: [Book ch11-03 — Test Organization](https://doc.rust-lang.org/book/ch11-03-test-organization.html) · [Book ch20-05 — Procedural Macros](https://doc.rust-lang.org/book/ch20-05-macros.html)

- **Proc-macro crate sınırı derleyici tarafından uygulanır.** `proc-macro = true` olan hedef yalnızca makro dışa aktarabilir; bu kısıt, makronun tanımlandığı crate'te çağrılamamasının da nedenidir.
  ↳ Kaynak: [Reference](https://doc.rust-lang.org/reference/) · [Book ch20-05 — Procedural Macros](https://doc.rust-lang.org/book/ch20-05-macros.html)

## Özet ve sonraki adım

- Makro, derleme anında kod üreten damgadır; bildirimsel ve prosedürel olmak üzere iki ailesi vardır.
- Prosedürel makro `#[proc_macro]` ile tanımlanır, `TokenStream` alıp verir ve yalnızca başka bir crate'te kullanılabilir.
- `tests/kullanim.rs` ayrı crate olduğu için `cevap_uret!()` orada genişler ve `cevap()` çağrılabilir olur.

Sıradaki bölüm: [21. Alt-tip ve Değişkenlik](../ileri/21-variance.md).
