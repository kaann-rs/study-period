# 16. Async / Await

> Kaynak crate: `learn/async-await` · Çalıştır: `cargo run -p async-await`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

## Neden bu bölüm?

Çamaşır makinesi dönerken bulaşık yıkarsın; evde tek kişi olmanına rağmen iki iş iç içe ilerler. Async tam olarak budur: beklenen anlarda başka işe geçerek tek thread'de çok işi yürütmek. Bu bölümde Future'ın ne olduğunu, `.await`'in hangi işi yaptığını ve çalıştırıcının (executor) neden dışarıdan geldiğini göreceğiz.

## 5 yaşındaki çocuğa anlatır gibi

Çamaşırı makineye koydun. Oturup bekler misin? Hayır, o sırada bulaşıkları yıkarsın. Makine bitince zil çalar, sen de çamaşırı alırsın. İki makine varsa ikisini birden çalıştırırsın; ikisi de aynı anda biter.

## Konu anlatımı (madde madde)

1. **Async, eşzamanlılıktır; paralellik değildir.** Async bir işi bölüp bekleme boşluklarını başka işlerle doldurur; thread'ler (Böl. 15) işi gerçekten aynı anda koşturur. İkisi birleştirilebilir.
   ↳ Kaynak: [Book ch17-00 — Async-Await](https://doc.rust-lang.org/book/ch17-00-async-await.html) · [Book ch16-00 — Concurrency](https://doc.rust-lang.org/book/ch16-00-concurrency.html)

2. **`async fn` gövdeyi çalıştırmaz, bir Future üretir.** `async fn f() -> T`'nin gerçek dönüş türü `impl Future<Output = T>`'dir; `f()` çağırmak sıfır iş yapar, çünkü future'lar tembeldir (tıpkı Böl. 12'deki iterator'lar gibi).
   ↳ Kaynak: [Book ch17-01 — Futures and the Async Syntax](https://doc.rust-lang.org/book/ch17-01-futures-and-syntax.html) · [Rustdoc — Future](https://doc.rust-lang.org/std/future/trait.Future.html)

3. **`.await` o future'ı sürer (poll eder).** Hazırsa değeri alıp kaldığın satırdan devam edersin; değilse `Poll::Pending` dönüp kontrolü üstteki çalıştırıcıya verirsin. Derleyici her `.await` noktasında durabilen bir **state machine** (durum makinesi) üretir.
   ↳ Kaynak: [Book ch17-02 — The Await Operation](https://doc.rust-lang.org/book/ch17-02-async-await.html) · [Rustdoc — Future::poll](https://doc.rust-lang.org/std/future/trait.Future.html#tymethod.poll)

4. **Future trait'inin tek metodu `poll` vardır.** İmza kabaca `fn poll(self: Pin<&mut Self>, cx: &mut Context) -> Poll<Self::Output>`'tur; `poll` "ilerleyebildiğin kadar ilerle" der, cevap `Ready(değer)` ya da `Pending`'tir.
   ↳ Kaynak: [rustc 1.99.1 — future.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/future/future.rs) · [rustc 1.99.1 — poll.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/task/poll.rs)

5. **Pending dönen future bir Waker bırakır.** `cx.waker()` "hazır olunca beni tekrar yokla" zilidir; I/O geldiğinde ya da zamanlayıcı dolduğunda `wake()` çağrılır ve çalıştırıcı o görevi yeniden poll eder. Böylece boşa dönen döngü (busy-wait) olmaz.
   ↳ Kaynak: [rustc 1.99.1 — wake.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/task/wake.rs) · [Book ch17-03 — More Futures](https://doc.rust-lang.org/book/ch17-03-more-futures.html)

6. **std sözdizimini ve Future'ı verir, çalıştırıcıyı vermez.** I/O, zamanlayıcı ve görev kuyruğu gerektiği için tek "doğru" seçim yoktur; koşturan döngü tokio/async-std gibi kütüphanelere bırakılmıştır. Bu crate'te mekanizmayı çıplak görmek için executor elle yazılmıştır.
   ↳ Kaynak: [Book ch17-00 — Async-Await](https://doc.rust-lang.org/book/ch17-00-async-await.html) · [Rustdoc — Future](https://doc.rust-lang.org/std/future/trait.Future.html)

7. **`block_on` tek future'ı bitene kadar yoklar.** `Poll::Pending` gelince thread `park()` ile uyur, `wake` onu `unpark()` ile uyandırır; böylece bekleme sırasında işlemci boşa yakılmaz.
   ↳ Kaynak: [Rustdoc — thread::park](https://doc.rust-lang.org/std/thread/fn.park.html) · [rustc 1.99.1 — wake.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/task/wake.rs)

8. **Birden çok görev tek thread'de iç içe yürütülebilir.** `cok_gorev` her göreve sırayla bir tur verir (round-robin); biten listeden çıkar, kalanlar bir sonraki tura kalır. Çıktıda iki "başladı", iki "bitti"den önce gelir — kazanç paralellikten değil bekleme sürelerinin üst üste binmesindendir.
   ↳ Kaynak: [Book ch17-00 — Async-Await](https://doc.rust-lang.org/book/ch17-00-async-await.html) · [Rustdoc — Future](https://doc.rust-lang.org/std/future/trait.Future.html)

9. **Pin, state machine'in yerinden oynamamasını garanti eder.** Bir `.await`'ten sonra makine kendi yerel değişkenine referans tutabilir (self-referential); değer taşınırsa o iç referanslar sarkar. Bu yüzden `poll` `Pin<&mut Self>` alır ve poll edilmeden önce `pin!`/`Box::pin` gerekir.
   ↳ Kaynak: [Book ch17-03 — More Futures and Pinning](https://doc.rust-lang.org/book/ch17-03-more-futures.html) · [Rustdoc — std::pin](https://doc.rust-lang.org/std/pin/index.html)

10. **`.await` yalnız async gövde içinde yazılabilir.** Normal bir fonksiyonda "Pending'de durumu sakla, sonra buradan devam et" yapacak state machine yoktur; düz `main` de async olamaz, senkron dünyaya geçiş tek noktada (`block_on` / `#[tokio::main]`) olur.
    ↳ Kaynak: [Book ch17-02 — The Await Operation](https://doc.rust-lang.org/book/ch17-02-async-await.html) · [Reference — Functions](https://doc.rust-lang.org/reference/items/functions.html)

## Kodda nasıl görünür?

```rust
use std::future::Future;
use std::pin::pin;
use std::sync::Arc;
use std::task::{Context, Poll, Wake, Waker};
use std::thread::{self, Thread};

struct ThreadWaker(Thread);
impl Wake for ThreadWaker {
    fn wake(self: Arc<Self>) { self.0.unpark(); }
    fn wake_by_ref(self: &Arc<Self>) { self.0.unpark(); }
}

fn block_on<F: Future>(fut: F) -> F::Output {
    let mut fut = pin!(fut); // poll için sabitle
    let waker = Waker::from(Arc::new(ThreadWaker(thread::current())));
    let mut cx = Context::from_waker(&waker);
    loop {
        match fut.as_mut().poll(&mut cx) {
            Poll::Ready(v) => return v,
            Poll::Pending => thread::park(), // uyanana dek uyu
        }
    }
}

struct BirKezBekle { hazir: bool }
impl Future for BirKezBekle {
    type Output = i32;
    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<i32> {
        if self.hazir {
            Poll::Ready(42)
        } else {
            self.hazir = true;
            cx.waker().wake_by_ref(); // "beni tekrar poll et"
            Poll::Pending
        }
    }
}

async fn akis() -> i32 {
    let n = BirKezBekle { hazir: false }.await; // bir tur Pending'den sonra 42
    n + 1
}

fn main() {
    let s = block_on(akis()); // 43
    println!("block_on döndü: {s}");
}
```

## Sık yapılan hatalar

| Kod / durum | Hata | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| `fn main() { let x = f().await; }` | **E0728** | `.await` yalnız `async` fonksiyon/blok içinde; köprü için `block_on` (tokio'da `#[tokio::main]`). | [Book ch17-02](https://doc.rust-lang.org/book/ch17-02-async-await.html) |
| `let n: i32 = async { 2 };` | **E0308** | Future, sonucun kendisi değil; `let n: i32 = async { 2 }.await;` ya da `block_on`. | [Book ch17-01](https://doc.rust-lang.org/book/ch17-01-futures-and-syntax.html) |
| Pending dönüp `wake()` çağırmamak | derlenir, executor uyur kalır | "Hazırım" sinyali yoksa bir daha bakılmaz; Pending'de waker'ı sakla/çal. | [wake.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/task/wake.rs) |
| `let mut fut = f(); fut.poll(&mut cx);` | **E0599** | Sabitlenmemiş Future poll edilemez; `pin!(fut)` veya `Box::pin(fut)` kullan. | [Rustdoc — std::pin](https://doc.rust-lang.org/std/pin/index.html) |
| `async fn kotu() { thread::sleep(sure); }` | derlenir, eşzamanlılık biter | `sleep` Pending dönmez, thread'i gerçekten uyutur; runtime'ın async zamanlayıcısını kullan. | [Book ch17-00](https://doc.rust-lang.org/book/ch17-00-async-await.html) · [Book ch16-00](https://doc.rust-lang.org/book/ch16-00-concurrency.html) |

## Derleyici perspektifi

- **`async fn`/`async {}` bir state machine'e derlenir.** Derleyici fonksiyonu her `.await` noktasında duraklayan bir enum'a çevirir; her durum o ana kadarki yerel değişkenleri saklar. Bu yüzden `f()` çağırmak hiçbir iş yapmaz.
  ↳ Kaynak: [Book ch17-01 — Futures and the Async Syntax](https://doc.rust-lang.org/book/ch17-01-futures-and-syntax.html) · *Rust for Rustaceans*, 8. Futures (kitap)

- **`poll` sözleşmesi `core/src/future/future.rs`'tedir.** `Ready` dönünce değer alınır; `Pending` dönünce waker saklanır ve hazır olunca `wake()` ile yeniden poll istenir. Future yeniden poll EDİLMEMELİDİR; `Ready` sonrası davranış belirsizdir.
  ↳ Kaynak: [rustc 1.99.1 — future.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/future/future.rs) · [Rustdoc — Future::poll](https://doc.rust-lang.org/std/future/trait.Future.html#tymethod.poll)

- **Waker mekanizması `core/src/task/wake.rs` ve `poll.rs`'tedir.** Bu dosyada ham `RawWaker`/vtable yerine `Arc` üzerinden `Wake` trait'i kullanılmıştır; zil çalınca park etmiş thread `unpark()` ile uyanır.
  ↳ Kaynak: [rustc 1.99.1 — wake.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/task/wake.rs) · [rustc 1.99.1 — poll.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/task/poll.rs)

- **Pin, self-referential state machine'i korur.** `Pin<&mut T>` "bu değer artık taşınmayacak" garantisini tür düzeyine çıkarır; `Unpin` olan türler bu kısıttan muaftır.
  ↳ Kaynak: [Rustdoc — std::pin](https://doc.rust-lang.org/std/pin/index.html) · [Book ch17-03 — More Futures](https://doc.rust-lang.org/book/ch17-03-more-futures.html)

## Özet ve sonraki adım

- `async` bir Future (iş kartı) üretir, çalıştırmaz; `.await` onu poll edip Pending'de sırayı verir.
- Waker olmadan hiçbir iş hazır olduğunda haberi iletemez; std çalıştırıcıyı vermez.
- Kazanç bekleme sürelerinin üst üste binmesindendir; Pin sayesinde durum makinesi güvenle saklanır.

Bir sonraki sayfada [16.1 Async / Await: Derinleşme](16-async-await-derinlesme.md) bölümünde tembellik, sıralı/eşzamanlı bekleme, API istemcisi ve Pin'in gündelik kullanımını göreceğiz.
