# 9.1 Jenerikler: Derinleşme

> Kaynak dosya: `learn/generics-traits-lifetimes/src/derinlesme.rs` · Test: `cargo test -p generics-traits-lifetimes`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

Önceki sayfada generic, trait ve lifetime'ın ne olduğunu gördük. Bu sayfa bir adım sonrasını sorar: **bir fonksiyonun ilk satırını (imzasını) ben yazarken neye dikkat etmeliyim?** İmzaya yazdığın her etiket ve her şart, seni çağırana verilmiş bir sözdür; gereğinden sıkı yazarsan kod derlenir ama çağıranın eli kolu bağlanır.

## Neden bu sayfa?

Kütüphaneden bir kitap ödünç aldıysan, içindeki bir satırın altını çizmek için cetvel kullanabilirsin. Ama o satır cetvele değil kitaba aittir: cetveli geri verdiğinde ayraç yerinde durur. Ödünç fişine "bu satır hem kitaba hem cetvele bağlı" yazarsan, cetveli geri verdiğin an satırı da kullanamazsın. Lifetime etiketi tam olarak bu fiştir.

## 1. Lifetime bir süre değil, bir ilişki bildirimidir

`'a` ömrü UZATMAZ; "dönen referans şu girdiden türetildi, onun kadar geçerli" der. Derleyici bunu gövdede ve çağrı yerinde denetler.

```rust
// ✗ Gereğinden sıkı: sonuç yalnız metin'den gelse bile "ikisinden de gelebilir" der.
fn on_eki_at_siki<'a>(metin: &'a str, on_ek: &'a str) -> &'a str {
    metin.strip_prefix(on_ek).unwrap_or(metin)
}

// ✓ on_ek yalnız karşılaştırmada kullanılıyor; çıktıyla bağı yok.
fn on_eki_at<'a>(metin: &'a str, on_ek: &str) -> &'a str {
    metin.strip_prefix(on_ek).unwrap_or(metin)
}
```

1. Sıkı imzada `on_ek` blok sonunda ölünce, kâğıt üzerinde `temiz` de geçersiz sayılır: **E0597 — `on_ek` does not live long enough**. Doğru imzada sonuç yalnız `yol`'a bağlıdır ve `on_ek` öldükten sonra da kullanılabilir. Kural: bir parametre çıktıya katkı vermiyorsa çıktıyla aynı lifetime'ı paylaşmasın.
   ↳ Kaynak: [Book ch10-03 — Lifetime Syntax](https://doc.rust-lang.org/book/ch10-03-lifetime-syntax.html) · [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html)

2. Ters yöndeki hata da yakalanır: `fn f<'a, 'b>(x: &'a str, y: &'b str) -> &'a str` gövdesi `y`'yi döndürürse derleme hatası alınır — bu hatanın E-kodu **YOKTUR**, mesaj "lifetime may not live long enough" ve `"consider adding the following bound: 'b: 'a"` önerisiyle gelir. Etiket doğruysa çağıran özgür olur; etiket yanlışsa derleyici imzaya güvenip sözü tutar.
   ↳ Kaynak: [Reference — Subtyping and Variance](https://doc.rust-lang.org/reference/subtyping.html) · [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html)

## 2. Gerçek senaryo: sıfır kopyalı (zero-copy) ayar ayrıştırıcı

"anahtar=değer;anahtar=değer" biçimli satırı ayrıştırırken her parça için yeni `String` tahsis etmek yerine girdinin içine bakan dilimler döndürebiliriz. Büyük girdilerde tahsis sayısı sıfıra iner; bedel sonuçların girdiye bağlı olmasıdır.

```rust
#[derive(Debug, PartialEq, Eq)]
pub struct Ayar<'a> { pub anahtar: &'a str, pub deger: &'a str }

pub struct Ayristirici<'a> { kalan: &'a str }

impl<'a> Ayristirici<'a> {
    pub fn yeni(girdi: &'a str) -> Self { Ayristirici { kalan: girdi } }

    // Dönüşteki 'a KRİTİK: sonuç ayrıştırıcıya değil GİRDİ METNİNE bağlı.
    pub fn sonraki(&mut self) -> Option<Ayar<'a>> {
        while !self.kalan.is_empty() {
            let (parca, gerisi) = self.kalan.split_once(';').unwrap_or((self.kalan, ""));
            self.kalan = gerisi;
            if let Some((anahtar, deger)) = parca.split_once('=') {
                return Some(Ayar { anahtar: anahtar.trim(), deger: deger.trim() });
            }
        }
        None
    }
}

impl<'a> Iterator for Ayristirici<'a> {
    type Item = Ayar<'a>;
    fn next(&mut self) -> Option<Ayar<'a>> { self.sonraki() }
}
```

1. Burada iki ömür vardır ve karıştırmak en sık yapılan hatadır: `'a` girdi metninin ömrüdür (uzun), `&mut self` ise ayrıştırıcının o anki ödünç süresidir (tek çağrı, çok kısa). Dönüşte `'a` yazmasaydık elision'ın 3. kuralı devreye girer, sonuç `&mut self`'e bağlanırdı; o zaman ikinci `sonraki()` çağrısı **E0499: cannot borrow `ayr` as mutable more than once** verirdi. (E0501 bu durumun hatası değildir; doğru kod **E0499** üretir.) `'a` yazarak ayrıştırıcı çağrı bitince serbest kalır, hatta düşürülse bile sonuçlar geçerlidir.
   ↳ Kaynak: [Book ch10-03 — Lifetime Elision Rules](https://doc.rust-lang.org/book/ch10-03-lifetime-syntax.html#lifetime-elision-in-function-signatures) · [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html)

2. Alıcıya struct'ın kendi parametresini yazmak (`&'a mut self`) yanlıştır: "beni, içimdeki verinin tüm ömrü boyunca özel olarak ödünç al" demektir; ilk çağrıdan sonra değer kilitlenir. Doğrusu alıcıyı etiketsiz bırakmaktır (`&mut self`); derleyici her çağrıya kısa, taze bir ödünç süresi verir.
   ↳ Kaynak: [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html) · [Book ch10-03](https://doc.rust-lang.org/book/ch10-03-lifetime-syntax.html)

3. `Iterator` uygulamak tam olarak bu imzayı ister: `type Item = Ayar<'a>` girdiye bağlıdır, `&mut self`'e bağlanamaz. "Ödünç veren iterator" (lending iterator) gerektiğinde devreye giren GAT bu dosyada yoktur; ileri lifetime konularına bırakılmıştır.
   ↳ Kaynak: [Rustdoc — Iterator](https://doc.rust-lang.org/std/iter/trait.Iterator.html) · [Reference — Traits](https://doc.rust-lang.org/reference/items/traits.html)

4. Dilimlerin gerçekten girdinin içine baktığı adresle doğrulanır: `girdi.as_bytes().as_ptr_range().contains(&ayarlar[0].deger.as_ptr())` → `true`. Girdi ölürse sonuçlar da kullanılamaz (**E0597**); sonuçların girdiden uzun yaşaması gerekiyorsa o noktada sahipli türe (`String` / `to_owned`) geçmek gerekir. Sıfır kopya bir optimizasyondur; ömürler karmaşıklaşıyorsa kopyalamak meşrudur.
   ↳ Kaynak: [Rustdoc — slice::as_ptr_range](https://doc.rust-lang.org/std/primitive.slice.html#method.as_ptr_range) · [Rustdoc — ToOwned](https://doc.rust-lang.org/std/borrow/trait.ToOwned.html)

## 3. 'static ne demek?

İki ayrı kullanım vardır ve ikincisi sürekli yanlış anlaşılır:

- `&'static T` → bu **referans** program sonuna dek geçerlidir (string literal'leri, `static` değerler).
- `T: 'static` → bu **tür**, `'static`'ten kısa ömürlü bir referans içermez. Değerin kendisi her an düşürülebilir! `String`, `Vec<u8>`, `i32` hepsi `'static`'tir, çünkü kimseye borçlu değillerdir.

Benzetme: `T: 'static` "bu çantada emanet eşya yok" demektir; çantanın sonsuza dek saklanacağı anlamına gelmez.

```rust
fn uzun_sure_sakla<T: Display + 'static>(deger: T) -> Box<dyn Display> {
    // Box<dyn Display> = Box<dyn Display + 'static> (varsayılan).
    Box::new(deger)
}
```

1. `Box<dyn Display>`'ın varsayılan süresi `'static`'tir; içine konan tür geçici bir referans taşımadığından emin olunmalıdır, yoksa kutu işaret ettiği veriden uzun yaşardı. `uzun_sure_sakla(String::from("kendi kitabım"))` ve `uzun_sure_sakla(42)` çalışır; `drop(kutu)` açıkça gösterir ki `'static` bir tür olması "hiç düşmez" demek değildir.
   ↳ Kaynak: [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html) · [Rustdoc — Box](https://doc.rust-lang.org/std/boxed/struct.Box.html)

2. Yerel bir değere referans `'static` değildir: `uzun_sure_sakla(&yerel)` **E0597** (`argument requires that yerel is borrowed for 'static`). Bound'u unutursan hata fonksiyonun içinde **E0310** (`the parameter type T may not live long enough`) olarak çıkar. Bu mesajları görünce referansı `'static` yapmaya çalışmak yanlış çözümdür; neredeyse her zaman doğru çözüm **sahipliği vermektir**: `&yerel` yerine `yerel`. `'static` bound'unu "referans verme, değerin kendisini ver" diye oku.
   ↳ Kaynak: [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html) · [Book ch10-03 — 'static](https://doc.rust-lang.org/book/ch10-03-lifetime-syntax.html#the-static-lifetime)

## 4. Generic veri yapısı: bound'u nereye koymalı?

Pahalı bir hesabı (veritabanı sorgusu, dosya okuma) anahtara göre önbelleğe alan `Onbellek<K, V>` yazıyoruz. Hangi anahtar/değer türüyle kullanılacağını bilmediğimiz için generic'tir. Okula kayıt olurken kimse "yüzme biliyor musun?" diye sormaz; bu soru havuzun kapısında sorulur.

```rust
pub struct Onbellek<K, V> {
    kayitlar: HashMap<K, V>, isabet: u32, iska: u32,
}

impl<K, V> Onbellek<K, V> {                 // şart yok: her K, V için var
    pub fn yeni() -> Self { Onbellek { kayitlar: HashMap::new(), isabet: 0, iska: 0 } }
    pub fn istatistik(&self) -> (u32, u32) { (self.isabet, self.iska) }
}

impl<K: Eq + Hash, V> Onbellek<K, V> {       // şart kapıda
    pub fn getir_ya_da_uret(&mut self, anahtar: K, uret: impl FnOnce(&K) -> V) -> &V {
        match self.kayitlar.entry(anahtar) {
            Entry::Occupied(dolu) => { self.isabet += 1; dolu.into_mut() }
            Entry::Vacant(bos) => {
                self.iska += 1;
                let deger = uret(bos.key());
                bos.insert(deger)
            }
        }
    }
}
```

1. Bound'lar struct'a değil, ihtiyacı olan `impl`'e konur: struct'a konan bound o türün geçtiği her imzaya kopyalanır. std de böyledir: `HashMap<K, V>`'de bound yok, `K: Eq + Hash` `insert`/`get` impl'indedir.
   ↳ Kaynak: [Rustdoc — HashMap](https://doc.rust-lang.org/std/collections/struct.HashMap.html) · [Book ch10-02 — Trait Bounds](https://doc.rust-lang.org/book/ch10-02-traits.html#trait-bounds)

2. `entry()` anahtarı bir kez arar ve "dolu / boş" yuvayı döndürür. Klasik `if let Some(v) = map.get(&k) { return v; } map.insert(k, ..)` yazımı borrow checker'a takılır; `Entry` API deyimsel çözümdür ve iki arama yerine tek arama yapar. `uret` yalnız değer YOKSA çağrılır → `FnOnce` yeter (en fazla **bir kez** çağrılabilen closure); dönüş `&V` değer önbellekte yaşar, çağırana ödünç verilir.
   ↳ Kaynak: [Rustdoc — HashMap::entry](https://doc.rust-lang.org/std/collections/struct.HashMap.html#method.entry) · [Rustdoc — FnOnce](https://doc.rust-lang.org/std/ops/trait.FnOnce.html)

3. Koşullu metotlar ayrı `impl` bloklarına konur: `impl<K: Ord + Display, V: Display>` altındaki `dokum()` yalnız anahtarı sıralanabilir, içeriği yazdırılabilir defterlerde vardır; diğer türlerde metot görünmez. `HashMap` sırası belirsiz olduğu için satırlar önce `sort_by` ile sıralanır.
   ↳ Kaynak: [Rustdoc — Ord](https://doc.rust-lang.org/std/cmp/trait.Ord.html) · [Rustdoc — HashMap](https://doc.rust-lang.org/std/collections/struct.HashMap.html)

4. Sık hatalar: `fn buyuk<T>(a: T, b: T) -> T { if a > b { a } else { b } }` → **E0369**, `T` hakkında yalnız bound'ların söylediği bilinir; `let n = "5".parse().unwrap()` → **E0284**, hedef tür yazılmalı; `struct Baslik { metin: &str }` → **E0106**, struct alanlarında elision yok, ya `'a` ya açık `'static` gerekir. C++ template'lerinden farklı olarak hata kullanım yerinde değil, tanım yerinde ve bir kez çıkar.
   ↳ Kaynak: [Book ch10-01](https://doc.rust-lang.org/book/ch10-01-syntax.html) · [Book ch10-03](https://doc.rust-lang.org/book/ch10-03-lifetime-syntax.html)

## 5. Associated type mi, generic parametre mi?

İkisi de "trait içinde bir tür değişkeni"dir; farkı o türü **kimin seçtiğidir**:

| Şekil | Anlamı | Örnek |
| --- | --- | --- |
| `trait Ayristir { type Cikti; }` | Çıktıyı uygulayan tür belirler; bir tür için tek cevap vardır. | `Iterator::Item`, `Deref::Target`, `Add::Output` |
| `trait Donustur<T> { .. }` | `T`'yi çağıran seçer; aynı tür birçok `T` için ayrı ayrı uygulanabilir. | `From<T>`: `String` hem `From<&str>` hem `From<char>` uygular |

Ölçüt şu sorudur: "Bu tür için birden fazla anlamlı cevap olabilir mi?" Hayırsa associated type seçilir; çağıranı her yerde tür yazmaktan kurtarır ve belirsizliği baştan kapatır.

```rust
pub trait Ayristir {
    type Cikti;
    fn ayristir(&self, ham: &str) -> Option<Self::Cikti>;
}
impl Ayristir for TamSayi {           // TamSayi → i64 (tek cevap)
    type Cikti = i64;
    fn ayristir(&self, ham: &str) -> Option<i64> { ham.trim().parse().ok() }
}
pub fn hepsini_ayristir<A: Ayristir>(a: &A, girdiler: &[&str]) -> Vec<A::Cikti> {
    girdiler.iter().filter_map(|g| a.ayristir(g)).collect()
}
```

1. Tek generic fonksiyon her ayrıştırıcıyla çalışır; dönüş türü `A::Cikti` ayrıştırıcıdan otomatik gelir, çağıran `hepsini_ayristir::<TamSayi, i64>` gibi ikinci bir parametre yazmaz. Aynı türe ikinci bir `type Cikti` ataması yapılamaz: cevap tektir.
   ↳ Kaynak: [Reference — Associated Types](https://doc.rust-lang.org/reference/items/traits.html#associated-types) · [Rustdoc — Iterator::Item](https://doc.rust-lang.org/std/iter/trait.Iterator.html#associatedtype.Item)

## Sık yapılan hatalar

| Yanlış kullanım | Hata | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| `fn on_eki_at_siki<'a>(metin: &'a str, on_ek: &'a str) -> &'a str` sonucu blok dışında kullanmak | **E0597** | Sonuç gereksiz yere `on_ek`'e bağlandı; çıktıya katkı vermeyen parametreye `'a` verme. | [Book ch10-03](https://doc.rust-lang.org/book/ch10-03-lifetime-syntax.html) |
| `fn sonraki(&mut self) -> Option<Ayar<'_>>` ile iki sonuç tutmak | **E0499** | Elision sonucu `&mut self`'e bağlar; dönüşe `'a` yaz. (E0501 doğru kod değildir.) | [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html) |
| `fn sonraki(&'a mut self)` | **E0499** | Alıcı struct parametrini taşırsa ilk çağrıdan sonra kilitlenir; alıcıyı etiketsiz bırak. | [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html) |
| `uzun_sure_sakla(&yerel)` / bound'u unutmak | **E0597 / E0310** | `'static` "borçlu değil" demektir; referans yerine sahipli değer ver. | [Book ch10-03](https://doc.rust-lang.org/book/ch10-03-lifetime-syntax.html) |
| `struct Baslik { metin: &str }` | **E0106** | Alanlarda elision yok; lifetime parametresi ya da açık `'static` gerekir. | [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html) |
| Bound'u struct tanımına koymak | derlenir ama kısıtlar | Şartı yalnız ihtiyacı olan `impl` bloğuna koy; `HashMap<K, V>` kalıbını izle. | [Rustdoc — HashMap](https://doc.rust-lang.org/std/collections/struct.HashMap.html) |

## Derleyici perspektifi

- **Lifetime erasure:** lifetime'lar çalışma anında YOKTUR. Yukarıdaki sıfır kopyalı ayrıştırıcı, C'deki pointer+uzunluk koduyla aynı makine koduna derlenir; fark, sarkan pointer'ın imkânsız olmasıdır. Derleme sonrası üretilen kodda etiketler yer tutmaz.
  ↳ Kaynak: [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html) · [rustc 1.99.1 — late.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_lint/src/late.rs)

- **Trait bound ve associated type çözümü** trait selection aşamasında yapılır; generic gövde yalnız bound'ların verdiği yetenekleri kullanabilir. `A::Cikti` tek türle çözümlenir, bu yüzden çağıranın ek tür parametresi yazmasına gerek kalmaz.
  ↳ Kaynak: [Reference — Associated Types](https://doc.rust-lang.org/reference/items/traits.html#associated-types) · [Reference — Traits](https://doc.rust-lang.org/reference/items/traits.html)

- **Monomorphization vs `dyn`:** generic kod kullanılan her tür için kopyalanır (`rustc_monomorphize/src/collector.rs`); `Box<dyn Trait>` ise tek kod + vtable kullanır. `dyn` tarafında varsayılan `'static` süresi, kutunun içindeki türün geçici referans taşımamasını garanti eder.
  ↳ Kaynak: [rustc 1.99.1 — collector.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_monomorphize/src/collector.rs) · [Book ch18-02](https://doc.rust-lang.org/book/ch18-02-trait-objects.html)

## Özet ve sonraki adım

- Lifetime etiketi bir süre uzatmaz, bir ilişki bildirir; çıktı hangi girdiden türetildiyse yalnız o girdiyle etiketlenir.
- `T: 'static` "içinde kısa ömürlü referans yok" demektir; çözüm çoğu zaman sahipliği vermektir.
- Bound'u struct'a değil ihtiyacı olan `impl`'e koy; tek anlamlı cevap varsa associated type, çok cevap varsa generic parametre kullan.

Alıştırmalar (kaynak dosyada): `en_uzun_deger<'a>` yazıp dönüşün girdi metnine bağlı olduğunu kanıtlamak, `Onbellek`'e `gecersiz_kil` eklemek ve `Ayristir`'ı `Vec<A>` için uygulamak.

Sıradaki bölüm: [10. Test Yazma](10-writing-tests.md) — bu imzaların ve sözleşmelerin `#[test]` ile nasıl sınandığını göreceğiz.
