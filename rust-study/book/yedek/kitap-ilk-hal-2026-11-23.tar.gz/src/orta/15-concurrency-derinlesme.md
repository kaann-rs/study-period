# 15.1 Eşzamanlılık: Derinleşme

> Kaynak dosya: `learn/concurrency/src/derinlesme.rs` · Test: `cargo test -p concurrency`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

Önceki sayfada üç yapı taşını gördük: `spawn` + `join`, kanal ve `Arc<Mutex<T>>`. Bu sayfada onları gerçek iş kalıplarına dönüştürüyoruz.

## Neden bu sayfa?

Thread açmak kolay, ama hangi aracı ne zaman seçeceğiniz programın yapısını belirler. Emin değilsen kanalla başla: sahiplik kimin dokunabileceğini söyler, kilit yoksa deadlock riski de yoktur. Paylaşımlı durum gerektiğinde ise kilidi olabildiğince kısa tutmak gerekir; Mutex doğruluğu sağlar, paralelliği değil.

## Mesajlaşma mı, paylaşım mı?

1. **Kanal (mesajlaşma):** veri bir thread'den ötekine taşınır, aynı anda tek sahibi vardır. İş hattı, görev dağıtımı ve olay akışına uygundur; deadlock riski düşüktür.
   ↳ Kaynak: [Book ch16-02 — Message Passing](https://doc.rust-lang.org/book/ch16-02-message-passing.html) · [Rustdoc — mpsc](https://doc.rust-lang.org/std/sync/mpsc/index.html)

2. **Paylaşımlı durum (`Arc<Mutex<T>>`):** veri yerinde durur, thread'ler sırayla erişir. Ortak tablo, önbellek, sayaç ve bağlantı havuzuna uygundur.
   ↳ Kaynak: [Book ch16-03 — Shared-State Concurrency](https://doc.rust-lang.org/book/ch16-03-shared-state.html) · [Rustdoc — Mutex](https://doc.rust-lang.org/std/sync/struct.Mutex.html)

## `thread::scope`: klonsuz ve Arc'sız ödünç

`thread::spawn` için closure `'static` olmalı, çünkü thread onu doğuran fonksiyondan uzun yaşayabilir. Yerel veriyi ödünç vermek istersen `E0373` alırsın. `thread::scope` ise "blok kapanmadan bütün thread'ler biter" güvencesini verir; derleyici bu yüzden `'static` şartını kaldırır ve düz `&`/`&mut` ödünçlere izin verir.

```rust
pub fn paralel_topla(veri: &[u64], parca_sayisi: usize) -> u64 {
    let parca_boyu = veri.len().div_ceil(parca_sayisi.max(1)).max(1);
    thread::scope(|kapsam| {
        let tutamaclar: Vec<_> = veri
            .chunks(parca_boyu)
            .map(|parca| kapsam.spawn(move || parca.iter().sum::<u64>()))
            .collect(); // ŞART: önce hepsini başlat, sonra hepsini bekle
        tutamaclar.into_iter().map(|t| t.join().unwrap()).sum()
    })
}
```

1. `chunks()` dilimi üst üste binmeyen parçalara böler; `chunks_mut()` ayrık `&mut` dilimler verir, böylece "aynı anda iki `&mut` yok" kuralı bozulmaz.
   ↳ Kaynak: [Rustdoc — slice::chunks](https://doc.rust-lang.org/std/primitive.slice.html#method.chunks) · [Rustdoc — slice::chunks_mut](https://doc.rust-lang.org/std/primitive.slice.html#method.chunks_mut)

2. `collect()` olmadan `.map(spawn).map(join)` her thread'i doğar doğmaz join eder; kod paralel görünür ama sırayla çalışır.
   ↳ Kaynak: [Rustdoc — Iterator::collect](https://doc.rust-lang.org/std/iter/trait.Iterator.html#method.collect) · [Rustdoc — thread::scope](https://doc.rust-lang.org/std/thread/fn.scope.html)

3. Kapsam kapanırken içeride doğan thread'ler otomatik join edilir; bu garanti olmasa yerel referanslar sarkardı.
   ↳ Kaynak: [Rustdoc — thread::scope](https://doc.rust-lang.org/std/thread/fn.scope.html) · [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html)

## Gerçek senaryo: işçi havuzu (worker pool)

Her iş için yeni thread açmak pahalıdır ve yük altında sınırsız thread doğurur. Havuz, eşzamanlılığı sabit sayıda işçiyle sınırlar; web sunucuları ve veri işleme hatları bu kalıbın üzerine kuruludur.

İki kanal kullanılır: iş kanalı (ana thread → işçiler) ve sonuç kanalı (işçiler → ana thread). `mpsc`'de alıcı tektir; N işçinin kuyruğu paylaşabilmesi için alıcı `Arc<Mutex<Receiver>>` içine konur. Buradaki Mutex veriyi değil, "sıradaki işi kim alacak"ı sıraya sokar.

```rust
pub fn havuzda_isle(isler: Vec<Is>, isci_sayisi: usize) -> Vec<Sonuc> {
    let (is_tx, is_rx) = mpsc::channel::<Is>();
    let (sonuc_tx, sonuc_rx) = mpsc::channel::<Sonuc>();
    let is_rx = Arc::new(Mutex::new(is_rx));

    let mut isciler = Vec::new();
    for _ in 0..isci_sayisi.max(1) {
        let is_rx = Arc::clone(&is_rx);
        let sonuc_tx = sonuc_tx.clone();
        isciler.push(thread::spawn(move || loop {
            // lock() geçici guard üretir: kilit iş alınır alınmaz bırakılır.
            let alinan = is_rx.lock().unwrap().recv();
            match alinan {
                Ok(is) => {
                    let kelime_sayisi = is.metin.split_whitespace().count();
                    if sonuc_tx.send(Sonuc { id: is.id, kelime_sayisi }).is_err() {
                        break;
                    }
                }
                Err(_) => break, // bütün gönderenler kapandı, kuyruk boş
            }
        }));
    }
    drop(sonuc_tx); // sonuç döngüsü sonsuza dek beklemesin
    for is in isler {
        is_tx.send(is).unwrap();
    }
    drop(is_tx); // "başka iş gelmeyecek" sinyali
    let mut sonuclar: Vec<Sonuc> = sonuc_rx.iter().collect();
    for isci in isciler {
        isci.join().unwrap();
    }
    sonuclar.sort_by_key(|s| s.id); // varış sırası belirsiz
    sonuclar
}
```

1. `while let Ok(is) = is_rx.lock().unwrap().recv()` yazsaydık guard döngü boyunca yaşar, havuz tek thread'e inerdi. Derlenir ama yanlış çalışır.
   ↳ Kaynak: [Rustdoc — MutexGuard](https://doc.rust-lang.org/std/sync/struct.MutexGuard.html) · [Book ch16-03 — Shared-State Concurrency](https://doc.rust-lang.org/book/ch16-03-shared-state.html)

2. `drop(is_tx)` ve `drop(sonuc_tx)` olmadan alıcı döngüleri hiç bitmez; kapanış sinyali sahiplik düşüşüyle gelir.
   ↳ Kaynak: [Book ch16-02 — Message Passing](https://doc.rust-lang.org/book/ch16-02-message-passing.html) · [Rustdoc — mpsc::Receiver](https://doc.rust-lang.org/std/sync/mpsc/struct.Receiver.html)

3. Varış sırası belirsiz olduğu için sonuçlar kimliğe göre sıralanır; her çalıştırmada aynı çıktı elde edilir.
   ↳ Kaynak: [Rustdoc — slice::sort_by_key](https://doc.rust-lang.org/std/primitive.slice.html#method.sort_by_key) · [Book ch16-00 — Fearless Concurrency](https://doc.rust-lang.org/book/ch16-00-concurrency.html)

## Kritik bölgeyi kısa tut

Kelime sıklığı örneğinde her kelime için kilidi alıp ortak tabloyu güncellemek derlenir ama yavaştır: thread'ler zamanını kilit sırası bekleyerek geçirir. Doğru yol, her thread'in kendi yerel tablosunu kilitsiz doldurup işi bitince kilidi bir kez alarak sonucu birleştirmedir.

```rust
pub fn kelime_sikligi(belgeler: &[&str]) -> BTreeMap<String, u32> {
    let ortak: Mutex<BTreeMap<String, u32>> = Mutex::new(BTreeMap::new());
    thread::scope(|kapsam| {
        for belge in belgeler {
            let ortak = &ortak; // Mutex'i taşımadan referansını ver
            kapsam.spawn(move || {
                let mut yerel: BTreeMap<String, u32> = BTreeMap::new();
                for kelime in belge.split_whitespace() {
                    *yerel.entry(kelime.to_lowercase()).or_insert(0) += 1;
                }
                let mut tablo = ortak.lock().unwrap(); // kısa kritik bölge
                for (kelime, adet) in yerel {
                    *tablo.entry(kelime).or_insert(0) += adet;
                }
            }); // `tablo` guard'ı burada düşer
        }
    });
    ortak.into_inner().unwrap() // tek sahibiz, kilitlemeye gerek yok
}
```

1. Kilit altında G/Ç yapma, uzun hesap yapma, başka kilit alma veya kullanıcı kodu çağırma; kilit çekişmesi paralelliği yer.
   ↳ Kaynak: [Book ch16-03 — Shared-State Concurrency](https://doc.rust-lang.org/book/ch16-03-shared-state.html) · [Rustdoc — Mutex](https://doc.rust-lang.org/std/sync/struct.Mutex.html)

2. Burada `Arc` yok: `thread::scope` sayesinde `&Mutex` ödünç vermek yeterlidir. Arc sahiplik sorununu, Mutex erişim sırasını çözer; sahiplik sorunu yoksa Arc gerekmez.
   ↳ Kaynak: [Rustdoc — thread::scope](https://doc.rust-lang.org/std/thread/fn.scope.html) · [Rustdoc — Arc](https://doc.rust-lang.org/std/sync/struct.Arc.html)

3. Guard'ın ömrü kilidin süresidir. Geçici guard deyim sonunda, değişkene bağlı guard kapsam sonunda düşer; gerekirse `drop(guard)` ile erken bırakılabilir.
   ↳ Kaynak: [Reference — Destructors](https://doc.rust-lang.org/reference/destructors.html) · [rustc 1.99.1 — poison/mutex.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/std/src/sync/poison/mutex.rs)

## Atomik sayaç: tek değer için Mutex gerekmez

Paylaşılan şey yalnızca bir sayaç ya da bayraksa işlemci düzeyinde bölünemez işlemler yeterlidir. `fetch_add` "oku + artır + yaz"ı tek hamlede yapar; iki thread aynı anda çağırsa bile artışlardan biri kaybolmaz.

```rust
pub fn paralel_say(thread_sayisi: u64, thread_basina: u64) -> u64 {
    let sayac = AtomicU64::new(0);
    thread::scope(|kapsam| {
        for _ in 0..thread_sayisi {
            kapsam.spawn(|| {
                for _ in 0..thread_basina {
                    sayac.fetch_add(1, Ordering::Relaxed);
                }
            });
        }
    });
    sayac.into_inner()
}
```

1. Bağımsız bir sayaç için `Ordering::Relaxed` yeterlidir; atomik bir değere bakıp başka veriye erişim kararı veriyorsan daha güçlü sıralama gerekir, emin değilsen `SeqCst` kullan.
   ↳ Kaynak: [Rustdoc — std::sync::atomic](https://doc.rust-lang.org/std/sync/atomic/index.html) · *Rust Atomics and Locks* (kitap)

2. Atomikler tek değeri korur. "Sayaç ile liste birlikte tutarlı kalsın" gibi birden çok değeri kapsayan değişmez (invariant) varsa yine Mutex gerekir.
   ↳ Kaynak: [Book ch16-03 — Shared-State Concurrency](https://doc.rust-lang.org/book/ch16-03-shared-state.html) · [Rustdoc — AtomicU64](https://doc.rust-lang.org/std/sync/atomic/struct.AtomicU64.html)

## Sık yapılan hatalar

| Kod / durum | Hata | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| `let veri = vec![…]; thread::spawn(\|\| println!("{veri:?}"));` | **E0373** | Closure`ı doğuran fonksiyondan uzun yaşayabilir; `move`, `Arc` ya da `thread::scope` kullan. | [Rustdoc — thread::spawn](https://doc.rust-lang.org/std/thread/fn.spawn.html) · [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html) |
| Arc klonlanıp `println!("{m:?}")` | **E0382** | Taşımadan önce `Arc::clone(&m)` çağır. | [Book ch16-03](https://doc.rust-lang.org/book/ch16-03-shared-state.html) |
| `Arc::new(vec![1])` içinde `v.push(2)` | **E0596** | Arc salt `&T` verir; `Arc<Mutex<Vec<_>>>` kullan. | [Rustdoc — Arc](https://doc.rust-lang.org/std/sync/struct.Arc.html) |
| `tx.send(mesaj); println!("{mesaj}");` | **E0382** | `send` sahipliği taşır; gönderen artık veriye erişemez. | [Book ch16-02](https://doc.rust-lang.org/book/ch16-02-message-passing.html) |
| `MutexGuard`'ı başka thread'e taşımak | **E0277** | Guard `!Send`'dir; kilit veriye dokunacak thread'in içinde alınmalı. | [poison/mutex.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/std/src/sync/poison/mutex.rs) · [marker.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/marker.rs) |
| Aynı thread'de kilitliyken tekrar `lock()` | derlenir, bloklar/panik | `try_lock` ile gözle; guard'ı bırakıp yeniden al. | [Rustdoc — Mutex::try_lock](https://doc.rust-lang.org/std/sync/struct.Mutex.html#method.try_lock) |
| İki kilit ters sırayla alınıyor | derlenir, **deadlock** | Her yerde aynı sırayla al; ya da `try_lock` ile geri çekil. | *Rust Atomics and Locks* (kitap) · [poison/mutex.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/std/src/sync/poison/mutex.rs) |
| Kilidi tutan thread panik etti | derlenir, Mutex **poison** olur | Sonraki `lock()` `Err` döner; veri tutarlıysa `unwrap_or_else(|z| z.into_inner())`. | [poison/mutex.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/std/src/sync/poison/mutex.rs) |

## Derleyici perspektifi

- **`thread::scope` bir ömür sözleşmesidir.** Kapsam kapanmadan tüm thread'lerin join edileceği garanti edildiği için derleyici `'static` kısıtını kaldırır; aksi halde `E0373` üretilir.
  ↳ Kaynak: [Rustdoc — thread::scope](https://doc.rust-lang.org/std/thread/fn.scope.html) · [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html)

- **`MutexGuard` bilinçli olarak `!Send`'dir.** Birçok işletim sisteminde kilidi, onu alan thread bırakmak zorundadır; bu yüzden guard başka thread'e taşınamaz (`E0277`).
  ↳ Kaynak: [rustc 1.99.1 — poison/mutex.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/std/src/sync/poison/mutex.rs) · [rustc 1.99.1 — marker.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/marker.rs)

- **Auto trait'ler tür silinince sızmaz.** Paylaşımlı çağrılarda `dyn Trait + Send + Sync` yazmak gerekir; aksi halde derleyici somut türün thread-güvenli olup olmadığını bilemez. Ayrıntı Böl. 17.1 ve Böl. 25'te.
  ↳ Kaynak: [rustc 1.99.1 — marker.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/marker.rs) · [Book ch16-04](https://doc.rust-lang.org/book/ch16-04-extensible-concurrency-sync-and-send.html)

- **Derleyici deadlock, kilit çekişmesi ve mantıksal yarışı yakalayamaz.** Bunlar program çalışırken belli olur; "korkusuz" sıfatı yalnızca veri yarışını kapsar.
  ↳ Kaynak: [Book ch16-00 — Fearless Concurrency](https://doc.rust-lang.org/book/ch16-00-concurrency.html) · [Nomicon — Aliasing](https://doc.rust-lang.org/nomicon/aliasing.html)

## Özet ve sonraki adım

- `thread::scope` yerel veriyi klonsuz ve Arc'sız ödünç verir; kapsam bitince thread'ler otomatik join edilir.
- İşçi havuzunda iki kanal ve kısa guard kullanılır; kilit sadece sırayı yönetir.
- Kilidi kısa tut, tek sayı için atomik kullan; deadlock ve poison derleyicinin dışındadır.

Bir sonraki bölüm: [16. Async / Await](16-async-await.md). Thread'ler işi gerçekten aynı anda koşturur; bekleyen çok işi az thread'le yürütmek async'in alanıdır.
