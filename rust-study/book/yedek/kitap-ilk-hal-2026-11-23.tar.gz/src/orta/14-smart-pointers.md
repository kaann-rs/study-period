# 14. Akıllı İşaretçiler

> Kaynak crate: `learn/smart-pointers` · Çalıştır: `cargo run -p smart-pointers`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

## Neden bu bölüm?

"Her verinin tek sahibi olur" kuralı çoğu programa yeter; ama bazen aynı veriyi birden çok kişi okumalı, ya da dışarıdan değişmez görünen bir şeyin içi güncellenmelidir. Akıllı işaretçiler tam bu durumlar için hazır kutulardır: bir adres tutar, yanında ek bilgi taşır ve her biri güvenliği **başka bir yolla** korur. Okul benzetmesiyle: kutu, paylaşılan top, nöbetçili defter ve sadece yeri hatırlatan not.

## 5 yaşındaki çocuğa anlatır gibi

Okulda birçok kutu var. Biri sadece senin (Box), birini arkadaşlarınla paylaşıyorsun (Rc), birinin içini öğretmen izin vermeden düzeltebiliyorsun (RefCell). İki defter birbirine "beni oku" diye not bırakırsa ikisi de çöpe atılamaz; bu yüzden biri sadece "nerede olduğunu" hatırlatır (Weak).

## Konu anlatımı (madde madde)

1. **Akıllı işaretçi, işaretçi gibi davranıp ek bilgi taşıyan kutudur.** Çoğu `Deref` ve `Drop` uygular; "ek bilgi" bir heap adresi, bir sahiplik sayacı ya da bir borrow sayacı olabilir. Bunlar sahiplik modelinin kaçış kapılarıdır; ilk tercih değildir.
   ↳ Kaynak: [Book ch15-00 — Smart Pointers](https://doc.rust-lang.org/book/ch15-00-smart-pointers.html) · [Rustdoc — Deref](https://doc.rust-lang.org/std/ops/trait.Deref.html)

2. **`Box<T>` değeri heap'e koyar, elinde sabit boylu bir adres tutar.** En yaygın kullanımı özyineli tiplerdir: `enum Liste { Dugum(i32, Box<Liste>), Son }` çalışır; `Box` olmadan tip kendini doğrudan içerir ve boyut sonsuz olur (**E0072**: recursive type has infinite size). Box tek sahiptir, ek çalışma anı yükü getirmez.
   ↳ Kaynak: [Book ch15-01 — Using Box to Store Data on the Heap](https://doc.rust-lang.org/book/ch15-01-box.html) · [rustc 1.99.1 — boxed.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/alloc/src/boxed.rs) · [Reference — recursive types](https://doc.rust-lang.org/reference/types.html#recursive-types)

3. **`Deref`, `*` operatörünü özelleştirir.** `*x` aslında `*(x.deref())` olarak çözülür. **Deref coercion** derleme anında zincirlenir: `&Kutum<String> → &String → &str`, böylece `&str` isteyen bir fonksiyona kutumuzu doğrudan verebiliriz. Tamamen statiktir, çalışma anı maliyeti yoktur.
   ↳ Kaynak: [Book ch15-02 — Deref Coercion](https://doc.rust-lang.org/book/ch15-02-deref.html) · [rustc 1.99.1 — deref.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/ops/deref.rs)

4. **`Drop`, değer kapsam dışına çıkınca otomatik temizlik demektir (RAII).** Temizlik kodunu sen yazmazsın; derleyici MIR drop-elaboration aşamasında çağrıyı ekler. Sıra ters tanım sırasıdır. `b.drop()` yasaktır (çift-drop olurdu); erken temizlik için `drop(b)` / `std::mem::drop` kullanılır.
   ↳ Kaynak: [Book ch15-03 — Drop Trait](https://doc.rust-lang.org/book/ch15-03-drop.html) · [rustc 1.99.1 — elaborate_drops.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_transform/src/elaborate_drops.rs) · [rustc 1.99.1 — drop.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/ops/drop.rs)

5. **`Rc<T>` tek veriye çok sahip verir (yalnız tek thread).** `Rc::clone(&a)` veriyi **kopyalamaz**, yalnız güçlü sayacı bir artırır; bir `Rc` düşünce sayaç azalır, sıfır olunca veri serbest kalır. `Rc` yalnız paylaşımlı `&` verir; içini değiştirtmez. Sayaç atomik olmadığı için çok thread gerekirse `Arc<T>` kullanılır (`library/alloc/src/rcs/arc.rs`).
   ↳ Kaynak: [Book ch15-04 — `Rc<T>`, Reference Counting](https://doc.rust-lang.org/book/ch15-04-rc.html) · [rustc 1.99.1 — rc.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/alloc/src/rcs/rc.rs) · [rustc 1.99.1 — arc.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/alloc/src/rcs/arc.rs)

6. **`RefCell<T>` iç değişkenlik sağlar: kuralı derleme anından çalışma anına taşır.** `borrow()` "bakacağım", `borrow_mut()` "yazacağım" der. Aliasing XOR Mutability kuralı kalkmaz; yalnız denetimin zamanı değişir. Aynı anda iki yazan olursa program panikler; güncel mesaj **`RefCell already borrowed`** (`core/src/cell.rs:917-922`, `panic_already_borrowed`).
   ↳ Kaynak: [Book ch15-05 — Interior Mutability with RefCell](https://doc.rust-lang.org/book/ch15-05-interior-mutability.html) · [rustc 1.99.1 — cell.rs:917-922](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/cell.rs#L917-L922)

7. **`Rc<RefCell<T>>` klasik birleşimdir:** çok sahip + değiştirilebilir durum. Örnekte üç `Rc` aynı sayacı paylaşır; biri `+10`, öteki `+5` yazar, ortak değer 15 olur. Bu birleşim **tek thread** içindir; çok thread'de karşılığı `Arc<Mutex<T>>` / `Arc<RwLock<T>>`dir.
   ↳ Kaynak: [Book ch15-05 — `Rc<RefCell<T>>`](https://doc.rust-lang.org/book/ch15-05-interior-mutability.html) · [rustc 1.99.1 — arc.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/alloc/src/rcs/arc.rs)

8. **`Weak<T>` sahip olmadan yerini bilir.** `Rc::downgrade` güçlü sayaca dokunmayan bir Weak üretir; `upgrade()` "gösterdiğim şey hâlâ yaşıyor mu?" diye sorar ve `Option<Rc<T>>` döner. Sarkan işaretçi imkânsızdır: Weak'i kullanmanın tek yolu bu soruyu sormaktır.
   ↳ Kaynak: [Book ch15-06 — `Weak<T>`](https://doc.rust-lang.org/book/ch15-06-reference-cycles.html) · [Rustdoc — Weak](https://doc.rust-lang.org/std/rc/struct.Weak.html)

9. **Referans döngüsü sayaçları 1'de kilitler.** İki veri birbirini `Rc` ile tutarsa dışarıdaki sahipler gitse bile sayaçlar sıfıra inmez; bellek geri verilmez. Rust bunu "güvenli" sayar — bellek bozulması değil, yalnız sızıntı vardır. Çözüm: döngünün bir yönünü `Weak` yapmaktır.
   ↳ Kaynak: [Book ch15-06 — Avoiding Reference Cycles with `Weak<T>`](https://doc.rust-lang.org/book/ch15-06-reference-cycles.html) · [Rustdoc — Rc::downgrade](https://doc.rust-lang.org/std/rc/struct.Rc.html#method.downgrade)

10. **Seçim üç soruyla yapılır:** kaç sahip var (Box / Rc / Arc), değer değişecek mi (`Cell` / `RefCell` / Mutex), sahip olmadan bilmek yeterli mi (Weak)? Bedelsiz olan yetiyorsa bedelli olana geçme; `Rc<RefCell<...>>` her yere yayılırsa derleme anındaki hatalar çalışma anı paniklerine dönüşür.
    ↳ Kaynak: [Book ch15-00 — Smart Pointers](https://doc.rust-lang.org/book/ch15-00-smart-pointers.html) · [Rustdoc — Cell](https://doc.rust-lang.org/std/cell/struct.Cell.html)

## Kodda nasıl görünür?

```rust
// learn/smart-pointers/src/main.rs — özet
use std::cell::RefCell;
use std::ops::Deref;
use std::rc::Rc;

#[derive(Debug)]
enum Liste {
    Dugum(i32, Box<Liste>), // Box olmadan: "recursive type has infinite size"
    Son,
}
fn topla(l: &Liste) -> i32 {
    match l {
        Liste::Dugum(deger, sonraki) => deger + topla(sonraki),
        Liste::Son => 0,
    }
}
fn box_ornegi() {
    use Liste::*;
    let liste = Dugum(1, Box::new(Dugum(2, Box::new(Son))));
    println!("cons list (Box): {liste:?}, toplam = {}", topla(&liste));
}

struct Kutum<T>(T);
impl<T> Kutum<T> {
    fn yeni(x: T) -> Kutum<T> { Kutum(x) }
}
impl<T> Deref for Kutum<T> {
    type Target = T;
    fn deref(&self) -> &T { &self.0 }
}
fn selamla(ad: &str) { println!("Selam, {ad}!"); }
fn deref_ornegi() {
    let k = Kutum::yeni(5);
    println!("*Kutum(5) = {}", *k); // Deref sayesinde *k çalışır (aslında *(k.deref()))
    let isim = Kutum::yeni(String::from("Kaan"));
    selamla(&isim); // &Kutum<String> --deref--> &String --deref--> &str
}

// Rc: aynı veriyi paylaşan üç sahip
let a = Rc::new(Dugum(5, Rc::new(Dugum(10, Rc::new(Son)))));
println!("a oluştu, sayaç = {}", Rc::strong_count(&a)); // 1
let b = Dugum(3, Rc::clone(&a)); // Rc::clone VERİYİ KOPYALAMAZ, sadece sayacı artırır
println!("b paylaştı, sayaç = {}", Rc::strong_count(&a)); // 2

// Rc<RefCell<T>>: çok sahip + içi değişir
let ortak = Rc::new(RefCell::new(0_i32));
let a = Rc::clone(&ortak);
let b = Rc::clone(&ortak);
*a.borrow_mut() += 10;
*b.borrow_mut() += 5;
println!("ortak sayaç = {}", ortak.borrow()); // 15
```

## Sık yapılan hatalar

1. **Box'sız özyineli tip (`E0072`).** `enum Kotu { Halka(i32, Kotu), Son }` derlenmez: derleyici "recursive type has infinite size" der ve araya `Box`/`Rc`/`&` koymanı ister.
   ↳ Kaynak: [Book ch15-01 — Recursive Types with Box](https://doc.rust-lang.org/book/ch15-01-box.html) · [Reference — recursive types](https://doc.rust-lang.org/reference/types.html#recursive-types)

2. **Aynı anda iki `borrow_mut()`.** Bu derlenir ama çalışırken panikler: `RefCell already borrowed`. Kural kalkmadı, yalnız denetim çalışma anına kaydı (`core/src/cell.rs:917-922`). Emin değilsen `try_borrow_mut()` ile panik yerine `Result` al.
   ↳ Kaynak: [rustc 1.99.1 — cell.rs:917-922](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/cell.rs#L917-L922) · [Rustdoc — RefCell::try_borrow_mut](https://doc.rust-lang.org/std/cell/struct.RefCell.html#method.try_borrow_mut)

3. **`Rc`'nin içini değiştirmeye çalışmak (`E0594` / `E0596`).** `Rc` yalnız `Deref` uygular, `DerefMut` uygulamaz: başka sahipler de baktığı için `&mut` vermek aliasing kuralını çiğnerdi. Çözüm `Rc<RefCell<T>>` ya da `Rc::make_mut`.
   ↳ Kaynak: [Rustdoc — Rc](https://doc.rust-lang.org/std/rc/struct.Rc.html) · [Rustdoc — Rc::make_mut](https://doc.rust-lang.org/std/rc/struct.Rc.html#method.make_mut)

4. **İki yönü de `Rc` yapmak.** Ebeveyn ↔ çocuk birbirini güçlü tutarsa sayaç hiç 0 olmaz; sızıntı oluşur. Sahiplik yönü `Rc`, geri yön `Weak` olmalı; `upgrade()` ile "hâlâ duruyor mu?" diye sorulur.
   ↳ Kaynak: [Book ch15-06 — Reference Cycles](https://doc.rust-lang.org/book/ch15-06-reference-cycles.html) · [Rustdoc — Weak::upgrade](https://doc.rust-lang.org/std/rc/struct.Weak.html#method.upgrade)

5. **`Rc<RefCell<T>>`'yi thread'e taşımak (`E0277`).** `Rc` sayacı ve `RefCell` borrow sayacı atomik değildir; derleyici taşımayı reddeder. Çok thread'li karşılık `Arc<Mutex<T>>`dir (`library/alloc/src/rcs/arc.rs`).
   ↳ Kaynak: [Rustdoc — Send](https://doc.rust-lang.org/std/marker/trait.Send.html) · [rustc 1.99.1 — arc.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/alloc/src/rcs/arc.rs)

## Derleyici perspektifi

- **`Box<T>` (library/alloc/src/boxed.rs):** değeri heap'e koyar, kendisi sabit boyutlu adrestir. Özyineli tip boyutunu bu araya giren adres sayesinde bilinir kılar; aksi halde **E0072** üretilir. Deref + Drop uygular, ek runtime yükü yoktur.
  ↳ Kaynak: [rustc 1.99.1 — boxed.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/alloc/src/boxed.rs) · [Book ch15-01](https://doc.rust-lang.org/book/ch15-01-box.html)

- **Deref (library/core/src/ops/deref.rs):** `*x` = `*(x.deref())`. Deref coercion derleme anında zincirlenir; tamamen statiktir, çalışma anı maliyeti yoktur.
  ↳ Kaynak: [rustc 1.99.1 — deref.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/ops/deref.rs) · [Book ch15-02](https://doc.rust-lang.org/book/ch15-02-deref.html)

- **Drop (library/core/src/ops/drop.rs):** çağrıyı rustc'nin MIR **drop-elaboration** aşaması ekler (ayrıntı rustc-dev-guide'da; Book'un sahiplik bölümü MIR ayrıntısına girmez). `x.drop()` çağrısı yasaktır; otomatik çağrı bir de seninkinin gelirse çift-drop olurdu.
  ↳ Kaynak: [rustc 1.99.1 — drop.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/ops/drop.rs) · [rustc 1.99.1 — elaborate_drops.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_transform/src/elaborate_drops.rs) · [rustc-dev-guide — drop elaboration](https://github.com/rust-lang/rustc-dev-guide/blob/master/src/mir/drop-elaboration.md)

- **Rc (library/alloc/src/rcs/rc.rs):** veriyle birlikte güçlü sayacı tutar; `Rc::clone` sayacı +1 yapar, veriyi kopyalamaz. Sayaç sıradan tam sayıdır, atomik değildir → tek thread. Çok thread için `Arc` aynı dosya ailesinde `rcs/arc.rs` içindedir.
  ↳ Kaynak: [rustc 1.99.1 — rc.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/alloc/src/rcs/rc.rs) · [rustc 1.99.1 — arc.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/alloc/src/rcs/arc.rs)

- **RefCell (library/core/src/cell.rs):** borrow sayacını çalışma anında tutar; "bir `&mut` VEYA çok `&`" ihlal edilirse hemen panikler — güncel mesaj **`RefCell already borrowed`**, kaynak `cell.rs:917-922`. Bellek bozulması olmaz; hata olursa çökme olur.
  ↳ Kaynak: [rustc 1.99.1 — cell.rs:917-922](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/cell.rs#L917-L922) · [Book ch15-05](https://doc.rust-lang.org/book/ch15-05-interior-mutability.html)

> **Güvenlik notu:** Referans döngüsü Rust'ta "güvensiz" (unsafe/UB) sayılmaz; yalnız işi biten veri geri verilmez. `Weak` olmasa da bellek bozulmaz, ama uzun yaşayan bir programda sızıntı büyür.
> ↳ Kaynak: [Book ch15-06 — Reference Cycles](https://doc.rust-lang.org/book/ch15-06-reference-cycles.html) · [Rustdoc — Weak](https://doc.rust-lang.org/std/rc/struct.Weak.html)

## Özet ve sonraki adım

- Box tek sahip + heap, Rc çok sahip + sayaç, RefCell çalışma anında borrow denetimi, Weak sahipsiz bakış.
- Özyineli tip `Box` ister (**E0072**); iki `borrow_mut` çalışırken **`RefCell already borrowed`** paniği verir.
- Döngünün bir yönü `Weak` olmalı; `Arc` yolu `rcs/arc.rs`'tir ve çok thread içindir.

Sıradaki sayfada [14.1 Akıllı İşaretçiler: Derinleşme](14-smart-pointers-derinlesme.md) bölümünde bu araçları tek bir ağaç veri yapısında birlikte kullanıp sızıntıyı gözle göreceğiz.
