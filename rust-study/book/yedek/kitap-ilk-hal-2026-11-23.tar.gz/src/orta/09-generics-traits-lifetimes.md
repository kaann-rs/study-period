# 9. Generic, Trait ve Lifetime

> Kaynak crate: `learn/generics-traits-lifetimes` · Çalıştır: `cargo run -p generics-traits-lifetimes`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

## Neden bu bölüm?

Sınıfta "en uzununu bul" oyununu öğrencilerle de oynarsın, kalemlerle de; kural hep aynıdır. Üç araç da aynı amaca hizmet eder: tekrarı azaltmak ve derleme zamanında güvenliği korumak. Generic "farklı türler için tek kod", trait "farklı türlerin ortak davranışı", lifetime ise "referansların ne kadar geçerli kaldığı" bilgisidir.

## 5 yaşındaki çocuğa anlatır gibi

Bir kâğıt formun var; adını yazınca herkes kullanabilir. Formun üstünde "imza atabilen" yazıyor; yani kalemi olan herkes doldurabilir. Bir de not var: "bu form yalnız bugün geçerli". Süre bitince form işe yaramaz.

## Konu anlatımı (madde madde)

1. **Generic `<T>` bir tür parametresidir.** `fn en_buyuk<T: PartialOrd>(liste: &[T]) -> &T` gövdesi tek kez yazılır, `i32` ile de `char` ile de çalışır. Generics olmasaydı aynı kodu her tür için kopyalardın; bir kopyadaki hatayı düzeltip ötekini unutmak kolaylaşırdı.
   ↳ Kaynak: [Book ch10-01 — Generic Data Types](https://doc.rust-lang.org/book/ch10-01-syntax.html) · [Book ch10-00 — Generics](https://doc.rust-lang.org/book/ch10-00-generics.html)

2. **Trait bound, "T her tür olamaz" der.** `T: PartialOrd` olmadan `a > b` kullanılamaz (E0369); bound sağlanmazsa daha derlemede **E0277** alınır. Rust'ta "ördek tipi" yoktur: metodu çağırmak için o türün ilgili trait'i uyguladığı kanıtlanmalıdır.
   ↳ Kaynak: [Book ch10-02 — Trait Bounds](https://doc.rust-lang.org/book/ch10-02-traits.html#trait-bounds) · [Reference — Traits](https://doc.rust-lang.org/reference/items/traits.html)

3. **Generic struct ve `impl` bloğu aynı `<T>`'yi bildirir.** `struct Nokta<T> { x: T, y: T }` ile hem tam sayı hem ondalık nokta aynı tanımla kurulur; iki alan da aynı `T` olmak zorundadır. `impl<T> Nokta<T>` "her T için bu metot" der.
   ↳ Kaynak: [Book ch10-01 — Generic Structs](https://doc.rust-lang.org/book/ch10-01-syntax.html#in-struct-definitions)

4. **Metot belirli bir somut türe de bağlanabilir.** `impl Nokta<f64> { fn uzaklik(&self) -> f64 { (self.x * self.x + self.y * self.y).sqrt() } }` yalnız `f64` noktalarında vardır. Not: `sqrt` **f32'de de vardır**, tam sayılarda yoktur; buradaki kullanım `Nokta<f64>` içindir.
   ↳ Kaynak: [Rustdoc — f64::sqrt](https://doc.rust-lang.org/std/primitive.f64.html#method.sqrt) · [Rustdoc — f32::sqrt](https://doc.rust-lang.org/std/primitive.f32.html#method.sqrt)

5. **Trait, metot imzalarının kümesidir.** Başka dillerdeki interface'e yakındır; zorunlu metotların yanında varsayılan gövde verilebilir ve tür isterse onu ezer. `Ozet` trait'inde `yazar()` zorunlu, `ozetle()` varsayılandır; `Haber` varsayılanı ezer, `Tweet` ezmez.
   ↳ Kaynak: [Book ch10-02 — Traits](https://doc.rust-lang.org/book/ch10-02-traits.html) · [Reference — Traits](https://doc.rust-lang.org/reference/items/traits.html)

6. **`impl Trait` ile `T: Trait` eşdeğer yazımlardır.** `fn duyur(x: &impl Ozet)` ve `fn _duyur_uzun<T: Ozet>(x: &T)` aynı sözleşmeyi anlatır. Statik dispatch'te her somut tür için ayrı kod üretilir; `dyn Ozet` ise tek kod + vtable kullanır, farklı türleri tek `Vec`'te tutmanı sağlar ve bedeli bir pointer dolaylamasıdır.
   ↳ Kaynak: [Book ch10-02 — impl Trait](https://doc.rust-lang.org/book/ch10-02-traits.html#impl-trait) · [Book ch18-02 — Trait Objects](https://doc.rust-lang.org/book/ch18-02-trait-objects.html)

7. **Blanket impl bir kuralla her türe trait verir.** `impl<T: Display> Etiket for T` "Display sözünü veren her türe `Etiket`'i de ver" der; std'deki `impl<T: Display> ToString for T` aynı kalıptır. `42.etiket()` ve `"ada".etiket()` çalışır, `Vec` için çalışmaz.
   ↳ Kaynak: [Rustdoc — ToString](https://doc.rust-lang.org/std/string/trait.ToString.html) · [Reference — Traits](https://doc.rust-lang.org/reference/items/traits.html)

8. **Lifetime bir süre değil, referanslar arasındaki ilişkiyi bildiren generic parametredir.** `'a` yeni bir ömür yaratmaz; var olan ömürlerin ilişkisini derleyiciye söyler. `fn en_uzun<'a>(x: &'a str, y: &'a str) -> &'a str` imzası "dönen referans iki girdinin de yaşadığı ortak bölge kadar geçerli" der; etiket iade tarihini uzatmaz.
   ↳ Kaynak: [Book ch10-03 — Lifetime Syntax](https://doc.rust-lang.org/book/ch10-03-lifetime-syntax.html) · [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html)

9. **Referans tutan struct'ta lifetime zorunludur.** `struct Alinti<'a> { parca: &'a str }` "bu struct, içindeki referans yaşadığı sürece geçerli" der. Alanlarda elision yoktur: her referans alanı ya bir lifetime parametresi ya da **açık `'static`** bildirir; hiçbiri yoksa **E0106** çıkar.
   ↳ Kaynak: [Book ch10-03 — Lifetimes in Structs](https://doc.rust-lang.org/book/ch10-03-lifetime-syntax.html#validating-references-with-lifetimes) · [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html)

10. **Elision, belli olan lifetime'ı derleyici doldurur.** Üç kural vardır: her referans parametre kendi süresini alır; tek girdi süresi varsa tüm çıktılara verilir; metotta `&self` varsa onun süresi çıktıya verilir. Kurallar çıktıyı tek bir süreye bağlayamazsa derleyici tahmin yürütmez, **E0106** ile etiket ister. `fn parca(&self) -> &str` bu yüzden etiketsiz yazılabilir.
    ↳ Kaynak: [Book ch10-03 — Lifetime Elision Rules](https://doc.rust-lang.org/book/ch10-03-lifetime-syntax.html#lifetime-elision-in-function-signatures) · [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html)

11. **`'static` program boyunca geçerli özel süredir.** String literal'leri ikiliye gömülür ve `'static`'tir. Her yere `'static` yazmak çözüm değildir: yerel bir `String`'e referans döndürmeye çalışıyorsan gerçek sorun sarkan (dangling) referanstır, süre etiketini uzatmak değil; sahipliği döndür.
    ↳ Kaynak: [Book ch10-03 — 'static](https://doc.rust-lang.org/book/ch10-03-lifetime-syntax.html#the-static-lifetime) · [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html)

## Kodda nasıl görünür?

```rust
use std::fmt::Display;

fn en_buyuk<T: PartialOrd>(liste: &[T]) -> &T {
    let mut en = &liste[0];
    for x in liste {
        if x > en { en = x; }
    }
    en
}

#[derive(Debug)]
struct Nokta<T> { x: T, y: T }
impl<T> Nokta<T> {
    fn x(&self) -> &T { &self.x }
}
impl Nokta<f64> {
    fn uzaklik(&self) -> f64 {
        (self.x * self.x + self.y * self.y).sqrt() // sqrt f32'de de var; burada Nokta<f64>
    }
}

fn en_uzun<'a>(x: &'a str, y: &'a str) -> &'a str {
    if x.len() > y.len() { x } else { y }
}

struct Alinti<'a> { parca: &'a str }
impl<'a> Alinti<'a> {
    fn parca(&self) -> &str { self.parca } // elision: Kural 3 (&self)
}

trait Etiket { fn etiket(&self) -> String; }
impl<T: Display> Etiket for T {
    fn etiket(&self) -> String { format!("[{self}]") }
}
```

## Sık yapılan hatalar

| Kod | Hata | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| `fn buyuk<T>(a: T, b: T) -> bool { a > b }` | **E0369** | `T` karşılaştırılabileceğini söylemiyor; `T: PartialOrd` ekle. | [Book ch10-01](https://doc.rust-lang.org/book/ch10-01-syntax.html) |
| `fn duyur(x: &impl Ozet) { .. }` ama türe `Ozet` uygulanmamış | **E0277** | Trait bound kanıtlanmalı; `impl Ozet for ...` yaz. | [Book ch10-02](https://doc.rust-lang.org/book/ch10-02-traits.html) |
| `fn f(x: &impl Ozet) { x.olmayan_metot(); }` | **E0599** | Metot trait'te yok; imzayı doğru trait ile sıkılaştır. | [rustc 1.99.1 — probe.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_hir_typeck/src/method/probe.rs) |
| `fn f() -> &str { .. }` / `struct S { metin: &str }` | **E0106** | Çıktı hangi girdiye bağlı? / alanlarda elision yok; `'a` ya da açık `'static` yaz. | [Book ch10-03](https://doc.rust-lang.org/book/ch10-03-lifetime-syntax.html) |
| `fn uret() -> Self` içeren trait'ten `dyn Trait` yapmak | **E0038** | Trait dyn-compatible olmalı; vtable hangi somut türü kuracağını bilemez. | [Book ch18-02](https://doc.rust-lang.org/book/ch18-02-trait-objects.html) |
| trait de tür de başkasına aitken `impl YabanciTrait for YabanciTür` | **E0117** | Orphan rule (tutarlılık) engeller. | [Book ch10-02](https://doc.rust-lang.org/book/ch10-02-traits.html#implementing-a-trait-on-a-type) |
| `let n = "5".parse().unwrap();` | **E0284** | Hedef türü derleyici tahmin etmez; `let n: u32 = ...` ya da `parse::<u32>()`. | [Rustdoc — str::parse](https://doc.rust-lang.org/std/primitive.str.html#method.parse) |

## Derleyici perspektifi

- **Monomorphization:** generic kod çalışma anında tür taşımaz. Derleyici kullanılan her somut tür için ayrı kopya üretir (`en_buyuk::<i32>` ve `en_buyuk::<char>` ayrı fonksiyonlardır); bu toplama `rustc_monomorphize/src/collector.rs` yapar. Sonuç hızlıdır (dolaylama yok) ama ikili büyür. Bir crate'deki generic, başka crate'de monomorphization üretebilir; ayrı derlemeyle uyumludur.
  ↳ Kaynak: [rustc 1.99.1 — collector.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_monomorphize/src/collector.rs) · [Book ch10-01](https://doc.rust-lang.org/book/ch10-01-syntax.html)

- **Trait bound çözümü** tür denetleyicide yapılır: `T: Ozet` sağlanmazsa **E0277**, trait'ten gelen metot bulunamazsa **E0599** çıkar. `dyn` tarafında dyn compatibility (eski adıyla object safety) kontrolü vardır; `Self` dönen veya generic metotlu trait'ler `dyn` olamaz (**E0038**), çünkü vtable'da hangi monomorphization'ın konacağı belli değildir.
  ↳ Kaynak: [Reference — Traits](https://doc.rust-lang.org/reference/items/traits.html) · [Book ch18-02](https://doc.rust-lang.org/book/ch18-02-trait-objects.html) · [rustc 1.99.1 — probe.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_hir_typeck/src/method/probe.rs)

- **Lifetime elision** üç kuralı isim çözümleme aşamasında uygulanır; kurallar çıktıyı bağlayamıyorsa sessiz kalınmaz, **E0106** verilir. Lifetime'lar yalnız derleme anında denetlenir: üretilen makine kodunda lifetime diye bir şey yoktur (**ömür silme / lifetime erasure**). Generics'te türler silinmez, monomorphization ile kopyalanır; "tür silme" trait object'ler için kullanılır.
  ↳ Kaynak: [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html) · [rustc 1.99.1 — late.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_lint/src/late.rs)

## Özet ve sonraki adım

- Generic tek gövdeyle çok tür, trait ortak davranışın sözünü, lifetime referansların ilişkisini verir; üçü de derleme anında denetlenir.
- Statik dispatch (monomorphization) hızlıdır; `dyn Trait` esnektir ve vtable + pointer dolaylaması maliyetlidir.
- Elision deterministik üç kuraldır; `'static` her yere yazılacak sihirli değil, özel bir süredir.

Sıradaki bölüm: [9.1 Jenerikler: Derinleşme](09-generics-traits-lifetimes-derinlesme.md) — imza yazarken etiketlerin çağıranı nasıl kıstığını, sıfır kopyalı ayrıştırıcıyı ve `T: 'static`'in gerçek anlamını göreceğiz.
