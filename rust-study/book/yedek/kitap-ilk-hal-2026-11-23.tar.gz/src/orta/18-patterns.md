# 18. Desenler (Patterns)

> Kaynak crate: `learn/patterns` · Çalıştır: `cargo run -p patterns`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

## Neden bu bölüm?

Bir kutunun kapağında yıldız, kare ve daire delikleri olsun: önce elindeki parçayı uygun deliğe tutarsın, sonra içinden çıkan boncuğa ad verirsin. Rust'ta bu işi *desen* (pattern) yapar; yalnız `match`te değil, `let`, döngüler ve fonksiyon parametrelerinde de aynı soru sorulur. Parçaları elle indekslemek yerine şekli bir kez tarif edersin; eksik kalan durumları derleyici yakalar.

## 5 yaşındaki çocuğa anlatır gibi

Kapağında yıldız, kare, daire delikleri olan oyuncak kutusu var. Elindeki parçayı hangi deliğe sokabileceğine bakarsın; girerse içindeki boncuğu alıp "buna Ali diyelim" dersin. Uymayan deliğe zorla sokamazsın.

## Konu anlatımı (madde madde)

1. **Desen, değerin yapısına göre eşleştirme ve parçaları bağlamadır.** `let (a, b, c) = (1, 2, 3);` üçlü demeti açıp parçalara ad verir; buna *destructuring* (yapı çözme) denir.
   ↳ Kaynak: [Book ch19-00 — Patterns and Matching](https://doc.rust-lang.org/book/ch19-00-patterns.html) · [Book ch19-02 — Pattern Syntax](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html)

2. **Aynı desen dilbilgisi birçok yerde çalışır.** `match` kollarının yanı sıra `let`, `if let`, `while let`, `for` ve fonksiyon/closure parametreleri de birer deliktir.
   ↳ Kaynak: [Book ch19-00 — Patterns and Matching](https://doc.rust-lang.org/book/ch19-00-patterns.html) · [Book ch13-01 — Closures](https://doc.rust-lang.org/book/ch13-01-closures.html)

3. **Reddedilemez (irrefutable) desen her değere uyar, reddedilebilir (refutable) desen bazılarına uymaz.** Düz `let`, `for` ve fonksiyon parametreleri yalnız reddedilemezi kabul eder; `let Some(x) = veri;` yazınca **E0005** gelir ve derleyici `let ... else` önerir.
   ↳ Kaynak: [Book ch19-02 — Refutability](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html) · [Book ch19-03 — The if let Syntax](https://doc.rust-lang.org/book/ch19-03-pattern-syntax.html)

4. **`if let` tek desene bakan kısa `match`, `while let` desen uydukça dönen döngüdür.** `let ... else` ise uymazsa `else` bloğunun kontrolü devralmasını sağlar; eşleşen değişken girinti almadan dışarıda kalır.
   ↳ Kaynak: [Book ch19-03 — The if let Syntax](https://doc.rust-lang.org/book/ch19-03-pattern-syntax.html) · [Book ch19-02 — Pattern Syntax](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html)

5. **Kollar yukarıdan aşağı sırayla denenir; ilk uyan kazanır.** Bu yüzden özel ve dar desenler üstte, genel yakalayıcılar altta durur.
   ↳ Kaynak: [Book ch19-01 — Match](https://doc.rust-lang.org/book/ch19-01-match.html) · [Book ch19-02 — Pattern Syntax](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html)

6. **Desen araçları tek bir dilbilgide birleşir.** Literal değerler, `|` (şu ya da bu), `..=` (aralık), struct/enum alanlarını açma, geri kalanı atlayan `..`, match guard'ı (`if ...`) ve `@` bağlaması aynı desende kullanılabilir.
   ↳ Kaynak: [Book ch19-02 — Pattern Syntax](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html)

7. **Guard, desenden sonraki ek sorudur.** Derleyici guard'ın içine bakmaz; bu yüzden guard'lı kollar "her durumu kapsadım" demeye yetmez, ayrı bir `_` kolu gerekebilir.
   ↳ Kaynak: [Book ch19-02 — Match Guards](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html) · [rustc 1.99.1 — check_match.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_build/src/thir/pattern/check_match.rs)

8. **`@` tek kolda iki işi birleştirir.** Alt deseni (örneğin `1..=5`) test ederken tutan değeri bir değişkene de bağlar; ayrı yazsan testi ya da bağlamayı kaybederdin.
   ↳ Kaynak: [Book ch19-02 — @ Bindings](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html) · [Reference](https://doc.rust-lang.org/reference/)

9. **Desendeki ad yeni bir bağlamadır.** Dışarıda aynı isimli değişken olsa bile `Some(y)` içindekine `y` adını verir; dıştaki `y` değişmez (*shadowing*).
   ↳ Kaynak: [Book ch03 — Common Programming Concepts](https://doc.rust-lang.org/book/ch03-00-common-programming-concepts.html) · [Book ch19-02 — Pattern Syntax](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html)

10. **Bütünlük denetimi derleme anında çalışır.** Açıkta durum kalırsa `E0004`, hiç çalışmayacak kol varsa "unreachable pattern" uyarısı gelir; `_` ve `..` "geri kalan her şey" der.
    ↳ Kaynak: [Book ch19-01 — Match](https://doc.rust-lang.org/book/ch19-01-match.html) · [rustc 1.99.1 — check_match.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_build/src/thir/pattern/check_match.rs)

## Kodda nasıl görünür?

```rust
fn konum(&(x, y): &(i32, i32)) -> String {
    format!("({x}, {y})")
}

fn reddedilebilirlik() {
    let veri: Option<i32> = Some(99);
    let Some(x) = veri else {
        println!("veri yok, çık");
        return;
    };
    println!("let-else ile bağlandı: x = {x}");
}

fn desen_yerleri() {
    let (a, b, c) = (1, 2, 3);
    println!("let destructuring: {a} {b} {c}");

    let renk: Option<&str> = Some("mavi");
    if let Some(r) = renk {
        println!("if let: renk {r}");
    } else {
        println!("if let: renk yok");
    }

    let mut yigin = vec![1, 2, 3];
    while let Some(ust) = yigin.pop() {
        print!("{ust} ");
    }
}
```

## Sık yapılan hatalar

| Kod / durum | Sonuç | Neden | Kaynak |
| --- | --- | --- | --- |
| `let Some(x) = veri;` | **E0005** | Reddedilebilir desen yerel bağlamada olamaz; derleyici `let ... else` önerir. | [Book ch19-02](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html) · [check_match.rs:657](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_build/src/thir/pattern/check_match.rs#L657) |
| `let (a, b) = (1, 2, 3);` | **E0308** | Desenin göz sayısı değerin parça sayısına uymalı. | [Book ch19-02](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html) · [Reference](https://doc.rust-lang.org/reference/) |
| `match n { x if x < 0 => .., x if x >= 0 => .. }` | **E0004** | Derleyici guard'ın içine bakarak bütünlük kanıtlamaz. | [Book ch19-02](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html) · [check_match.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_build/src/thir/pattern/check_match.rs) |
| Üstte `_ => ..` varken sonraki kol | `unreachable pattern` uyarısı | Önceki kol her şeyi yakalar. | [Book ch19-01](https://doc.rust-lang.org/book/ch19-01-match.html) · [rustc 1.99.1 — late.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_lint/src/late.rs) |
| `Komut::Ekle { ad, .. } \| Komut::Listele => println!("{ad}")` | **E0408** | `\|` ile birleşen her alternatif aynı isimleri bağlamalı. | [Book ch19-02](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html) · [Reference](https://doc.rust-lang.org/reference/) |

## Derleyici perspektifi

- **Reddedilebilirlik derleme anında hesaplanır.** `check_binding_is_irrefutable` (~657. satır) desenin değerin tüm olası biçimlerine uyup uymadığına bakar; uymayan hâl varsa düz `let` **E0005** ile reddedilir ve `let-else` önerilir.
  ↳ Kaynak: [rustc 1.99.1 — check_match.rs:657](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_build/src/thir/pattern/check_match.rs#L657) · [Book ch19-02](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html)

- **Bütünlük (exhaustiveness) ve faydalılık (usefulness) aynı analiz ailesindendir.** Kolların tüm durumları kapsayıp kapsamadığı ve bir kolun erişilemez olup olmadığı derlerken belirlenir; erişilemez kol uyarısı üretilir.
  ↳ Kaynak: [rustc 1.99.1 — check_match.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_build/src/thir/pattern/check_match.rs) · [rustc 1.99.1 — late.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_lint/src/late.rs)

- **Guard'lar desen analizinin dışındadır.** Derleyici ek koşulun ne zaman doğru olacağını bilemediği için guard'lı kolu "her zaman eşleşir" saymaz; bütünlük guard'a güvenerek tamamlanamaz.
  ↳ Kaynak: [Book ch19-02 — Match Guards](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html) · [rustc 1.99.1 — check_match.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_build/src/thir/pattern/check_match.rs)

- **Desenler tamamen derleme zamanı aracıdır.** Eşleştirme ve bağlama en sonda sıradan dallanma ile alan okumaya iner; çalışma anında "pattern" diye bir nesne yoktur.
  ↳ Kaynak: [Reference](https://doc.rust-lang.org/reference/) · [rustc 1.99.1 — check_match.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_build/src/thir/pattern/check_match.rs)

## Özet ve sonraki adım

- Desen, değerin şeklini tarif eder ve uyan parçalara ad verir; aynı dilbilgisi `match`, `let`, döngüler ve parametrelerde çalışır.
- Reddedilebilir desen düz `let`'e giremez; `if let`, `while let` ve `let ... else` bu durumu taşır.
- Bütünlük ve erişilemezlik derlerken denetlenir; guard bu denetimin dışında kalır.

Sıradaki sayfada [18.1 Desenler: Derinleşme](18-patterns-derinlesme.md) bölümünde bu araçları bir komut ayrıştırıcısında birlikte göreceğiz; bağlama modları, dilim desenleri ve `matches!` da orada.
