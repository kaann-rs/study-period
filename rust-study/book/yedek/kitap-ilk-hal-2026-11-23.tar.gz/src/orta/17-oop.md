# 17. Nesne Yönelimli Özellikler

> Kaynak crate: `learn/oop` · Çalıştır: `cargo run -p oop`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

## Neden bu bölüm?

Rust'ta nesne = veri + o veriyi kullanan davranıştır; kapsülleme vardır ama kalıtım (inheritance) yoktur. Ortak davranışı trait ile tarif eder, kod paylaşımını bileşimle (composition) yaparsın. Sonuç: yeni bir tür eklemek için çekirdek kodu değiştirmen gerekmez.

## 5 yaşındaki çocuğa anlatır gibi

Oyuncak kutusuna kırmızı araba, mavi tren, sarı top koyuyorsun. Hepsi farklı ama hepsi "yuvarlanabilir". Kutuya yeni bir oyuncak eklemek için kutuyu değiştirmen gerekmez; yeter ki o da yuvarlanabilsin.

## Konu anlatımı (madde madde)

1. **Rust OOP'nin bazı parçalarını destekler, kalıtımı bilinçli olarak almaz.** Nesne = veri + davranış ve kapsülleme vardır; sınıftan sınıf türetme yoktur. Yerine trait varsayılan metotları ve bileşim kullanılır.
   ↳ Kaynak: [Book ch18-00 — Object-Oriented Programming Features of Rust](https://doc.rust-lang.org/book/ch18-00-oop.html) · [Book ch18-01 — Characteristics of Object-Oriented Languages](https://doc.rust-lang.org/book/ch18-01-features-of-oop.html)

2. **Kapsülleme: private alan + invariant koruyan public API.** Alanlar `pub` değildir; dış dünya yalnızca `ekle` gibi açık düğmeleri kullanır. Böylece "ortalama hep güncel" kuralı tek yerde korunur ve iç temsil değiştirilebilir.
   ↳ Kaynak: [Book ch18-01 — Encapsulation](https://doc.rust-lang.org/book/ch18-01-features-of-oop.html) · [Reference — Visibility and Privacy](https://doc.rust-lang.org/reference/visibility-and-privacy.html)

3. **E0616 modül bazlı gizliliğin hatasıdır, tür bazlı değil.** Aynı modüldeki kod private alana erişebilir; bu yüzden `main.rs`'te `o.liste` derlenir. Tür ayrı bir `mod` içine konup dışından erişilince **E0616** alınır — invariant korumak için türü kendi moduna koymak gerekir.
   ↳ Kaynak: [Reference — Visibility and Privacy](https://doc.rust-lang.org/reference/visibility-and-privacy.html) · [Book ch18-01 — Encapsulation](https://doc.rust-lang.org/book/ch18-01-features-of-oop.html)

4. **Kalıtımın iki işi ayrılır: kod paylaşımı ve polimorfizm.** Kod paylaşımı için trait varsayılan metotları + bileşim (bir türü başka türün alanı yapmak); polimorfizm için trait + generic (statik) ya da trait object (dinamik) kullanılır.
   ↳ Kaynak: [Book ch18-01 — Inheritance](https://doc.rust-lang.org/book/ch18-01-features-of-oop.html) · [Book ch10-02 — Traits](https://doc.rust-lang.org/book/ch10-02-traits.html)

5. **`dyn Trait` ile farklı türler tek listede durur.** `Vec<Box<dyn Ciz>>` heterojendir; `Ekran` somut türleri bilmez, yalnız "çizebilen bir şey" sözünü bilir. Yeni bileşen eklemek için `Ekran`'a dokunmak gerekmez (open/closed).
   ↳ Kaynak: [Book ch18-02 — Trait Objects](https://doc.rust-lang.org/book/ch18-02-trait-objects.html) · [Reference — Trait objects](https://doc.rust-lang.org/reference/items/traits.html)

6. **Trait object bir fat pointer'dır: veri işaretçisi + vtable işaretçisi.** Çağrılacak metot çalışma anında vtable'dan bulunur (dinamik dispatch). Bu yapının neden iki kelime olduğu Böl. 10'da ve [22. Boyut, DST ve Şişman İşaretçi](../ileri/22-sized-dst.md) sayfasında anlatılır; Böl. 15 (akıllı işaretçiler) bu atfın yeri değildir.
   ↳ Kaynak: [Book ch10-02 — Traits](https://doc.rust-lang.org/book/ch10-02-traits.html) · [Nomicon — Sized](https://doc.rust-lang.org/nomicon/sized.html)

7. **dyn uyumluluğu (dyn compatibility) gerekir.** `Self` dönen ya da generic metotlu trait'ler `dyn` yapılamaz (**E0038**); `where Self: Sized` ile metot vtable'ın dışında bırakılabilir, böylece trait dyn-uyumlu kalır.
   ↳ Kaynak: [Reference — Trait objects](https://doc.rust-lang.org/reference/items/traits.html) · [Book ch10-02 — Traits](https://doc.rust-lang.org/book/ch10-02-traits.html)

8. **Type-state: her durum ayrı bir türdür.** Klasik state pattern'de durum bir alanda tutulup çalışma anında kontrol edilir; Rust'ta `Taslak → Inceleme → Yayin` geçişi `self`'i tüketip yeni tür döndürür. Yanlış durumda yanlış metot çağırmak derlenmez.
   ↳ Kaynak: [Book ch18-03 — Object-Oriented Design Patterns](https://doc.rust-lang.org/book/ch18-03-object-oriented-design-patterns.html) · [Book ch04-01 — What is Ownership?](https://doc.rust-lang.org/book/ch04-01-what-is-ownership.html)

9. **Homojen ve sıcak yol için generic daha ucuzdur.** `K: Ciz` çağrı yerinde tek somut türe sabitlenir; derleyici her tür için kopya üretir (monomorphization), çağrı inline edilebilir. Heterojen liste veya eklenti mimarisi dyn gerektirir.
   ↳ Kaynak: [Book ch10-01 — Generic Data Types](https://doc.rust-lang.org/book/ch10-01-syntax.html) · [Book ch18-02 — Trait Objects](https://doc.rust-lang.org/book/ch18-02-trait-objects.html)

10. **`dyn` tek başına `Send`/`Sync` ya da ömür bilgisi taşımaz.** Tür silinince derleyici somut türün thread-güvenli olup olmadığını bilemez; `dyn Kanal + Send + Sync` ya da `+ 'a` sözünü çağıran yazar. Ayrıntı Böl. 17.1'de.
    ↳ Kaynak: [Book ch16-04 — Sync and Send](https://doc.rust-lang.org/book/ch16-04-extensible-concurrency-sync-and-send.html) · [rustc 1.99.1 — marker.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/marker.rs)

## Kodda nasıl görünür?

```rust
trait Ciz {
    fn ciz(&self) -> String;
}
struct Buton { etiket: String }
struct OnayKutusu { isaretli: bool }
impl Ciz for Buton {
    fn ciz(&self) -> String { format!("[ {} ]", self.etiket) }
}
impl Ciz for OnayKutusu {
    fn ciz(&self) -> String {
        format!("({}) seçim", if self.isaretli { "x" } else { " " })
    }
}

struct Ekran { bilesenler: Vec<Box<dyn Ciz>> }
impl Ekran {
    fn calistir(&self) {
        for b in &self.bilesenler {
            println!("  {}", b.ciz()); // dinamik dispatch (vtable)
        }
    }
}

// Type-state: geçiş eski değeri tüketir.
struct Taslak { icerik: String }
struct Inceleme { icerik: String }
struct Yayin { icerik: String }
impl Taslak {
    fn ekle(&mut self, s: &str) { self.icerik.push_str(s); }
    fn incelemeye_gonder(self) -> Inceleme { Inceleme { icerik: self.icerik } }
}
impl Inceleme {
    fn onayla(self) -> Yayin { Yayin { icerik: self.icerik } }
}
impl Yayin {
    fn icerik(&self) -> &str { &self.icerik } // yalnız Yayin'de var
}
```

## Sık yapılan hatalar

| Kod / durum | Hata | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| Tür başka `mod`'un private alanına erişiyor | **E0616** | Gizlilik modüle göredir; `pub` alan ya da erişim metodu ekle. | [Reference — Visibility](https://doc.rust-lang.org/reference/visibility-and-privacy.html) |
| `trait Ciz { fn kopya(&self) -> Self; }` + `&dyn Ciz` | **E0038** | `Self` dönen metot dyn-uyumsuzdur; `where Self: Sized` ile dışarıda bırak. | [Reference — Trait objects](https://doc.rust-lang.org/reference/items/traits.html) |
| `let v: Vec<dyn Ciz> = Vec::new();` | **E0277** | `dyn Ciz` boyutsuzdur (DST); `Vec<Box<dyn Ciz>>` kullan. | [Nomicon — Sized](https://doc.rust-lang.org/nomicon/sized.html) |
| `yazi.icerik();` — yazi hâlâ `Taslak` | derlenmez | `icerik()` yalnız `Yayin`'de var; önce `incelemeye_gonder().onayla()`. | [Book ch18-03](https://doc.rust-lang.org/book/ch18-03-object-oriented-design-patterns.html) |
| `yazi.ekle(...)` — `incelemeye_gonder(self)` sonrası | derlenmez (**E0382** sınıfı) | `self` tüketildi; eski değer artık yok. | [Book ch04-01](https://doc.rust-lang.org/book/ch04-01-what-is-ownership.html) |

## Derleyici perspektifi

- **Gizlilik modül ağacına göre çözülür.** Alan ve metotlar varsayılan private'tır, `pub` ile açılır; başka modülden erişimde rustc **E0616** üretir. Bu yüzden invariant'ı korumak için tür kendi moduna konur.
  ↳ Kaynak: [Reference — Visibility and Privacy](https://doc.rust-lang.org/reference/visibility-and-privacy.html) · [Book ch18-01](https://doc.rust-lang.org/book/ch18-01-features-of-oop.html)

- **Trait object = (veri-pointer, vtable-pointer).** vtable her somut tür için metot adreslerini tutar; çağrı çalışma anında oradan bulunur. Boyut ve `where Self: Sized` ayrıntısı Böl. 10 ve [ileri-sized-dst](../ileri/22-sized-dst.md) sayfasındadır.
  ↳ Kaynak: [Reference — Trait objects](https://doc.rust-lang.org/reference/items/traits.html) · [Nomicon — Sized](https://doc.rust-lang.org/nomicon/sized.html)

- **Statik ve dinamik dispatch ayrışır.** Generic çağrılar monomorphization ile tür başına kopya üretir (`rustc_monomorphize/src/collector.rs`), dyn çağrılar tek kopya kalır ama vtable dolaylaması öder.
  ↳ Kaynak: [rustc 1.99.1 — collector.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_monomorphize/src/collector.rs) · [Book ch10-01](https://doc.rust-lang.org/book/ch10-01-syntax.html)

- **Type-state tamamen derleme zamanında çalışır.** `self`'i tüketerek tür değiştiren metotlar, geçersiz durum kenarlarını sahiplik/borrow denetimiyle reddeder; çalışma anı kontrolü veya panik gerekmez.
  ↳ Kaynak: [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs) · [Book ch04-01](https://doc.rust-lang.org/book/ch04-01-what-is-ownership.html)

## Özet ve sonraki adım

- Kapsülleme modül bazlıdır (E0616); kalıtım yerine trait + bileşim vardır.
- `dyn Trait` heterojen listeyi açık tutar; fat pointer/vtable ayrıntısı Böl. 10 ve ileri-sized-dst'tedir.
- Type-state geçersiz durumları derlenmez kılar; generic sıcak yolda daha ucuzdur.

Bir sonraki sayfada [17.1 OOP: Derinleşme](17-oop-derinlesme.md) bölümünde genişletilebilir bildirim sistemi, dyn/generic/enum karşılaştırması ve `Box<dyn Trait>` klonlamayı göreceğiz.
