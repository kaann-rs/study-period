# 11. minigrep: Gerçek Bir Program

> Kaynak crate: `learn/minigrep` · Çalıştır (rust-study kökünden): `cargo run -p minigrep -- hiç learn/minigrep/siir.txt` · Test: `cargo test -p minigrep`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

## Neden bu bölüm?

Burada yeni bir kavram öğrenmiyoruz: önceki bölümlerin Result/`?`, lifetime, trait, closure/iterator ve test araçlarını gerçek bir komut satırı aracında birleştiriyoruz. Asıl ders şu: mantığı test edilebilir yere (`lib.rs`) koy, test edilmeyen kısmı (`main`) küçült. Program bir kelime ve dosya adı alır, o kelimenin geçtiği satırları bulur.

## 5 yaşındaki çocuğa anlatır gibi

Kütüphanede danışma masası var. Sen "masal" kelimesini soruyorsun, görevli kitabı tarayıp o kelimenin olduğu sayfaları gösteriyor. Kapıdaki kişi sadece soruyu alıp görevliye verir; aramayı o yapmaz.

## Konu anlatımı (madde madde)

1. **`Config` ayarları tek struct'ta toplar.** `sorgu` (aranan kelime), `dosya_yolu` (hangi dosya), `harf_duyarsiz` (büyük/küçük harf ayrımı var mı). Bilgiler dağınık dursaydı her fonksiyona üçünü ayrı ayrı taşırdın; biri eksik ya da yanlış sırada gidebilirdi.
   ↳ Kaynak: [Book ch12-01 — Accepting Command Line Arguments](https://doc.rust-lang.org/book/ch12-01-accepting-command-line-arguments.html) · [Book ch05-01 — Structs](https://doc.rust-lang.org/book/ch05-01-defining-structs.html)

2. **`Config::build` argüman iterator'ını alır.** İlk `next()` programın kendi adını atlar; sorgu veya dosya yolu yoksa programı çökertmez (paniklemez), `Err("sorgu verilmedi")` / `Err("dosya yolu verilmedi")` döndürür. Eksik argüman kullanıcının yanlışıdır, kullanıcıya çökme raporu değil anlaşılır cümle gerekir.
   ↳ Kaynak: [Book ch12-01 — Reading Arguments](https://doc.rust-lang.org/book/ch12-01-accepting-command-line-arguments.html#reading-the-argument-values-into-a-vector-and-returning-a-config-struct) · [Rustdoc — Iterator::next](https://doc.rust-lang.org/std/iter/trait.Iterator.html#method.next)

3. **`env::args()` bir iterator döndürür.** Doğrudan `Config::build`'e vermek sahipliği devralır, klon yoktur; önce `Vec`'e toplayıp `.clone()` yapmak gereksiz tahsis/kopya olurdu. `args()` geçersiz Unicode argümanda panik eder; `args_os()` `OsString` döndürür (burada gerek yok).
   ↳ Kaynak: [Rustdoc — env::args](https://doc.rust-lang.org/std/env/fn.args.html) · [Rustdoc — env::args_os](https://doc.rust-lang.org/std/env/fn.args_os.html)

4. **`IGNORE_CASE` ortam değişkeni aramayı harf duyarsız yapar.** `env::var("IGNORE_CASE").is_ok()` yalnızca tanımlı olup olmadığını sorar; değerin "1" olması gerekmez.
   ↳ Kaynak: [Book ch12-05 — Working with Environment Variables](https://doc.rust-lang.org/book/ch12-05-working-with-environment-variables.html) · [Rustdoc — env::var](https://doc.rust-lang.org/std/env/fn.var.html)

5. **`run(config)` işi yapar ve `Result<(), Box<dyn Error>>` döner.** `fs::read_to_string(&config.dosya_yolu)?` dosya yoksa hatayı hemen yukarı taşır; dosya varsa satırlar taranır ve uyanlar `println!` ile **stdout**'a yazılır. `Box<dyn Error>` "herhangi bir `Error`" koyulabilen trait object'tir (Rust Book Böl. 18 — [Book ch18-02 — Trait Objects](https://doc.rust-lang.org/book/ch18-02-trait-objects.html)); farklı hatalar `?` ile `From` üzerinden kutuya çevrilir. Bedeli bir heap tahsisi + dinamik dispatch'tir, bir uygulama (binary) için makul; kütüphaneler genelde kendi hata enum'unu verir.
   ↳ Kaynak: [Book ch12-03 — Improving Error Handling](https://doc.rust-lang.org/book/ch12-03-improving-error-handling-and-modularity.html) · [Book ch18-02 — Trait Objects](https://doc.rust-lang.org/book/ch18-02-trait-objects.html) · [Rustdoc — Error](https://doc.rust-lang.org/std/error/trait.Error.html)

6. **`ara<'a>` dönen satırların `icerik`'e bağlı olduğunu söyler.** İmzada iki referans girdi vardır (`sorgu`, `icerik`); derleyici sonucun hangisine bağlı olduğunu kendisi bilemez. `'a` yalnız `icerik`'e verilir: bulunan satırlar kitabın ayraçları gibidir, arama kelimesi yazılan kâğıt ise iş bitince atılabilir. Arama üç adımdır: `lines()`, `filter()`, `collect()`.
   ↳ Kaynak: [Book ch12-04 — Testing the Library's Functionality](https://doc.rust-lang.org/book/ch12-04-testing-the-librarys-functionality.html) · [Book ch10-03 — Lifetime Syntax](https://doc.rust-lang.org/book/ch10-03-lifetime-syntax.html) · [Rustdoc — str::lines](https://doc.rust-lang.org/std/primitive.str.html#method.lines)

7. **`ara_harf_duyarsiz` iki kez küçük harfe çevirir.** `sorgu.to_lowercase()` yeni bir `String` üretir; her satır `satir.to_lowercase().contains(&sorgu)` ile karşılaştırılır. Böylece "hiç" araması hem "Ben bir hiçim" hem "Hiç misin" satırını bulur.
   ↳ Kaynak: [Book ch12-05 — Making the Search Case-Insensitive](https://doc.rust-lang.org/book/ch12-05-working-with-environment-variables.html#making-the-search-function-case-insensitive) · [Rustdoc — str::to_lowercase](https://doc.rust-lang.org/std/primitive.str.html#method.to_lowercase)

8. **Sonuçlar ve hatalar iki ayrı kanala gider.** Arama sonuçları `println!` ile stdout'a; argüman ve uygulama hataları `main`'de `eprintln!` ile stderr'e yazılır. İkisi de stdout'a gitseydi `minigrep ... > cikti.txt` ile sonuç yönlendirildiğinde hata mesajları da dosyaya karışırdı; ayrım Unix sözleşmesidir.
   ↳ Kaynak: [Book ch12-06 — Write Error Messages to stderr](https://doc.rust-lang.org/book/ch12-06-write-messages-to-stderr-instead-of-stdout.html)

9. **Hata durumunda `process::exit(1)` ile çıkılır.** Kabuk ve betikler "başarılı mı?" sorusunu çıkış koduyla yanıtlar: 0 oldu, sıfır olmayan kod olmadı. Panik/stack-unwind yerine temiz çıkış tercih edilir.
   ↳ Kaynak: [Rustdoc — process::exit](https://doc.rust-lang.org/std/process/fn.exit.html) · [Book ch12-06](https://doc.rust-lang.org/book/ch12-06-write-messages-to-stderr-instead-of-stdout.html)

10. **Katmanlama bu bölümün asıl dersidir.** Ayrıştırma (`Config::build`) ve iş (`run`) `lib.rs`'tedir ve `#[test]` ile doğrudan sınanır; `main` yalnız "argümanları al, hatayı göster, çıkış kodu ver" yapar. `main` entegrasyon testine doğrudan import edilemez; bu yüzden test edilebilir mantık lib'e taşınır.
    ↳ Kaynak: [Book ch12-04 — Testing the Library's Functionality](https://doc.rust-lang.org/book/ch12-04-testing-the-librarys-functionality.html) · [Book ch11-03 — Integration Tests](https://doc.rust-lang.org/book/ch11-03-test-organization.html#integration-tests)

11. **Testler TDD kalıbıyla yazılmıştır:** önce beklenti (`harf_duyarli_tek_sonuc`, `harf_duyarsiz_iki_sonuc`, `eksik_arguman_hata_doner`), sonra onu geçiren kod. `cargo test -p minigrep` üç testi koşturur; `cargo test -p minigrep duyarsiz` adında "duyarsiz" geçenleri süzer.
    ↳ Kaynak: [Book ch12-04 — Writing an Integration Test](https://doc.rust-lang.org/book/ch12-04-testing-the-librarys-functionality.html) · [Book ch11-02 — Running Tests](https://doc.rust-lang.org/book/ch11-02-running-tests.html)

## Kodda nasıl görünür?

```rust
// src/main.rs — ince ikili: kapı görevlisi
use std::env;
use std::process;
use minigrep::{Config, run};

fn main() {
    let config = Config::build(env::args()).unwrap_or_else(|hata| {
        eprintln!("Argüman hatası: {hata}");
        eprintln!("Kullanım: minigrep <sorgu> <dosya_yolu>   (büyük/küçük harf: IGNORE_CASE=1)");
        process::exit(1);
    });
    if let Err(e) = run(config) {
        eprintln!("Uygulama hatası: {e}");
        process::exit(1);
    }
}

// src/lib.rs — asıl iş
pub fn run(config: Config) -> Result<(), Box<dyn Error>> {
    let icerik = fs::read_to_string(&config.dosya_yolu)?;
    let satirlar = if config.harf_duyarsiz {
        ara_harf_duyarsiz(&config.sorgu, &icerik)
    } else {
        ara(&config.sorgu, &icerik)
    };
    for satir in satirlar { println!("{satir}"); }
    Ok(())
}

pub fn ara<'a>(sorgu: &str, icerik: &'a str) -> Vec<&'a str> {
    icerik.lines().filter(|satir| satir.contains(sorgu)).collect()
}
```

## Sık yapılan hatalar

| Yanlış kullanım | Hata | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| Kökten `cargo run -p minigrep -- hiç siir.txt` | dosya bulunamaz | `siir.txt` yalnız `learn/minigrep` dizininden çıplak yazılabilir; kökten doğru yol `learn/minigrep/siir.txt`'tir. | [Book ch12-02 — Reading a File](https://doc.rust-lang.org/book/ch12-02-reading-a-file.html) |
| Arama mantığını `main.rs`'e yazmak | test edilemez | `main` entegrasyon testine import edilemez; `Config::build` ve `run` lib'te kalmalı. | [Book ch11-03](https://doc.rust-lang.org/book/ch11-03-test-organization.html) |
| Hataları `println!` ile stdout'a basmak | yönlendirmede karışma | Hatalar `eprintln!` ile stderr'e gider; sonuçlar stdout'ta kalır. | [Book ch12-06](https://doc.rust-lang.org/book/ch12-06-write-messages-to-stderr-instead-of-stdout.html) |
| `Config::build` eksik argümanda `panic!` etsin | kötü kullanıcı deneyimi | Eksik argüman kullanıcı hatasıdır; `Err` döner, kararı `main` verir. | [Book ch12-01](https://doc.rust-lang.org/book/ch12-01-accepting-command-line-arguments.html) |
| `ara` imzasında `'a`'yı `sorgu`'ya da bağlamak | gereksiz kısıt | Dönen satırlar `icerik`'e aittir; yalnız ona `'a` ver. | [Book ch10-03](https://doc.rust-lang.org/book/ch10-03-lifetime-syntax.html) |

## Derleyici perspektifi

- `env::args()` sahipliği devralır: her `String` bir kez taşınır, klon ve tahsis yoktur. Geçersiz Unicode argümanda `args()` panik eder; `args_os()` `OsString` verir.
  ↳ Kaynak: [Rustdoc — env::args](https://doc.rust-lang.org/std/env/fn.args.html) · [Rustdoc — env::args_os](https://doc.rust-lang.org/std/env/fn.args_os.html)

- `Box<dyn Error>` dinamik dispatch kullanır (Rust Book Böl. 18'in trait object bölümü): `?` operatörü farklı hata türlerini `From` ile kutuya çevirir. Bedel heap tahsisi ve pointer dolaylamasıdır; bir binary için makul, kütüphane için kendi enum'u daha bilgilidir.
  ↳ Kaynak: [Book ch18-02 — Trait Objects](https://doc.rust-lang.org/book/ch18-02-trait-objects.html) · [Rustdoc — Error](https://doc.rust-lang.org/std/error/trait.Error.html)

- `ara<'a>` imzasındaki ilişki derleme anında denetlenir: dönen `Vec<&'a str>` yalnızca `icerik` yaşadığı sürece kullanılabilir. Çalışma anında herhangi bir lifetime denetimi yapılmaz (ömür silme / lifetime erasure).
  ↳ Kaynak: [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html) · [Book ch10-03](https://doc.rust-lang.org/book/ch10-03-lifetime-syntax.html)

- stdout/stderr ayrımı ve çıkış kodu programın dış sözleşmesidir: sonuç yönlendirilebilir, hatalar ekranda kalır; kabuk çıkış koduyla başarıyı anlar.
  ↳ Kaynak: [Book ch12-06 — Write Error Messages to stderr](https://doc.rust-lang.org/book/ch12-06-write-messages-to-stderr-instead-of-stdout.html)

## Özet ve sonraki adım

- `Config::build` argümanları iterator'dan alır, eksikse `Err` döner; `run` dosyayı okur, arar ve sonuçları stdout'a basar.
- `ara<'a>` sonuçları içeriğe bağlar; `Box<dyn Error>` (Böl. 18 trait object'leri) farklı hataları tek imzada toplar.
- Mantık lib'te, vitrin main'de: main entegrasyon testine import edilemez; hatalar stderr'e, çıkış kodu 1 olur.

Sıradaki bölüm: [12. Closure ve Iterator'lar](12-closures-iterators.md) — burada kullandığımız `filter`, `collect`, iterator ve `FnOnce` gibi trait bound'ları ayrıntılı göreceğiz.
