# 3. Ownership (Sahiplik)

> Kaynak crate: `learn/ownership` · Çalıştır: `cargo run -p ownership`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

## Neden bu bölüm?

C/C++'ta belleği sen yönetirsin: `free()` etmeyi unutursan sızıntı, iki kez çağırırsan bellek bozulması. Java/Go'da çöp toplayıcı (garbage collector) senin yerine yapar ama çalışma anında duraklamaya yol açar. Rust'ın farkı: sahiplik kuralları **derleme zamanında** denetlenir, bellek ise çalışma anında deterministik biçimde geri alınır. Bu bölüm, o kuralların tamamını anlatır.

## 5 yaşındaki çocuğa anlatır gibi

Oyuncağın var, değil mi? Onu arkadaşına verdiğinde artık onun olur, sen tutamazsın. Ama "sadece bakabilir misin?" dersen oyuncak yine senindir. Herkes birlikte bakabilir; ama boyayan tek kişi olmalı, yoksa resim bozulur. Oyun odasından çıkınca oyuncaklar kendiliğinden toplanır, sen "topla" demek zorunda değilsin. Defteri çöpe atarsan arkadaşının bakacağı şey kalmaz — Rust "hayır" der. Pasta dilimi gibi: bütün pastayı almadan bir parçaya bakarsın; pasta gidince dilim de gider.

## Konu anlatımı (madde madde)

1. **Her değerin tek bir sahibi (owner) vardır.** Aynı anda yalnızca bir değişken o veriye sahip olabilir.
   ↳ Kaynak: [Book ch04-01 — What is Ownership?](https://doc.rust-lang.org/book/ch04-01-what-is-ownership.html) · [Reference — Ownership](https://doc.rust-lang.org/reference/ownership.html)

2. **Sahip kapsamdan (scope) çıkınca değer düşürülür (drop).** Bellek otomatik serbest bırakılır; "sil" komutu yazmana gerek yoktur.
   ↳ Kaynak: [Book ch04-01 — The Scope and Drop](https://doc.rust-lang.org/book/ch04-01-what-is-ownership.html#the-scope-and-drop) · [Reference — Destructors](https://doc.rust-lang.org/reference/destructors.html)

3. **Atama, heap sahibi olan türlerde taşıma (move)** yapar. `let s2 = s1;` yazınca veri `s1`'den `s2`'ye geçer; `s1` artık geçersizdir. Böylece aynı bellek bloğu iki kez serbest bırakılmaz (double free).
   ↳ Kaynak: [Book ch04-01 — Variables and Data Interacting with Move](https://doc.rust-lang.org/book/ch04-01-what-is-ownership.html#variables-and-data-interacting-with-move) · [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs)

4. **Copy ölçütü boyut ya da stack/heap değil, `Copy` trait'idir.** Sayılar, `bool`, `char`, `&T`, fonksiyon işaretçileri ve tamamı `Copy` olan struct/tuple/dizi/Option atamada bit kopyası yapar. Heap sahibi olan `String`/`Vec` gibi türler `Drop` gerektirdiğinden `Copy` olamaz; taşınırlar.
   ↳ Kaynak: [Book ch04-01 — Stack-Only Data: Copy](https://doc.rust-lang.org/book/ch04-01-what-is-ownership.html#stack-only-data-copy) · [Rustdoc — Copy](https://doc.rust-lang.org/std/marker/trait.Copy.html)

5. **`.clone()` açıkça çağrılan derin kopyadır.** Heap verisi yeni bir blok olarak kopyalanır; maliyet görünür ve isteğe bağlıdır. Move ucuz varsayılandır.
   ↳ Kaynak: [Book ch04-01 — Clone](https://doc.rust-lang.org/book/ch04-01-what-is-ownership.html#clone-the-copy-trait) · [Rustdoc — Clone](https://doc.rust-lang.org/std/clone/trait.Clone.html)

6. **Ödünç alma (borrow) sahipliği devretmez.** `&T` ile veriye bakarsın, sahibi değişmez; `&mut T` ile geçici olarak değiştirebilirsin.
   ↳ Kaynak: [Book ch04-02 — References and Borrowing](https://doc.rust-lang.org/book/ch04-02-references-and-borrowing.html) · [Reference — Borrowing](https://doc.rust-lang.org/reference/ownership.html#borrowing)

7. **Borrow kuralı: ya birçok `&` ya da tek bir `&mut`, ikisi aynı anda değil.** Buna *aliasing XOR mutability* denir. Böylece kimse ayağının altından değişen veriyle karşılaşmaz. Bu kural, tek iş parçacığında da geçerlidir; veri yarışı (data race) yalnızca iş parçacıkları arası bir kavramdır.
   ↳ Kaynak: [Book ch04-02 — The Rules of References](https://doc.rust-lang.org/book/ch04-02-references-and-borrowing.html#the-rules-of-references) · [Nomicon — Aliasing](https://doc.rust-lang.org/nomicon/aliasing.html)

8. **Referans asla sarkmaz (dangling).** Gösterdiği veri yoksa Rust kodu derlemez; bu yüzden `E0106` (lifetime eksik) ve `E0515`/`E0597` (yerel değişkene referans) hataları alınır.
   ↳ Kaynak: [Book ch04-02 — Dangling References](https://doc.rust-lang.org/book/ch04-02-references-and-borrowing.html#dangling-references) · [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs)

9. **Dilim (slice) verinin kopyası değil, bir parçasına bakıştır.** Pasta gidince dilim de gider; bu yüzden dilim varsa sahip değiştirilemez (`E0502`).
   ↳ Kaynak: [Book ch04-03 — Slices](https://doc.rust-lang.org/book/ch04-03-slices.html) · [Rustdoc — slice](https://doc.rust-lang.org/std/primitive.slice.html)

## Kodda nasıl görünür?

```rust
fn sahiplik_ve_move() {
    let s1 = String::from("merhaba");
    let s2 = s1;              // heap verisi s2'ye TAŞINIR; s1 geçersiz
    println!("s2 = {s2}");    // ✓
    // println!("{s1}");      // ✗ E0382: borrow of moved value
}

fn copy_vs_move() {
    let x = 5;
    let y = x;                // Copy: ikisi de geçerli
    println!("x = {x}, y = {y}");
}

fn borrow_paylasimli() {
    let s = String::from("kitap");
    let n = uzunluk_hesapla(&s); // & ile ödünç; sahiplik s'de kalır
    println!("'{s}' uzunluğu {n}");
}
fn uzunluk_hesapla(x: &String) -> usize { x.len() }
```

## Sık yapılan hatalar

| Kod | Hata | Neden / çözüm |
| --- | --- | --- |
| `println!("{s1}")` move sonrası | **E0382** | `s1` artık sahibi değil; `s2`'yi kullan ya da `s1.clone()` yap. |
| `let b = &s; let m = &mut s;` | **E0502** | `&` ve `&mut` aynı anda olamaz; `b`'nin kullanımı bitene kadar bekle. |
| `fn f() -> &String` | **E0106** | Hangi ömür? Döndürülen referans girdiğe bağlıysa `'a` ekle. |
| `fn f<'a>() -> &'a String { &s }` | **E0515** | `s` yerel; fonksiyon bitince yok olur. Sahipliği döndür (`String`). |
| Dilim varken `s.clear()` | **E0502** | Dilim `s`'i ödünç alıyor; sahibi değiştirilemez. |

## Derleyici perspektifi

- **Move**, MIR'de `Operand::Move(place)` olarak modellenir; taşınan yer "başlatılmamış" sayılır. Hangi yerlerin hâlâ başlatılmış olduğunu `MaybeInitializedPlaces` + `MoveData` veri akış analizi izler; taşınmış değeri kullanınca borrowck **E0382** üretir.
  ↳ Kaynak: [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs) · [rustc 1.99.1 — borrow_set.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrow_set.rs)

- **Drop çağrılarını sen yazmazsın.** "Drop elaboration" geçişi MIR'e ekler; koşullu taşıma durumları için *drop flag* kullanılır. Değişkenler kapsam sonunda ters tanım sırasında düşürülür.
  ↳ Kaynak: [rustc 1.99.1 — elaborate_drops.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_transform/src/elaborate_drops.rs) · [Reference — Destructors](https://doc.rust-lang.org/reference/destructors.html)

- **Borrow çakışmaları** borrowck'ın NLL (non-lexical lifetimes) aşamasında bulunur; ödünç ömrü sözdizimsel kapsam değil, son kullanıma kadar uzanır.
  ↳ Kaynak: [Book ch04-02 — NLL](https://doc.rust-lang.org/book/ch04-02-references-and-borrowing.html#the-rules-of-references) · [rustc 1.99.1 — nll.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/nll.rs)

> **Sıfır maliyet notu:** "Sıfır maliyet" yalnız sahiplik/ödünç **kontrolleri** için geçerlidir; heap serbest bırakma çalışma anında olur. RAII, GC duraklaması eklemeden deterministik yönetim sağlar.
> ↳ Kaynak: [Book ch04-01](https://doc.rust-lang.org/book/ch04-01-what-is-ownership.html) · [Rustdoc — Drop](https://doc.rust-lang.org/std/ops/trait.Drop.html)

## Özet ve sonraki adım

- Tek sahip, tek serbest bırakma; move varsayılan, `Copy` bit kopya, `.clone()` açık derin kopya.
- `&` paylaşımlı, `&mut` özel; ikisi aynı anda olmaz; referans sarkmaz.
- Drop otomatik ve deterministiktir; derleyici kontrolleri çalışma anına maliyet eklemez.

Bir sonraki sayfada [Ownership: Derinleşme](03-ownership-derinlesme.md) bölümünde imzaların birer sahiplik sözleşmesi olduğunu, kısmi move'u ve gerçek bir kullanıcı deposu tasarımını göreceğiz.
