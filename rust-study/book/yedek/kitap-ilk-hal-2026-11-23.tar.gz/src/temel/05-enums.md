# 5. Enum'lar ve Desen Eşleme

> Kaynak crate: `learn/enums` · Çalıştır: `cargo run -p enums`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

## Neden bu bölüm?

Bir gönderi mektup, koli ya da kartpostal olabilir; üçü birden olamaz. Bunu üç ayrı değişken ve "hangisi geçerli?" diye bir bayrakla modellemek, bayrağa uymayan bir değerin üretilmesine açıktır. Enum olasılıkları tek türde toplar, `match` de her olasılığa ayrı bir satır yazmanı zorunlu kılar. Böylece eksik durum çalışma anına değil, derleme anına taşınır.

## 5 yaşındaki çocuğa anlatır gibi

Postacı kapıya gelir. Zarf ya kutuya girer, ya cebinde kalır, ya da geri götürülür. Bir zarfın aynı anda hem kutuda hem cebinde olması imkânsızdır. Postacı her durumda ne yapacağını önceden bilir; birini unutursa patronu hemen fark eder.

## Konu anlatımı (madde madde)

1. **Enum "bu değer şu seçeneklerden yalnız biridir" der.** Her seçeneğe varyant (variant) denir: `enum Yon { Kuzey, Guney, Dogu, Bati }`. Bir `Yon` değeri dört varyanttan tam biridir; dördü birden olamaz.
   ↳ Kaynak: [Book ch06-01 — Defining an Enum](https://doc.rust-lang.org/book/ch06-01-defining-an-enum.html)

2. **Varyant unit, tuple-like ya da struct-like olabilir.** `Cik` veri taşımaz; `V4(u8, u8, u8, u8)` ve `Yaz(String)` adsız veri taşır; `Tasi { x: i32, y: i32 }` adlı veri taşır. Her varyant kendi verisini yanında getirir, "şu an hangisi?" sorusuna ayrıca bakılmaz.
   ↳ Kaynak: [Book ch06-01 — Enum Variants](https://doc.rust-lang.org/book/ch06-01-defining-an-enum.html)

3. **Enum'lar da metot alabilir.** `impl Mesaj { fn calistir(&self) { match self { .. } } }` içinde hangi varyantın geldiği `match` ile ayrılır; alan erişimi gibi kaba bir denetim yerine desen eşleme kullanılır.
   ↳ Kaynak: [Book ch06-01 — Methods with Enums](https://doc.rust-lang.org/book/ch06-01-defining-an-enum.html) · [Book ch05-03 — Method Syntax](https://doc.rust-lang.org/book/ch05-03-method-syntax.html)

4. **`Option<T>` null'ın yerine "değer olabilir de olmayabilir" durumunu türde kodlar.** `enum Option<T> { Some(T), None }`; `Some(5)` "içinde 5 var", `None` "kutu boş" der. Rust'ta null yoktur; `i32` ile `Option<i32>` toplanamaz, çünkü `None` ihtimali ele alınmak zorundadır. Böylece unutulan null kontrolü çalışma anından derleme anına çekilir.
   ↳ Kaynak: [Book ch06-01 — Option Enum](https://doc.rust-lang.org/book/ch06-01-defining-an-enum.html) · [Rustdoc — Option](https://doc.rust-lang.org/std/option/enum.Option.html)

5. **`match` bir ifadedir; her kol bir desen ve yapılacak iştir.** `IpAdres::V4(a, b, c, d)` deseni içindeki sayıları bağlar; `diger` isimli catch-all değeri bağlar, `_` ise değeri umursamadığını söyler. Kolların hepsi aynı türde bir sonuç üretmelidir; sonuç doğrudan bir değişkene konabilir.
   ↳ Kaynak: [Book ch06-02 — The match Control Flow Construct](https://doc.rust-lang.org/book/ch06-02-match.html) · [Book ch19-02 — Pattern Syntax](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html)

6. **Bütünlük denetimi (exhaustiveness) tüm varyantları ister.** Bir varyantı atlarsan `E0004` alırsın: `non-exhaustive patterns: Yon::Dogu and Yon::Bati not covered`. C'de switch'te unutulan case sessizce atlanır; Rust'ta enum'a yarın yeni bir varyant eklenirse onu ele almayan bütün `match`'ler derlenmez — bu derleyici güdümlü refactor'dur.
   ↳ Kaynak: [Book ch06-02 — Patterns That Bind to Values / Exhaustiveness](https://doc.rust-lang.org/book/ch06-02-match.html) · [rustc 1.99.1 — check_match.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_build/src/thir/pattern/check_match.rs)

7. **`if let` ve `let ... else`, tek desenle ilgilendiğinde `match`'in kısa yazımıdır.** `if let Some(v) = ayar { .. }` yalnız dolu kutuyu işler; `let Some(v) = ayar else { return; }` desen tutmazsa bloktan erken çıkar, tutarsa `v` sonraki satırlarda kullanılabilir. Tam `match` + `_ => ()` gürültülü olduğunda aynı güvenliği korurlar.
   ↳ Kaynak: [Book ch06-03 — Concise Control Flow with if let and let-else](https://doc.rust-lang.org/book/ch06-03-if-let.html)

8. **Enum bellekte tagged union'dur: discriminant + payload.** Gizli küçük etiket hangi varyantın olduğunu söyler, ayrılan yer en büyük varyantı tutacak kadardır; `match` etikete bakıp doğru dalı seçer.
   ↳ Kaynak: [Book ch06-01 — Mixing Different Types of Data in an Enum](https://doc.rust-lang.org/book/ch06-01-defining-an-enum.html) · [Reference — Type Layout](https://doc.rust-lang.org/reference/type-layout.html)

9. **Niche optimization: kullanılmayan bit deseni `None` olur.** Kaynak dosyadaki ölçümlerle doğrulandı: `i32` 4, `Option<i32>` 8 bayt (i32 bütün desenleri kullanır, ayrı etiket gerekir); `&i32` 8, `Option<&i32>` 8 (referans asla null olamaz); `Box<i32>` 8, `Option<Box<i32>>` 8. **`bool` 1, `Option<bool>` 1 bayttır:** bool bir baytta yalnız 0 ve 1'i kullanır, geri kalan **254 geçersiz desenden biri** `None` olarak saklanır. Yani `Option<&T>` null'lanabilir gösterici kadar ucuzdur ama güvenlidir.
   ↳ Kaynak: [Rustdoc — Option](https://doc.rust-lang.org/std/option/enum.Option.html) · [Reference — Type Layout](https://doc.rust-lang.org/reference/type-layout.html)

10. **`if let` / `while let` / let-else sözdizimsel şekerdir, AMA HIR'da `match`'e indirgenmez.** Anlamca `match`'e eşdeğerdirler; güncel rustc bunları `Let` / `If` / let-else düğümleri olarak korur (`expr.rs:324-325`). Buna karşılık `for` → `loop + match` ve `?` → `match` indirgemeleri gerçekten yapılır. İkisini karıştırmak yaygın bir yanlıştır.
    ↳ Kaynak: [rustc 1.99.1 — expr.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_ast_lowering/src/expr.rs#L324-L325) · [Book ch06-03 — if let](https://doc.rust-lang.org/book/ch06-03-if-let.html)

## Kodda nasıl görünür?

```rust
#[derive(Debug)]
enum IpAdres {
    V4(u8, u8, u8, u8), // tuple-like varyant (veri taşır)
    V6(String),         // tek alanlı varyant
    Bilinmeyen,         // unit varyant (veri taşımaz)
}

fn enum_ve_varyantlar() {
    let adresler = [
        IpAdres::V4(127, 0, 0, 1),
        IpAdres::V6(String::from("::1")),
        IpAdres::Bilinmeyen,
    ];
    for a in adresler {
        // match bir İFADEDİR: değer üretir. Varyantın taşıdığı veriyi burada bağlarız.
        let aciklama = match a {
            IpAdres::V4(a, b, c, d) => format!("IPv4 {a}.{b}.{c}.{d}"),
            IpAdres::V6(s) => format!("IPv6 {s}"),
            IpAdres::Bilinmeyen => String::from("bilinmeyen"),
        };
        println!("{aciklama}");
    }
}

fn option_neden() {
    // Rust'ta null YOKTUR. "Değer olmayabilir" durumu Option<T> ile TÜRÜN İÇİNE kodlanır:
    //   enum Option<T> { Some(T), None }
    let bazi: Option<i32> = Some(5);
    let yok: Option<i32> = None;

    // i32 ile Option<i32> toplanamaz: None ihtimalini ELE ALMALISIN.
    let sonuc = match bazi {
        Some(n) => n + 1,
        None => 0,
    };
    println!("sonuç = {sonuc}, yok = {yok:?}");
    println!("yok.unwrap_or(-1) = {}", yok.unwrap_or(-1)); // kısayol metotlardan biri
}
```

## Sık yapılan hatalar

| Kod | Hata | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| `match y { Kuzey => .., Guney => .. }` (`Yon` dört varyantlı) | **E0004** | `Dogu` ve `Bati` kapsanmadı; tüm varyantları yaz ya da bilinçli `_ =>` kullan. | [Book ch06-02](https://doc.rust-lang.org/book/ch06-02-match.html) · [check_match.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_build/src/thir/pattern/check_match.rs) |
| `let n: u32 = Some(5);` | **E0308** | `Option&lt;u32&gt;`, `u32` değildir; `match` / `map` / `unwrap_or` ile aç. | [Rustdoc — Option](https://doc.rust-lang.org/std/option/enum.Option.html) |
| `let kutu: Option<i32> = Some(5); kutu + 1;` | derlenmez | Kutu sayı değildir; önce iki ihtimale de bakılmalı. | [Book ch06-01 — Option](https://doc.rust-lang.org/book/ch06-01-defining-an-enum.html) |
| `Some("42").map(\|s\| s.parse::<u32>().ok())` sonucunu `Option&lt;u32&gt;`'ye atamak | **E0308** | Sonuç `Option&lt;Option&lt;u32&gt;&gt;` olur; adım da Option döndürüyorsa `and_then` kullan. | [Rustdoc — Option::and_then](https://doc.rust-lang.org/std/option/enum.Option.html#method.and_then) |
| `Result` döndüren fonksiyonda `let kod = k?;` (`k: Option<&str>`) | **E0277** | `None` hangi hataya karşılık gelir, derleyici bilemez; `k.ok_or(Hata::Yok)?` yaz. | [Book ch09-02 — `?` Operator](https://doc.rust-lang.org/book/ch09-02-recoverable-errors-with-result.html) |

## Derleyici perspektifi

- Enum bir tagged union'dır: discriminant + en büyük varyantın payload'u. Niche varsa ayrı etiket eklenmez; `Option<bool>` 1 baytta kalır ve `bool`'un 254 geçersiz deseninden biri `None`'a karşılık gelir. Kaynak dosyadaki boyut ölçümleri bu şekilde doğrulandı.
  ↳ Kaynak: [Reference — Type Layout](https://doc.rust-lang.org/reference/type-layout.html) · [Rustdoc — Option](https://doc.rust-lang.org/std/option/enum.Option.html)

- Bütünlük denetimi tür denetiminden sonra THIR (typed HIR) üzerinde yapılır; eksik varyant `E0004` üretir. "Usefulness" algoritması ayrı bir crate'te (`rustc_pattern_analysis`) yaşar.
  ↳ Kaynak: [rustc 1.99.1 — check_match.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_build/src/thir/pattern/check_match.rs)

- `if let` / `while let` / let-else **HIR'da `match`'e indirgenmez**: sözdizimsel şekerdir, anlamca eşdeğerdir ve düğümler korunur. `for` → `loop + match`, `?` → `match` indirgemeleri ise gerçekten yapılır.
  ↳ Kaynak: [rustc 1.99.1 — expr.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_ast_lowering/src/expr.rs#L324-L325)

## Özet ve sonraki adım

- Enum "şunlardan biri" der; her varyant kendi verisini taşır, `match` hepsini kapsamak zorundadır.
- `Option<T>` null'ı türden kovar; `Some`/`None` ayrımı derleyici tarafından zorunlu kılınır.
- `if let` kısa yazımdır ama HIR'da match'e indirgenmez; bool'un 254 geçersiz deseni `None` için kullanılır.

Sıradaki bölüm: [6. Modüller](06-modules.md).
