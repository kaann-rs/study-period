# 4. Struct'lar (Yapılar)

> Kaynak crate: `learn/structs` · Çalıştır: `cargo run -p structs`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

## Neden bu bölüm?

Bir kullanıcının adını, e-postasını ve giriş sayısını ayrı ayrı değişkenlerde taşırsan hangisinin kime ait olduğunu takip etmek zorlaşır. Struct ilgili bilgileri tek bir kartta toplar; metotlar da o kartla yapılan işleri kartın yanına yazar. Bölüm 3'teki sahiplik kuralları burada doğrudan alanlara ve metotların alıcısına (receiver) uygulanır.

## 5 yaşındaki çocuğa anlatır gibi

Öğrenci kartında ad, sınıf, numara gözleri var. Kartı basan büro kontrol eder; sen sadece kullanırsın. Kartı okumak için üstüne bakarsın, numarayı değiştirmek için silgi kullanırsın, bütün kartı vermek için arkadaşına uzatırsın.

## Konu anlatımı (madde madde)

1. **Struct, ilgili alanları (field) tek bir türde toplayan kalıptır.** `struct Kullanici { ad: String, eposta: String, aktif: bool, giris: u64 }` kart kalıbıdır; `Kullanici { ... }` ile ondan bir örnek (instance) çıkarırsın. Kalıp bir kez tanımlanır, istediğin kadar kart doldurulur.
   ↳ Kaynak: [Book ch05-01 — Defining and Instantiating Structs](https://doc.rust-lang.org/book/ch05-01-defining-structs.html)

2. **Alanlara nokta ile erişilir; `mut` bir alanın değil, binding'in özelliğidir.** `kart.ad` ile okursun, `k.sinif = 4` ile değiştirirsin — ama yalnızca kartın tamamı `mut` ise. `&mut k` elde eden ödünç kuralları gereği bütün alanlara yazabilir; bu yüzden "tek alanı mut yapma" diye bir seçenek yoktur.
   ↳ Kaynak: [Book ch03 — Mutability](https://doc.rust-lang.org/book/ch03-00-common-programming-concepts.html) · [Book ch05-01 — Accessing and Modifying Struct Fields](https://doc.rust-lang.org/book/ch05-01-defining-structs.html)

3. **`ad: ad` yerine `ad` yazmak (field init shorthand) ve `..eski` (struct update syntax) kısayoldur.** `..eski` bir kopya DEĞİLDİR: yazmadığın alanları eski karttan alır; non-Copy olanları (ör. `String`) taşır, Copy olanları kopyalar. Taşınan alanın kaynaktaki örneği artık okunamaz.
   ↳ Kaynak: [Book ch05-02 — Using Struct Update Syntax](https://doc.rust-lang.org/book/ch05-02-example-structs.html) · [Book ch04-01 — Move](https://doc.rust-lang.org/book/ch04-01-what-is-ownership.html)

4. **Tuple struct ve unit-like struct da kendi türüdür.** `struct Renk(u8, u8, u8)` alanlara ad vermez, sıraya bakar; `struct Birim` hiç alan taşımaz. `Renk` isteyen bir yere `Konum(u8, u8, u8)` ya da düz bir `(u8, u8, u8)` veremezsin — tür güvenliği bundan gelir.
   ↳ Kaynak: [Book ch05-01 — Tuple Structs and Unit-Like Structs](https://doc.rust-lang.org/book/ch05-01-defining-structs.html)

5. **Alanlar varsayılan olarak veriyi sahiplenir; referans tutan alan ömür etiketi ister.** `struct Alinti<'a> { metin: &'a str }` geçerlidir; `struct S { r: &str }` geçersizdir (`E0106`). `'a` sözü, gösterilen verinin struct'tan uzun yaşayacağını derleyiciye söyler ve borrowck bunu denetler.
   ↳ Kaynak: [Book ch10-03 — Lifetime Syntax](https://doc.rust-lang.org/book/ch10-03-lifetime-syntax.html) · [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html)

6. **`impl` bloğu metotları ve associated function'ları tutar.** `Self`, o struct'ın türüdür. `fn yeni(en: u32, boy: u32) -> Self` gibi `self`siz fonksiyonlar kalıba bağlıdır ve `Dikdortgen::yeni(..)` diye çağrılır; genelde yapıcı (constructor) olarak kullanılır.
   ↳ Kaynak: [Book ch05-03 — Associated Functions](https://doc.rust-lang.org/book/ch05-03-method-syntax.html)

7. **Receiver bir sahiplik sözleşmesidir: `&self` okur, `&mut self` değiştirir, `self` tüketir.** `self == self: Self`, `&self == self: &Self`, `&mut self == self: &mut Self` kısaltmalarıdır; Bölüm 3'ün ödünç kuralları aynen geçerli. Çoğu metot `&self` alır, çünkü her metot kartı yeseydi ilk çağrıda kart elinden çıkardı.
   ↳ Kaynak: [Book ch05-03 — Method Syntax and `self`](https://doc.rust-lang.org/book/ch05-03-method-syntax.html) · [Book ch04-02 — References and Borrowing](https://doc.rust-lang.org/book/ch04-02-references-and-borrowing.html)

8. **Metot çağrısında otomatik referanslama/deref yapılır.** `d.alan()` yazınca derleyici metodun `&self` istediğini görüp çağrıyı `(&d).alan()` olarak düzenler; aday zincirinde önce receiver'ı olduğu gibi, sonra `&d`, `&mut d` ve Deref ile açılmış hâlleri dener.
   ↳ Kaynak: [Book ch05-03 — Automatic Referencing and Dereferencing](https://doc.rust-lang.org/book/ch05-03-method-syntax.html) · [rustc 1.99.1 — probe.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_hir_typeck/src/method/probe.rs)

9. **`#[derive(Debug)]`, derleyiciye gömülü (built-in) bir derive makrosudur.** Makro genişletme aşamasında `fmt::Debug` implementasyonunu senin yerine üretir; `{:?}` tek satır, `{:#?}` çok satır yazdırır. `Debug`/`Clone`/`PartialEq` gibi standart derive'lar built-in'dir; kullanıcıların yazdığı derive'lar (ör. `serde::Serialize`) gerçek proc-macro'dur. `{}` için `Display` gerekir, `derive(Debug)` onu getirmez.
   ↳ Kaynak: [Book ch20-05 — Derive Macros](https://doc.rust-lang.org/book/ch20-05-macros.html) · [Reference — Derive](https://doc.rust-lang.org/reference/attributes/derive.html) · [Rustdoc — Debug](https://doc.rust-lang.org/std/fmt/trait.Debug.html)

10. **Alan sırası varsayılan `repr(Rust)`ta garanti değildir.** Derleyici padding'i azaltmak için alanları yeniden sıralayabilir; sabit ve C-uyumlu bir sıra gerekiyorsa `#[repr(C)]` kullanılır. Program yazarken bundan yararlanılmaz, düzen oldukça değişebilir.
    ↳ Kaynak: [Reference — Type Layout](https://doc.rust-lang.org/reference/type-layout.html)

## Kodda nasıl görünür?

```rust
#[derive(Debug)]
struct Dikdortgen {
    en: u32,
    boy: u32,
}

impl Dikdortgen {
    // associated function (self YOK): tür üzerinden çağrılır, genelde yapıcı (constructor).
    fn yeni(en: u32, boy: u32) -> Self {
        Self { en, boy } // Self = Dikdortgen; field init shorthand (en: en → en)
    }
    // &self: receiver'ı ödünç alır, sahiplenmez, değiştirmez — en yaygın metot biçimi.
    fn alan(&self) -> u32 {
        self.en * self.boy
    }
    // &mut self: değiştirmek için ödünç alır.
    fn olcekle(&mut self, k: u32) {
        self.en *= k;
        self.boy *= k;
    }
    // self: receiver'ı TÜKETİR (sahipliğini alır); çağrıdan sonra orijinal kullanılamaz.
    fn yok_et(self) -> (u32, u32) {
        (self.en, self.boy)
    }
}

fn metotlar() {
    let mut d = Dikdortgen::yeni(3, 4); // associated function :: ile çağrılır (self yok)
    println!("alan = {}", d.alan());    // &self: `d.alan()` aslında `Dikdortgen::alan(&d)`
    d.olcekle(2);                       // &mut self: d mut olmalı
    println!("ölçekli alan = {} ({:?})", d.alan(), d);

    let (en, boy) = d.yok_et();         // self: d burada TÜKETİLİR
    println!("yok edildi: {en}x{boy}");
    // d.alan(); // ✗ E0382: use of moved value `d` — yok_et(self) d'nin sahipliğini aldı
}
```

## Sık yapılan hatalar

| Kod | Hata | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| `struct S { r: &str }` | **E0106** | Referans alan ömür etiketi ister: `struct S<'a> { r: &'a str }`. | [Book ch10-03](https://doc.rust-lang.org/book/ch10-03-lifetime-syntax.html) |
| `let (en, boy) = d.yok_et(); d.alan();` | **E0382** | `self` receiver'ı tüketir; `d` artık elinde değil. | [Book ch04-01](https://doc.rust-lang.org/book/ch04-01-what-is-ownership.html) |
| `..u1` sonrası `u1.eposta` | **E0382** | `..u1` kopyalamaz; `eposta: String` taşınır. Copy alanlar hâlâ okunabilir. | [Book ch05-02](https://doc.rust-lang.org/book/ch05-02-example-structs.html) · [Book ch04-01](https://doc.rust-lang.org/book/ch04-01-what-is-ownership.html) |
| `println!("{d}")` (`derive(Debug)` ile) | derlenmez | `{}` için `Display` gerekir; `{:?}` ya da `{:#?}` kullan. | [Rustdoc — Debug](https://doc.rust-lang.org/std/fmt/trait.Debug.html) |
| `sabit.sinif = 4;` (`mut` yok) | derlenmez | Mutability binding'in özelliğidir; kartın hiçbir alanı değişmez. | [Book ch03](https://doc.rust-lang.org/book/ch03-00-common-programming-concepts.html) · [Book ch05-01](https://doc.rust-lang.org/book/ch05-01-defining-structs.html) |

## Derleyici perspektifi

- `self`, `&self`, `&mut self` birer kısaltmadır (`Self`, `&Self`, `&mut Self`); ch4'teki sahiplik ve ödünç kuralları receiver'a aynen uygulanır.
  ↳ Kaynak: [Book ch05-03](https://doc.rust-lang.org/book/ch05-03-method-syntax.html) · [Book ch04-02](https://doc.rust-lang.org/book/ch04-02-references-and-borrowing.html)

- Metot çağrısı çözümü (method resolution) bir aday zinciri dener; `rustc_hir_typeck` adayları toplar ve ilk uyanı seçer. "Otomatik referanslama" dediğimiz şey budur.
  ↳ Kaynak: [rustc 1.99.1 — probe.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_hir_typeck/src/method/probe.rs)

- `repr(Rust)`ta alan sırası garanti değildir; derleyici padding'i azaltmak için yeniden sıralayabilir. Sabit sıra yalnız `#[repr(C)]` ile korunur.
  ↳ Kaynak: [Reference — Type Layout](https://doc.rust-lang.org/reference/type-layout.html)

- `derive(Debug)` gibi standart derive'lar derleyiciye gömülü makrolardır ve makro genişletme aşamasında impl enjekte eder; kullanıcı derive'ları proc-macro crate'lerindendir.
  ↳ Kaynak: [Book ch20-05 — Derive Macros](https://doc.rust-lang.org/book/ch20-05-macros.html) · [Reference — Derive](https://doc.rust-lang.org/reference/attributes/derive.html)

- `dead_code` analizinde bir alanı yalnız `{:?}` ile basmak "okundu" sayılmaz: rustc, derive'ın ürettiği impl'i bu analizde kasıtlı olarak yok sayar. Bu yüzden kaynak dosyada `aktif` ayrıca gerçek kodda okunur.
  ↳ Kaynak: [rustc 1.99.1 — late.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_lint/src/late.rs)

## Özet ve sonraki adım

- Struct ilgili alanları tek türde toplar; `mut` tüm binding'i kapsar, alan sırası `repr(Rust)`ta garanti değildir.
- Receiver bir sözleşmedir: `&self` okur, `&mut self` değiştirir, `self` tüketir; `..eski` kopya değil, taşımadır.
- Standart derive'lar built-in, kullanıcı derive'ları proc-macro'dur; `{:?}` `Debug` ister, `{}` `Display` ister.

Sıradaki bölüm: [5. Enum'lar ve Desen Eşleme](05-enums.md).
