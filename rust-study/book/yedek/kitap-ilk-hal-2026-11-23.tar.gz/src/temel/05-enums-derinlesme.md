# 5.1 Enum'lar: Derinleşme

> Kaynak dosya: `learn/enums/src/derinlesme.rs` · Test: `cargo test -p enums`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

Önceki sayfada enum'un ne olduğunu, `Option`'ın null'ı neden kaldırdığını ve `match`'in bütünlük denetimini gördük. Bu sayfada aynı araçları bir tasarım aracına çeviriyoruz: geçersiz durumları temsil edilemez kılma, tek bir `(durum, olay)` eşlemesiyle sipariş durum makinesi ve iç içe `match` yerine Option/Result kombinatörleri.

## Neden bu sayfa?

Bir siparişin "ödendi", "kargoda", "takip no" bilgilerini üç ayrı alanda tutarsan 2 × 2 × 2 = 8 değer kurulabilir; anlamlı olanı yalnız 3'üdür. Kalan 5'i de derleyici tarafından engellenmez ve her kullananın tutarlılığı denetlemesi gerekir. Enum ile aynı saçmalığı **yazamazsın**: takip numarası yalnız `Kargoda` / `TeslimEdildi` varyantlarının yanında vardır, denetleyecek bir `tutarli_mi()`'ye gerek kalmaz.

## Gerçek senaryo: sipariş durum makinesi

Benzetme bir kargo şubesinde geçer. Duvarda bir yol haritası asılıdır: SEPETTE iken ödeme gelirse ÖDENDİ olur; ÖDENDİ iken kargoya verilirse YOLDA olur. Haritada çizilmemiş yol kapalıdır: SEPETTE bir paket doğrudan TESLİM EDİLDİ olamaz. Kodda `SiparisDurumu` aşamaları, `Olay` dışarıdan gelen haberleri anlatır; `gecis(self, olay)` haritanın kendisidir.

`GevsekSiparis` (bayraklı model) ile karşılaştırma doğrudan kaynak dosyada var: `odendi: false, kargoda: true, takip_no: None` yazılabilir ama `tutarli_mi()` yanlış döner. Enum modelinde bu değerin karşılığı yoktur.

## Adım adım kod analizi

1. **Kurallar türde değil, bayraklı modelde fonksiyonda yaşar.** `GevsekSiparis::tutarli_mi()` "ödemesiz kargo" ve "takipsiz kargo" koşullarını elle denetler; kuralı çağırmayı unutan her kod bozuk veriyle çalışır. Enum modelinde aynı denetim yazılamaz bile, çünkü yanlış alan kombinasyonu oluşturulamaz.
   ↳ Kaynak: [Book ch06-01 — Defining an Enum](https://doc.rust-lang.org/book/ch06-01-defining-an-enum.html) · [Book ch05-01 — Structs](https://doc.rust-lang.org/book/ch05-01-defining-structs.html)

2. **Veri varyantın yanına taşınır.** `SiparisDurumu::Kargoda { odeme_no: u32, takip_no: String }` hem ödeme hem takip bilgisini zorunlu kılar; `TeslimEdildi { takip_no }` ödeme numarasını taşımaz, `IptalEdildi { neden, iade: Option<u32> }` iadenin olup olmadığını türde anlatır.
   ↳ Kaynak: [Book ch06-01 — Struct-Like Enums](https://doc.rust-lang.org/book/ch06-01-defining-an-enum.html)

3. **`gecis(self, olay)` dört şeyi birden yapar.** (1) `self` tüketilir; eski durum geçişten sonra yoktur, "hem ödendi hem sepette" diye iki kopya dolaşamaz. (2) `(self, olay)` tuple'ı üzerinde tek bir `match` kuralları tek yerde toplar. (3) Desen eski varyantın `odeme_no` / `takip_no` verisini yenisine **taşır**, kopya yoktur. (4) Son kol `(durum, olay) => Err(GecersizGecis { durum, olay })` bilinçli bir "varsayılan olarak reddet"tir; yeni bir durum ya da olay kendiliğinden izin almaz ve tüketilen durum çağırana geri verilir.
   ↳ Kaynak: [Book ch06-02 — The match Control Flow Construct](https://doc.rust-lang.org/book/ch06-02-match.html) · [Book ch04-01 — What is Ownership?](https://doc.rust-lang.org/book/ch04-01-what-is-ownership.html)

4. **`ozet()`'te `_ =>` kolu yoktur ve olmamalıdır.** Yarın `IadeBekliyor` varyantı eklenirse bu `match` `E0004` verir ve derleyici tam o satıra götürür. `_ => "bilinmiyor"` yazılmış olsaydı yeni durum sessizce öyle raporlanır; hata derleme anından müşterinin ekranına taşınırdı. Aynı dosyadaki `gecis()` ise catch-all kullandığı için şikâyet etmez — orada istenen davranış zaten "reddet"tir.
   ↳ Kaynak: [rustc 1.99.1 — check_match.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_build/src/thir/pattern/check_match.rs) · [Book ch06-02 — Exhaustiveness](https://doc.rust-lang.org/book/ch06-02-match.html)

5. **`matches!` bir desenin tutup tutmadığını `bool`'a çevirir.** `bitti_mi()` iki bitiş varyantını `|` ile birleştirir; içeride `_ => false` olan bir `match`ın kısa yazımıdır.
   ↳ Kaynak: [Rustdoc — matches!](https://doc.rust-lang.org/std/macro.matches.html) · [Book ch19-02 — Pattern Syntax](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html)

6. **Kombinatörler kutuyu açmadan iş yapar.** `ok_or` / `ok_or_else` Option'ı Result'a çevirir ("yokluk"a sebep ekler), `map_err` hatanın türünü değiştirir, `?` hata varsa hemen döner, `and_then` adımın kendisi Option/Result döndürdüğünde `Option<Option<U>>` yerine düz sonuç verir, `filter_map` Result'ı Option'a çevirip hatalıları eler, `unwrap_or_else` yedek değeri o anda üretir.
   ↳ Kaynak: [Rustdoc — Option](https://doc.rust-lang.org/std/option/enum.Option.html) · [Book ch09-02 — Recoverable Errors with Result](https://doc.rust-lang.org/book/ch09-02-recoverable-errors-with-result.html)

7. **Kupon çözümü bu zincirin somut hâlidir.** `kupon.ok_or(KuponHatasi::Yok)?`, `strip_prefix("IND-").ok_or_else(bozuk)?`, `parse().map_err(|_| bozuk())?` ve `oran > 50` denetimi sırayla uygulanır. `Hata çözümü olarak unwrap()/expect()` kullanılmaz: burada her hata ayrı bir varyantla raporlanır.
   ↳ Kaynak: [Book ch09-02 — The `?` Operator](https://doc.rust-lang.org/book/ch09-02-recoverable-errors-with-result.html) · [Rustdoc — Result](https://doc.rust-lang.org/std/result/enum.Result.html)

8. **Ödeme hesabı taşmayı da gözetir.** İndirim `u64::from(tutar) * u64::from(oran) / 100` ile hesaplanır; çünkü büyük `u32` değerlerinde çarpma taşardı. Sonuç `saturating_sub` ile düşülür; tutardan büyük indirim sıfırın altına inmez.
   ↳ Kaynak: [Rustdoc — u32::saturating_sub](https://doc.rust-lang.org/std/primitive.u32.html#method.saturating_sub) · [Rustdoc — u64](https://doc.rust-lang.org/std/primitive.u64.html)

```rust
use SiparisDurumu as D;
match (self, olay) {
    (D::Sepette, Olay::OdemeAlindi { odeme_no }) => Ok(D::Odendi { odeme_no }),
    (D::Odendi { odeme_no }, Olay::KargoyaVerildi { takip_no }) => {
        Ok(D::Kargoda { odeme_no, takip_no })
    }
    (D::Kargoda { takip_no, .. }, Olay::TeslimEdildi) => Ok(D::TeslimEdildi { takip_no }),
    (D::Sepette, Olay::IptalIstendi { neden }) => Ok(D::IptalEdildi { neden, iade: None }),
    (D::Odendi { odeme_no }, Olay::IptalIstendi { neden }) => Ok(D::IptalEdildi {
        neden,
        iade: Some(odeme_no),
    }),
    (durum, olay) => Err(GecersizGecis { durum, olay }),
}
```

## Sık yapılan hatalar

| Kod | Hata | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| `let n: u32 = bazi;` (`bazi: Option&lt;u32&gt;`) | **E0308** | Kutu sayı değildir; `map` ile dönüştür ya da `unwrap_or` ile çık. | [Rustdoc — Option](https://doc.rust-lang.org/std/option/enum.Option.html) |
| `let toplam = bazi + 1;` | **E0369** | `Option&lt;u32&gt;` ile tamsayı toplanamaz; iki ihtimal de ele alınmalı. | [Rustdoc — Option](https://doc.rust-lang.org/std/option/enum.Option.html) |
| `Some("42").map(\|s\| s.parse::<u32>().ok())` → `Option&lt;u32&gt;` | **E0308** | Sonuç `Option&lt;Option&lt;u32&gt;&gt;`; `and_then` düzleştirir. | [Rustdoc — Option::and_then](https://doc.rust-lang.org/std/option/enum.Option.html#method.and_then) |
| `Result` döndüren fonksiyonda `k?` (`k: Option<&str>`) | **E0277** | None'ın hangi hata olduğu bilinmez; `ok_or`/`ok_or_else` ile söyle. | [Book ch09-02 — `?`](https://doc.rust-lang.org/book/ch09-02-recoverable-errors-with-result.html) |
| `p.takma_ad.unwrap_or(String::from("anonim"))` (`p: &Profil`) | **E0507** | `unwrap_or` self'i tüketir; `&Profil` üzerinden tüketilemez. `as_deref()` ile ucuz bir `Option<&str>` elde et. | [Rustdoc — Option::as_deref](https://doc.rust-lang.org/std/option/enum.Option.html#method.as_deref) |
| Desenle `takip_no` alıp `durum`'u yeniden kullanmak | **E0382** | Desen `String`'i durumun içinden çıkardı; `&durum` üzerinde eşleştir, bağlanan değer `&String` olsun. | [Book ch04-02 — Borrowing](https://doc.rust-lang.org/book/ch04-02-references-and-borrowing.html) |
| `OdemeAlindi(no) => ..` (varyantın 2 alanı varken) | **E0023** | Desendeki alan sayısı varyantınkiyle uymaz; `OdemeAlindi(no, _)` ya da struct-like varyant kullan. | [Book ch19-02 — Pattern Syntax](https://doc.rust-lang.org/book/ch19-02-pattern-syntax.html) |

## Derleyici perspektifi

- Eksik varyant `E0004` olarak tür denetiminden sonra THIR üzerinde yakalanır; "usefulness" algoritması `rustc_pattern_analysis` crate'indedir. `ozet()`'te `_` olmaması bilinçli bir tercihtir: yeni varyant her yerde derleme hatası olarak görünür.
  ↳ Kaynak: [rustc 1.99.1 — check_match.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_build/src/thir/pattern/check_match.rs)

- `if let` / `while let` / let-else anlamca `match`'e eşdeğer olsa da **HIR'da match'e indirgenmez**; rustc onları `Let` / `If` / let-else düğümleri olarak korur. `for` → `loop + match` ve `?` → `match` indirgemeleri gerçekten yapılır. Bu ayrımı karıştırmak, derleyici perspektifi hakkında yanlış bir resim verir.
  ↳ Kaynak: [rustc 1.99.1 — expr.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_ast_lowering/src/expr.rs#L324-L325)

- Enum düzeni tagged union'dur; niche varsa ayrı etiket eklenmez. `bool` 1 bayt, `Option<bool>` de 1 bayttır: bool'un kullanmadığı **254 geçersiz desenden biri** `None` olur. Ölçümler kaynak dosyada doğrulanmış olarak kayıtlıdır.
  ↳ Kaynak: [Reference — Type Layout](https://doc.rust-lang.org/reference/type-layout.html) · [Rustdoc — Option](https://doc.rust-lang.org/std/option/enum.Option.html)

## Alıştırmalar

- `SiparisDurumu`'na `IadeBekliyor { takip_no: String }` varyantı ekle; `TeslimEdildi` iken yeni `Olay::IadeIstendi` gelince bu duruma geçilsin. İpucu: önce yalnız varyantı ekle ve `cargo check -p enums` ile derleyicinin seni hangi fonksiyona götürdüğüne bak. Beklenen: `ozet()` `E0004` verir; `gecis()` kabul edilir ama sen kol eklemeden yeni geçişi reddeder.
- `kupon_coz`'u `"IND-20"` yanında `"SABIT-150"` biçimini de tanıyacak şekilde genişlet. İpucu: dönüş türü artık tek `u8` olamaz; `enum Indirim { Yuzde(u8), Sabit(u32) }` tanımla ve hesapta `match` et. Beklenen: 1000 TL → 850, 100 TL → 0 (sabit indirim tutarı aşamaz).
- `fn gorunen_ad(p: &Profil) -> &str` yaz: takma ad varsa ve boş değilse onu, yoksa `"anonim"` döndürsün; `match` ve `if` kullanma. İpucu: `as_deref` + `filter` + `unwrap_or`. Beklenen: `Some("")` ve `None` için `"anonim"`, `Some("kbo")` için `"kbo"`.

↳ Kaynak: [Book ch11-01 — Writing Tests](https://doc.rust-lang.org/book/ch11-01-writing-tests.html) · [Rustdoc — Option::filter](https://doc.rust-lang.org/std/option/enum.Option.html#method.filter)

> **Gelecek bölüme bağlantı:** Buradaki türler tek dosyada duruyor ve `GevsekSiparis`'in alanlarına herkes yazabiliyor. Bölüm 6 kodu modüllere bölmeyi ve `pub` ile neyin dışarı açılacağını anlatır. `Result` ve `?`'ın tamamı hata yönetimi bölümünde; `gecis()`'teki `(durum, olay)` deseninin dayandığı desen dili ise ileri bölümlerde derinleşir.

## Özet ve sonraki adım

- Geçersiz durumları enum ile temsil edilemez kıl; `bool` bayrakları her kullananın denetimini ister.
- Durum makinesi tek bir `(durum, olay)` eşlemesidir; `self` tüketilir, veri taşınır, bilinmeyen çiftler reddedilir.
- Kombinatörler iç içe `match` yerine zincir kurar; `if let` HIR'da match'e indirgenmez.

Sıradaki bölüm: [6. Modüller](06-modules.md).
