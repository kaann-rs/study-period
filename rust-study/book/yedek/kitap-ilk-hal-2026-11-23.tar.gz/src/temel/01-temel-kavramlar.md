# 1. Temel Kavramlar

> Kaynak crate: `learn/basic-concepts` · Çalıştır: `cargo run -p basic-concepts`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)
>
> **Not:** `learn/basic-concepts` crate'inde denetim dışında kalan önceden var olmuş derleme hataları vardır. Bu sayfa kodu düzeltmez; yalnızca kaynak yorumlarda doğrulanmış olanı aktarır.

## Neden bu bölüm?

Bir dil öğrenirken önce isimlerin, sayıların ve küçük tariflerin nasıl yazıldığını bilmen gerekir. Bu crate'de ilk araçlar tek bir dosyada yan yana durur: bir değere isim takmak, o ismi değiştirilebilir yapmak, cinsini söylemek, tarif yazmak ve "şu olursa bunu yap" demek. Derleyicinin kanıtlayamadığı birkaç işin neden ayrı bir `unsafe` kutusuna konduğunu da burada görürsün.

## 5 yaşındaki çocuğa anlatır gibi

Defterine "yaş: 7" diye yazarsın. Tükenmez kalemle yazdıysan üstünü çizemezsin; kurşun kalemle yazdıysan silebilirsin. Sayı mı harf mi olduğunu da söylemen gerekir; yoksa öğretmen ne yazdığını anlamaz.

## Konu anlatımı (madde madde)

1. **`let` bir ismi bir değere bağlar (binding); varsayılan immutable.** `let mut first_var: i32 = 10_i32;` satırında `let` ismi bağlar, `mut` değiştirilebilir yapar; `first_var = 101;` bu yüzden serbesttir.
   ↳ Kaynak: [Book ch02 — Variable Bindings and Mutability](https://doc.rust-lang.org/book/ch02-00-variable-bindings-and-mutability.html) · [Reference](https://doc.rust-lang.org/reference/)

2. **Türü iki yerde belirtirsin: açıklama ve literal son eki.** `: i32` değişkenin cinsini söyler; `10_i32` son eki aynı bilgiyi sayının kendisine ekler.
   ↳ Kaynak: [Book ch03 — Common Programming Concepts](https://doc.rust-lang.org/book/ch03-00-common-programming-concepts.html) · [Reference](https://doc.rust-lang.org/reference/)

3. **`const` derleme zamanı sabitidir; const generic ise DEĞER alır.** `const N: usize = 0;` her zaman değişmez ve türü zorunlu yazılır. `struct Buffer<const N: usize = 0> { data: [u8; N] }` tanımında `N`, türün parçası olan bir uzunluktur; `Buffer<4>` dört baytlık dizi demektir. Böylece `[u8; 4]` ile `[u8; 8]` ayrı türler olsa da tek kod tüm boyutları kapsar.
   ↳ Kaynak: [Book ch10-01 — Generic Data Types](https://doc.rust-lang.org/book/ch10-01-syntax.html) · [Reference](https://doc.rust-lang.org/reference/)

4. **Raw pointer (`*const T`) referansın garantilerini taşımaz.** `&s as *const i32` belleğe doğrudan işaret eder; "ham" olması, normal referansların güvenlik ve ömür garantilerinin YOKLUĞU anlamına gelir. `ptr::read(s1)` belleği değiştirmeden bit kopyası verir; `i32` `Copy` olduğu için orijinal değeri tekrar okumak sorun değildir.
   ↳ Kaynak: [Book ch20-01 — Unsafe Rust](https://doc.rust-lang.org/book/ch20-01-unsafe-rust.html) · [Nomicon](https://doc.rust-lang.org/nomicon/) · [Rustdoc — Copy](https://doc.rust-lang.org/std/marker/trait.Copy.html)

5. **`unsafe` güven yüzeyini küçültür.** C gibi her yerde serbest bellek işlemi tanıyan dillerde bir hata KODUN HER YERİNDE olabilir; Rust derleyicinin kanıtlayamadığı işleri yalnız `unsafe` bloklara hapseder. Kaynak dosyadaki `// SAFETY: s1, &s'den geliyor ve her iki okuma da s yaşarken oluyor.` yorumu, garantinin programcı tarafından verildiğini gösterir.
   ↳ Kaynak: [Book ch20-01 — Unsafe Rust](https://doc.rust-lang.org/book/ch20-01-unsafe-rust.html) · [rustc 1.99.1 — check_unsafety.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_build/src/check_unsafety.rs)

6. **Trait bound bir sözleşmedir.** `Color<F>` içinde `F` tutar; `where F: Fn(i8) -> i8` şartı, `F`'nin bir `i8` ile çağrılıp `i8` döndürebilmesini ister. Sınırsız bir generic ile derleyici `F` hakkında hiçbir şey bilmez; metot bile çağıramazsın.
   ↳ Kaynak: [Book ch10-02 — Traits](https://doc.rust-lang.org/book/ch10-02-traits.html) · [Book ch13-01 — Closures](https://doc.rust-lang.org/book/ch13-01-closures.html)

7. **Fn / FnMut / FnOnce neyi nasıl yakaladığına göre ayrılır.** Sadece okuyan closure defalarca paylaşarak çağrılır (Fn); yakaladığını değiştiren özel erişim ister (FnMut); yakaladığını tüketen bir closure **en fazla bir kez** çağrılabilir (FnOnce). Ayrım olmasaydı taşınmış değeri yeniden kullanmak ya da aynı anda iki `&mut` oluşturmak mümkün olurdu.
   ↳ Kaynak: [Book ch13-01 — Closures](https://doc.rust-lang.org/book/ch13-01-closures.html) · [Rustdoc](https://doc.rust-lang.org/std/)

8. **Closure çevreyi yakalar, function pointer yakalayamaz.** `let x = |y: i8| -> i8 { y };` hiçbir şey yakalamaz; `Color::hex(x, x)` çağrısında ilk `x` kendi closure türünü korur, ikincisi `fn(i8) -> i8` işaretçisine dönüşür (coercion). Her closure ayrı bir türdür; fn pointer ise tek somut tür olarak depolanır ve FFI'da kullanılabilir.
   ↳ Kaynak: [Book ch13-01 — Closures](https://doc.rust-lang.org/book/ch13-01-closures.html) · [Reference — Type coercions](https://doc.rust-lang.org/reference/type-coercions.html)

9. **Associated type, her implementasyonun doldurduğu bir "tür yuvası"dır.** `trait Animal<T> { type Your; fn voice() -> T; }` içinde `Your` ilişkili tür; `voice()` ise `self` almadığı için tür üzerinden çağrılan bir associated function'dır (`Color::<fn(i8) -> i8>::voice()`). `Iterator` associated type kullandığı için bir tür hem `Iterator<i32>` hem `Iterator<String>` olamaz; `for x in it` belirsiz kalmaz.
   ↳ Kaynak: [Book ch10-02 — Traits](https://doc.rust-lang.org/book/ch10-02-traits.html) · [Rustdoc — Iterator](https://doc.rust-lang.org/std/iter/trait.Iterator.html)

10. **Inherent impl doğrudan türe metot ekler.** `impl<F> Color<F> { fn hex(f: F, b: fn(i8) -> i8) -> i8 { f(1) } }` bloğu `hex`'i bir trait üzerinden değil `Color`'ın kendisine ekler. Generic `F` yakalama ve inline hızı verir; somut `fn(i8) -> i8` parametresi tek türde depolama ve FFI imkânı sağlar.
    ↳ Kaynak: [Book ch05-03 — Method Syntax](https://doc.rust-lang.org/book/ch05-03-method-syntax.html) · [Book ch10-01 — Generic Data Types](https://doc.rust-lang.org/book/ch10-01-syntax.html)

11. **HRTB: süreyi çağıran seçer.** `for<'a> Fn(&'a i8)` "her `'a` seçimi için" der; somut ömür closure'ın çağrıldığı yerde seçilir ve `f` tüm ömürlere uymak zorundadır. `<'a, F> ... Fn(&'a i8)` ise tek sabit bir `'a` verir; onu `hex_v3`'ü çağıran dıştan belirler, bu yüzden yerel `&n` ile `E0597` alınır.
    ↳ Kaynak: [Nomicon — HRTB](https://doc.rust-lang.org/nomicon/hrtb.html) · [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html)

12. **Yetim kuralı (orphan rule): trait ya da tür senin olmalı.** Bir trait'i bir tür için implemente edebilmek için ikisinden en az biri bu crate'te tanımlı olmalı; amaç program boyunca her (trait, tür) ikilisi için en fazla bir impl olması (coherence). Yabancı türü kendi struct'ının içine sarmak (newtype) geçerli çıkış yollarından biridir.
    ↳ Kaynak: [Book ch10-02 — Traits](https://doc.rust-lang.org/book/ch10-02-traits.html) · [Reference — Items: traits](https://doc.rust-lang.org/reference/items/traits.html)

## Kodda nasıl görünür?

Aşağıdaki parçalar `learn/basic-concepts/src/main.rs` dosyasından alınmıştır. Crate'in tamamında denetim dışında kalmış önceden var olan hatalar bulunduğu için bu sayfa, tüm dosya için "doğrulandı" iddiası yapmaz.

```rust
fn main() {
    let mut first_var: i32 = 10_i32;
    first_var = 101;
    println!("First Variables {}", first_var);
}

const N: usize = 0;

struct Color<F>
where
    F: Fn(i8) -> i8,
{
    x: F,
}

impl<F> Color<F>
where
    F: Fn(i8) -> i8,
{
    fn hex(f: F, b: fn(i8) -> i8) -> i8 {
        f(1)
    }
}

fn hex_v2<F>(f: F) -> i8
where
    F: for<'a> Fn(&'a i8) -> i8,
{
    f(&1)
}

fn hex_v3<'a, F>(f: F) -> i8
where
    F: Fn(&'a i8) -> i8,
{
    f(&1)
}

fn test() {
    let x = |y: i8| -> i8 { y };
    let a: i8 = Color::hex(x, x);
    println!("{:?}", a);
}
```

## Sık yapılan hatalar

| Kod / durum | Sonuç | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| `let x = 5; x = 6;` | **E0384** | `x` varsayılan immutable; değiştirmek için `let mut x`. | [Book ch02](https://doc.rust-lang.org/book/ch02-00-variable-bindings-and-mutability.html) |
| `let tuket = move \|\| drop(s); tuket(); tuket();` | 2. çağrı derlenmez | FnOnce en fazla bir kez çağrılır; `s` ilk çağrıda taşındı. | [Book ch13-01](https://doc.rust-lang.org/book/ch13-01-closures.html) |
| `fn hex_v3_yerel<'a, F>(f: F) -> i8 { let n = 1; f(&n) }` | **E0597** | `f` dıştaki tek `'a`'yı ister; `n` iç bölgede ölür. `for<'a>` kullan. | [Nomicon — HRTB](https://doc.rust-lang.org/nomicon/hrtb.html) · [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html) |
| `impl std::fmt::Display for Vec<i32> {}` | Yetim kuralı ihlali | İkisi de yabancı; E0119 yalnız aynı crate içindeki çakışmayı yakalar. Newtype kullan. | [Book ch10-02](https://doc.rust-lang.org/book/ch10-02-traits.html) |
| `#[proc_macro]` bildirimi normal binary crate'de | Derlenmez | proc-macro crate'i gerekir; denetim dışında kalmış önceden var olan hatalardandır. | [Book ch20-05 — Macros](https://doc.rust-lang.org/book/ch20-05-macros.html) |

## Derleyici perspektifi

- Trait bound'lar HIR tür denetiminde çözülür; her somut `F` için monomorphization ayrı kod üretir. Sınırsız generic'in aksine çağrı yerinde net denetim yapılır.
  ↳ Kaynak: [Book ch10-01](https://doc.rust-lang.org/book/ch10-01-syntax.html) · [rustc 1.99.1 — collector.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_monomorphize/src/collector.rs)

- Closure'ın hangi değişkeni nasıl yakaladığı (kopya / `&mut` / sahiplik) `upvar` analizinde belirlenir; Fn/FnMut/FnOnce seçimi bu yakalama moduna bağlıdır.
  ↳ Kaynak: [rustc 1.99.1 — upvar.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_hir_typeck/src/upvar.rs) · [Book ch13-01](https://doc.rust-lang.org/book/ch13-01-closures.html)

- `for<'a>` gibi yüksek dereceli bound'lar tür denetiminde çözülür. `&1` literali `'static`'e terfi ettiği için iki `hex_v*` gövdesi de derlenir; fark static'e terfi etmeyen yerel `&n` ile ortaya çıkar.
  ↳ Kaynak: [Nomicon — HRTB](https://doc.rust-lang.org/nomicon/hrtb.html) · [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html)

- `unsafe` blokların derleyicinin denetiminden çıkan kısmı MIR kurulumunda izlenir; güvenlik yükü programcının `// SAFETY` gerekçesindedir.
  ↳ Kaynak: [rustc 1.99.1 — check_unsafety.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_build/src/check_unsafety.rs) · [Book ch20-01](https://doc.rust-lang.org/book/ch20-01-unsafe-rust.html)

## Özet ve sonraki adım

- `let` isim bağlar, `mut` değiştirme izni verir; `const` derleme zamanı sabiti, const generic ise türün parçası olan bir DEĞERdir.
- Trait bound bir sözleşmedir; Fn/FnMut/FnOnce yakalama biçimine göre çağrı hakkını (en fazla bir kez dahil) belirler.
- `unsafe` küçük bir kutudur; orphan kuralı ve HRTB belirsizliği derleme zamanında keser.

Sıradaki bölüm: [2. Yaygın Kavramlar](02-yaygin-kavramlar.md).
