# 2. Yaygın Kavramlar

> Kaynak crate: `learn/common-concepts` · Çalıştır: `cargo run -p common-concepts`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

## Neden bu bölüm?

Önceki bölümde isimlerin ve küçük tariflerin nasıl yazıldığını görmüştük. Şimdi o isimlerin nasıl davrandığını soruyoruz: değişebilir mi, cinsi ne, hangi yol tabelasını izleyecek? Bir program; isimli değerlerden, o değerlerin cinsinden, iş yapan küçük tariflerden ve "şu olursa bunu yap" diyen yapılardan oluşur. Bu bölüm dört temel parçayı ve hepsinin arkasındaki tek kuralı anlatır.

## 5 yaşındaki çocuğa anlatır gibi

Okulda defterin, kalemin, çantan var. Deftere bir sayı yazarsın; üstünü çizmek istersen önce "silebilir" demen gerekir. Öğretmen "şu kapı kapalı, şu kapı açık" der; sen de tabelaya bakıp yürürsün.

## Konu anlatımı (madde madde)

1. **Binding ve varsayılan immutable.** `let x = 5;` tükenmez kalemdir: `x = 6;` derlenmez. `let mut y = 5;` kurşun kalemdir; `y = 6;` serbesttir. `mut` "burası değişecek" işaretidir.
   ↳ Kaynak: [Book ch02 — Variable Bindings and Mutability](https://doc.rust-lang.org/book/ch02-00-variable-bindings-and-mutability.html) · [Book ch03 — Common Programming Concepts](https://doc.rust-lang.org/book/ch03-00-common-programming-concepts.html)

2. **Neden varsayılan immutable?** Kısa cevap: yanlışlıkla değiştirmeyi engeller, niyeti açık kılar, derleyici sabit değerlere güvenip optimize eder. Kök cevap tek bir kuraldır: Aliasing XOR Mutability — aynı veriye ya birçok ok BAKAR ya da tek ok YAZAR, ikisi aynı anda olmaz.
   ↳ Kaynak: [Book ch04-02 — References and Borrowing](https://doc.rust-lang.org/book/ch04-02-references-and-borrowing.html) · [Nomicon — Aliasing](https://doc.rust-lang.org/nomicon/aliasing.html)

3. **`const` derleme zamanı sabitidir.** `const MAX_PUAN: u32 = 100_000;` satırında tür zorunlu yazılır, değer derleme anında hesaplanır ve asla `mut` olamaz. `let n = 3; [0; n]` olmaz; dizi uzunluğu gibi yerlerde `const` gerekir.
   ↳ Kaynak: [Book ch02 — Variables and Mutability](https://doc.rust-lang.org/book/ch02-00-variable-bindings-and-mutability.html) · [Reference](https://doc.rust-lang.org/reference/)

4. **Shadowing yeni bir binding oluşturur; türü değiştirebilir.** `let bosluk = "   ";` ardından `let bosluk = bosluk.len();` yazınca ikinci isim `usize`'dır; eskisi silinmez, sadece o isimden erişilemez olur. `mut` ile tür değiştirilemez (`E0308`), shadowing ile değiştirilir ve sonuç yine immutable kalır.
   ↳ Kaynak: [Book ch02 — Shadowing](https://doc.rust-lang.org/book/ch02-00-variable-bindings-and-mutability.html) · [Reference](https://doc.rust-lang.org/reference/)

5. **Scalar türler: integer, float, bool, char.** `i32` işaretli tam sayı, `f64` varsayılan küsuratlı sayı, `bool` yalnız doğru/yanlış, `char` tek bir Unicode scalar değerdir (`'ş'` 4 byte tutar). Cinsi belli olmayan değerle ne yapılabileceği de belli olmaz; derleyici karışıklığı çalışmadan yakalar.
   ↳ Kaynak: [Book ch03 — Data Types](https://doc.rust-lang.org/book/ch03-00-common-programming-concepts.html) · [Reference](https://doc.rust-lang.org/reference/)

6. **Integer overflow debug'da panik, release'de sarar.** `u8` en çok 255 tutar; 255 + 1 debug derlemesinde programı durdurur, release'de başa sarar. Kasıtlı sarma için `wrapping_add`, "sığmadı" haberini almak için `checked_add` (None) kullanılır.
   ↳ Kaynak: [Book ch03 — Integer Overflow](https://doc.rust-lang.org/book/ch03-00-common-programming-concepts.html) · [Rustdoc — u8](https://doc.rust-lang.org/std/primitive.u8.html)

7. **Compound türler: tuple ve array.** `let demet: (i32, f64, char) = (1, 2.0, 'x');` farklı cinsleri yan yana tutar; `let (a, b, c) = demet;` ile parçalanır, `.1` ile indekslenir. `let dizi = [10, 20, 30];` aynı cinsten, uzunluğu baştan belli ve stack'te duran bir sıradır.
   ↳ Kaynak: [Book ch03 — Data Types](https://doc.rust-lang.org/book/ch03-00-common-programming-concepts.html) · [Rustdoc — array](https://doc.rust-lang.org/std/primitive.array.html)

8. **Dizi sınırı denetlenir.** `dizi[0]` normal erişimdir; çalışma anında sınır dışına çıkarsa program panikler. `dizi.get(1)` → `Some(20)`, `dizi.get(5)` → `None` verir ve program sürer. `dizi[5]` gibi sabit indeksi derleyici `deny(unconditional_panic)` ile daha derleme anında reddeder.
   ↳ Kaynak: [Book ch03 — Data Types](https://doc.rust-lang.org/book/ch03-00-common-programming-concepts.html) · [Rustdoc — slice](https://doc.rust-lang.org/std/primitive.slice.html)

9. **Statement iş yapar, expression değer verir.** `let x = 5;` bir statement, `5 + 6` bir expression'dır. `fn toplam(x: i32, y: i32) -> i32 { x + y }` satırının sonunda noktalı virgül YOKTUR; `;` eklersen ifade statement'a döner, `()` döner ve `E0308` alırsın.
   ↳ Kaynak: [Book ch03 — Functions](https://doc.rust-lang.org/book/ch03-00-common-programming-concepts.html) · [Reference](https://doc.rust-lang.org/reference/)

10. **`if` bir ifadedir; dallar aynı türde olmalı.** `let etiket = if sayi % 2 == 0 { "çift" } else { "tek" };` değer üretir ve `let`'e atanabilir. Bir dal `i32`, öbürü `&str` dönseydi derleyici değişkenin türünü tek ve kesin bilemezdi.
    ↳ Kaynak: [Book ch03 — Control Flow](https://doc.rust-lang.org/book/ch03-00-common-programming-concepts.html) · [Reference](https://doc.rust-lang.org/reference/)

11. **Döngüler: loop, while, for.** `loop` "dur" denene kadar döner ve `break sayac * 2;` ile bir değer verebilir; `while geri > 0` koşul tutar; `for i in 1..4` aralığı (1, 2, 3) gezer. `for` en güvenlisidir: koleksiyonun kendisi üzerinde gezdiği için sınırı elle yazma hatası kalmaz.
    ↳ Kaynak: [Book ch03 — Control Flow](https://doc.rust-lang.org/book/ch03-00-common-programming-concepts.html) · [Rustdoc — Iterator](https://doc.rust-lang.org/std/iter/trait.Iterator.html)

12. **Aliasing XOR Mutability tek kök kuraldır.** Aynı veriye işaret eden bir `alias` varken yazmak: `Vec` yeniden tahsis edilirse referans boşu gösterir (use-after-free), döngü sırasında değiştirmek iterator'ı bozar, iki thread biri yazıp biri okursa veri yarışı olur. Rust bütün bunları baştan keser: ya N tane `&T` ya tam 1 tane `&mut T`. Yazma yetkisi tehlikeli olduğu için varsayılan dışı tutulur.
    ↳ Kaynak: [Book ch04-02 — The Rules of References](https://doc.rust-lang.org/book/ch04-02-references-and-borrowing.html) · [Nomicon — Aliasing](https://doc.rust-lang.org/nomicon/aliasing.html) · [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs)

## Kodda nasıl görünür?

Aşağıdaki parçalar `learn/common-concepts/src/main.rs` dosyasından alınmıştır.

```rust
fn degiskenler_ve_mut() {
    let x = 5;
    println!("x = {x}"); // immutable; `x = 6;` yazsan derlenmez (E0384)

    let mut y = 5;
    y = 6;
    println!("yeni y = {y}");

    const MAX_PUAN: u32 = 100_000;
    println!("MAX_PUAN = {MAX_PUAN}");
}

fn golgeleme() {
    let bosluk = "   ";
    let bosluk = bosluk.len(); // &str → usize — shadowing
    println!("boşluk sayısı = {bosluk}");
}

fn toplam(x: i32, y: i32) -> i32 {
    x + y // son ifade; NOKTALI VİRGÜL YOK → dönen değer budur
}

fn kontrol_akisi() {
    let sayi = 7;
    let etiket = if sayi % 2 == 0 { "çift" } else { "tek" };
    println!("{sayi} → {etiket}");

    let mut sayac = 0;
    let sonuc = loop {
        sayac += 1;
        if sayac == 5 {
            break sayac * 2;
        }
    };
    println!("loop sonucu = {sonuc}");

    for i in 1..4 {
        print!("{i} "); // 1, 2, 3 (4 hariç)
    }
    println!();
}
```

## Sık yapılan hatalar

| Kod / durum | Sonuç | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| `let x = 5; x = 6;` | **E0384** | Immutable binding'e atama; `let mut x` yaz. | [Book ch02](https://doc.rust-lang.org/book/ch02-00-variable-bindings-and-mutability.html) |
| `let mut s = "   "; s = s.len();` | **E0308** | `mut` değeri değiştirir, cinsini değiştiremez; shadowing kullan. | [Book ch02](https://doc.rust-lang.org/book/ch02-00-variable-bindings-and-mutability.html) |
| `fn bozuk(x: i32) -> i32 { x * 2; }` | **E0308** | `;` cevabı attı, geriye `()` kaldı; son satıra noktalı virgül koyma. | [Book ch03](https://doc.rust-lang.org/book/ch03-00-common-programming-concepts.html) |
| `if zil_caldi { 1 } else { "yok" }` | **E0308** | İki dal aynı cinsten olmalı. | [Book ch03](https://doc.rust-lang.org/book/ch03-00-common-programming-concepts.html) |
| `puan: u8 = 255; puan + 1` (debug) | Panik | Taşma; `checked_add` → None, `wrapping_add` → 0. | [Book ch03](https://doc.rust-lang.org/book/ch03-00-common-programming-concepts.html) |
| `siralar[5]` / `siralar[i]` sınır dışı | Derleme hatası / çalışma anı panik | Sabit indekte `deny(unconditional_panic)`; değişkende sınır denetimi. `get` güvenli. | [Rustdoc — slice](https://doc.rust-lang.org/std/primitive.slice.html) |
| Aynı veriye iki `&mut` | Derlenmez | Aliasing XOR Mutability; borrow checker MIR'de reddeder. | [Book ch04-02](https://doc.rust-lang.org/book/ch04-02-references-and-borrowing.html) · [Nomicon — Aliasing](https://doc.rust-lang.org/nomicon/aliasing.html) |

## Derleyici perspektifi

- **1–3. durak:** `rustc_lexer` metni token'a böler, `rustc_parse` AST'yi kurar, `rustc_ast_lowering` AST'yi HIR'a indirger. Burada "desugaring" olur: `for` → `loop + match`, `while` → `loop`, `?` → `match`.
  ↳ Kaynak: [Reference](https://doc.rust-lang.org/reference/) · [Book ch03 — Control Flow](https://doc.rust-lang.org/book/ch03-00-common-programming-concepts.html)

- **4–5. durak:** `rustc_hir_typeck` tür çıkarımı ve trait çözümü yapar; tür uyuşmazlığı (**E0308**) burada doğar. `rustc_mir_build` HIR'ı MIR'e (temel blokların kontrol-akış grafiği) çevirir; dizi sınırı ve taşma denetimleri burada `Assert` düğümleri olarak eklenir. Kaynak yorumda atıflar: `compiler/rustc_mir_build/src/builder/mod.rs:872` ve `compiler/rustc_mir_build/src/builder/expr/as_place.rs:752`.
  ↳ Kaynak: [Reference](https://doc.rust-lang.org/reference/) · [Rustdoc — array](https://doc.rust-lang.org/std/primitive.array.html)

- **6. durak:** `rustc_borrowck` MIR üzerinde çalışır; NLL (non-lexical lifetimes), ödünç kuralları ve immutable binding'e atama (**E0384**) burada denetlenir. Aynı fonksiyonda bir tür hatası (**E0308**) varsa E0384 hiç raporlanmaz, çünkü derleme bu aşamaya ulaşmaz.
  ↳ Kaynak: [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs) · [rustc 1.99.1 — nll.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/nll.rs)

- **7–9. durak:** `rustc_mir_transform` gereksiz bounds check'leri kaldırır, `rustc_monomorphize` generic'leri somut türlerle özelleştirir, `rustc_codegen_llvm` LLVM IR üzerinden makine kodu üretir. Optimizer indeksin güvenli olduğunu kanıtlayabilirse denetimi kaldırır; güvenlik yine korunur.
  ↳ Kaynak: [Book ch10-01](https://doc.rust-lang.org/book/ch10-01-syntax.html) · [rustc 1.99.1 — collector.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_monomorphize/src/collector.rs)

## Özet ve sonraki adım

- Program; isimli değerler, türler, fonksiyonlar ve kontrol akışından oluşur; varsayılan immutable, `mut` açık izindir.
- Statement değer vermez, expression verir; `if` bir ifadedir, `for` en güvenli döngüdür.
- Aliasing XOR Mutability tek kök kuraldır; borrow checker onu MIR üzerinde, çalışma anı maliyeti eklemeden zorlar.

Sıradaki bölüm: [3. Ownership (Sahiplik)](03-ownership.md).
