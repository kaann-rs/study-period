# 4.1 Struct'lar: Derinleşme

> Kaynak dosya: `learn/structs/src/derinlesme.rs` · Test: `cargo test -p structs`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

Önceki sayfada struct'ın sözdizimini gördük: alanlar, üç receiver, `derive(Debug)`. Bu sayfada aynı araçlarla küçük bir kullanıcı yönetimi modülü tasarlıyoruz: alanları kapalı tutup doğrulayan yapıcı, builder kalıbı, receiver seçimi ve `..taban` ile gelen kısmi move tuzağı.

## Neden bu sayfa?

`main.rs`te `Kullanici` alanlarına her kod yazabiliyordu; `eposta: "asdf".into()` da yazılabilirdi. Oysa bir karta güvenen posta gönderimi veya alan adına göre gruplama, içindeki yazının geçerli olduğunu varsayar. Kuralı her kullananın denetlemesi yerine modülün kapısına koyarsan, kart geçerli olmadan hiç üretilemez — değişmez (invariant) tek yerde yaşar.

## Gerçek senaryo: kullanıcı yönetimi modülü

Benzetme öğrenci kartından kayıt bürosuna geçer: kartı kendin yazamazsın, yalnız büro basar ve önce bilgini denetler. Kodda büro `mod hesap`, kartın gözleri `pub` olmadığı için dışarıya kapalıdır; kart yalnız büronun `ayristir` / `olustur` fonksiyonlarıyla üretilir. `Eposta(String)` tek alanlı bir newtype'tır; içindeki `String` private olduğu için yalnız denetimden geçen yazı `Eposta` olabilir.

İlan edilen değişmez: **boşluksuz, küçük harfli, tek `@` içeren, `@` öncesi boş olmayan ve alan adında nokta bulunan adres.** Bu, gerçek e-posta doğrulamasından daha sade bir örnektir; amaç kalıbı göstermektir.

## Adım adım kod analizi

1. **Denetim yapıcıda toplanır.** `Eposta::ayristir(ham: &str) -> Result<Eposta, String>` önce `trim()` yapar, `split_once('@')` ile parçaları kontrol eder, geçerliyse `Ok(Eposta(ham.to_lowercase()))`, değilse `Err(format!(...))` döner. Eposta üretmenin tek yolu budur; alanı okuyan kod tekrar denetlemez.
   ↳ Kaynak: [Book ch09-02 — Recoverable Errors with Result](https://doc.rust-lang.org/book/ch09-02-recoverable-errors-with-result.html) · [Reference — Visibility and Privacy](https://doc.rust-lang.org/reference/visibility-and-privacy.html)

2. **Salt okunur erişim değişmezi korur.** `as_str(&self) -> &str` ve `alan_adi(&self) -> &str` yalnız bakış verir; `String`'in kendisini ya da `&mut`'unu vermez. `@` kesin var olduğu için `alan_adi` hata dalı tasarlamaz.
   ↳ Kaynak: [Book ch04-02 — References and Borrowing](https://doc.rust-lang.org/book/ch04-02-references-and-borrowing.html) · [Book ch05-03 — Method Syntax](https://doc.rust-lang.org/book/ch05-03-method-syntax.html)

3. **Builder, isimli argümanların yerini alır.** `KullaniciKurucu` zorunlu alanları `Option<String>` ile "verilmedi" başlatır; `ad(mut self, ..) -> Self` gibi adımlar kurucuyu devralıp günceller ve zinciri kurar. `olustur(self)` kurucuyu tüketir; içindeki `String`ler yeni `Kullanici`'ya **taşınır**, kopyalanmaz. Rust'ta isimli argüman olmadığı için `yeni("Ada", "a@b.c", true, false)` yerine her değer adlandırılır.
   ↳ Kaynak: [Book ch05-03 — Method Syntax](https://doc.rust-lang.org/book/ch05-03-method-syntax.html) · [Book ch04-01 — Move](https://doc.rust-lang.org/book/ch04-01-what-is-ownership.html)

4. **Receiver seçimi bir sahiplik sözleşmesidir.** `giris_kaydet(&mut self)` sayacı yalnız bu metot artırır; `pasiflestir(self)` aktif kullanıcıyı tüketip `PasifKullanici` döner. Pasif türde `giris_kaydet` diye bir metot yoktur, dolayısıyla yanlış çağrı derlenmez — "aktif mi?" bayrağını çalışma anında denetlemeye gerek kalmaz. `yeniden_etkinlestir(self)` yetkiyi geri vermez; kural tek yerde, bu modülde yazılıdır.
   ↳ Kaynak: [Book ch05-03 — Method Syntax](https://doc.rust-lang.org/book/ch05-03-method-syntax.html) · [Book ch04-01 — What is Ownership?](https://doc.rust-lang.org/book/ch04-01-what-is-ownership.html)

5. **`..taban` alan alan çalışır.** `Ayarlar { tema: String::from("koyu"), ..taban }` içinde `..` yalnız yazılmayan alanları alır: `dil: String` taşınır, `bildirim` ve `sayfa_boyutu` kopyalanır. `taban.tema` yerine yeni değer yazıldığı için tek başına okunabilir; ama `taban` bütün olarak kullanılamaz, çünkü `dil` gitti. Kaynağı korumak gerekiyorsa kopyayı açıkça istemek gerekir (maliyet görünür olur): `..taban.clone()`.
   ↳ Kaynak: [Book ch05-02 — Struct Update Syntax](https://doc.rust-lang.org/book/ch05-02-example-structs.html) · [Book ch04-01 — Move](https://doc.rust-lang.org/book/ch04-01-what-is-ownership.html)

6. **"Varlıklar + birkaç fark" deyimi en güvenli kullanımdır.** `Ayarlar { bildirim: false, ..Default::default() }` geçici bir değeri taşır; kimsenin elindeki kart etkilenmez ve struct'a yeni alan eklendiğinde satır değişmeden derlenmeye devam eder. Buna karşılık bir alanı unutup `..` kullanmamak `E0063` verir: Rust'ta yarım kurulmuş struct olmaz.
   ↳ Kaynak: [Book ch05-02 — Struct Update Syntax](https://doc.rust-lang.org/book/ch05-02-example-structs.html) · [Rustdoc — Default](https://doc.rust-lang.org/std/default/trait.Default.html)

```rust
#[derive(Debug, Clone, PartialEq)]
pub struct Eposta(String);

impl Eposta {
    // Eposta üretmenin TEK yolu: denetim geçilmeden değer oluşmaz, alan kod tekrar denetlemez.
    pub fn ayristir(ham: &str) -> Result<Eposta, String> {
        let ham = ham.trim();
        let gecerli = ham.split_once('@').is_some_and(|(yerel, alan)| {
            !yerel.is_empty()
                    && alan.contains('.')
                    && !alan.contains('@') // tek '@'
                    && !ham.contains(char::is_whitespace)
        });
        if gecerli {
            Ok(Eposta(ham.to_lowercase()))
        } else {
            Err(format!("geçersiz e-posta: '{ham}'"))
        }
    }

    // Salt okunur erişim: &str verir, String'in kendisini (ve &mut'unu) vermez.
    pub fn as_str(&self) -> &str {
        &self.0
    }
}
```

## Sık yapılan hatalar

| Kod | Hata | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| `hesap::Eposta(String::from("asdf"))` (modül dışı) | **E0603** | Tuple struct kurucusu private; kartı yalnız büro basar. `Eposta::ayristir(..)` kullan. | [Reference — Visibility and Privacy](https://doc.rust-lang.org/reference/visibility-and-privacy.html) |
| `println!("{}", e.0)` (modül dışı) | **E0616** | Alan erişimi modül bazlı gizliliğe tabidir; `as_str()` kullan. | [Reference — Visibility and Privacy](https://doc.rust-lang.org/reference/visibility-and-privacy.html) |
| `Kullanici { ad: .., eposta: .., .. }` (modül dışı) | **E0451** | Tüm alanlar private; `Kullanici::kurucu()` zincirini kullan. | [Reference — Visibility and Privacy](https://doc.rust-lang.org/reference/visibility-and-privacy.html) |
| `KullaniciKurucu::default().ad("Kaan").olustur()` ayarlayıcılar `&mut Self` döndürseydi | **E0507** | Zincirin ucunda yalnız `&mut` kalır; ödünç alınan tüketilemez. `self -> Self` kullan. | [Book ch04-02 — Borrowing](https://doc.rust-lang.org/book/ch04-02-references-and-borrowing.html) |
| `let k1 = b.olustur(); let k2 = b.olustur();` | **E0382** | `olustur(self)` kurucuyu tüketir; iki kullanıcı için iki zincir yaz. | [Book ch04-01 — Move](https://doc.rust-lang.org/book/ch04-01-what-is-ownership.html) |
| `let mut ada = ..; ada.giris_kaydet();` (`mut` yoksa) | **E0596** | `&mut self` çağırmak için binding'in `mut` olması gerekir: `let mut ada`. | [Book ch05-03 — Method Syntax](https://doc.rust-lang.org/book/ch05-03-method-syntax.html) |
| `fn arsivle(k: &Kullanici) -> PasifKullanici { k.pasiflestir() }` | **E0507** | `self` sahiplik ister; imza `fn arsivle(k: Kullanici)` olmalı. | [Book ch04-02 — Borrowing](https://doc.rust-lang.org/book/ch04-02-references-and-borrowing.html) |
| `Ayarlar { tema: String::from("koyu") }` | **E0063** | Eksik alanlar: `dil`, `bildirim`, `sayfa_boyutu`. Ya hepsini ver ya `..` kullan. | [Book ch05-01 — Instantiating Structs](https://doc.rust-lang.org/book/ch05-01-defining-structs.html) |

## Derleyici perspektifi

- Gizlilik modül bazlıdır: `pub` olmayan alan ve tuple struct kurucusu yalnız tanımlandığı modülden (ve altlarından) görülür. Dışarıdan denetimi atlamaya çalışmak `E0603` / `E0616` / `E0451` üretir.
  ↳ Kaynak: [Reference — Visibility and Privacy](https://doc.rust-lang.org/reference/visibility-and-privacy.html)

- Kısmi move alan bazında izlenir; taşınan alan "başlatılmamış" sayılır ve struct'ın tamamı artık kullanılamaz. Bu veri akışı borrowck tarafından yürütülür.
  ↳ Kaynak: [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs) · [rustc 1.99.1 — borrow_set.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrow_set.rs)

- `#[derive(Debug, Clone, PartialEq, Default)]` gibi standart derive'lar derleyiciye gömülü (built-in) makrolardır; `serde::Serialize` gibi kullanıcı derive'ları ise gerçek proc-macro'dur. İkisini aynı sınıfa koymak yanlıştır.
  ↳ Kaynak: [Book ch20-05 — Derive Macros](https://doc.rust-lang.org/book/ch20-05-macros.html) · [Reference — Derive](https://doc.rust-lang.org/reference/attributes/derive.html)

## Alıştırmalar

- `Parola` newtype'ı yaz: en az 8 karakter ve en az bir rakam içermeyeni reddetsin. İpucu: `Eposta::ayristir` ile aynı kalıp; alanı private tut, `chars().any(..)` işini görür. Beklenen: `"kisa1"` → `Err`, `"uzunparola1"` → `Ok`. Ek soru: `Parola`'ya neden `derive(Debug)` eklemek istemeyebilirsin?
- `KullaniciKurucu`'ya `dil(self, &str) -> Self` adımı ekle; verilmezse `"tr"` olsun ve `ozet()` bunu göstersin. İpucu: `Option<String>` + `olustur()` içinde `unwrap_or_else`. `Kullanici`'ya alan ekleyince derleyicinin seni hangi iki yapıcı ifadeye götürdüğüne bak (`E0063`).
- `Kullanici::ad_degistir` metodunu yaz: boş (yalnız boşluk) adı reddetsin. İpucu: değer yerinde değişiyor ve eski hâli anlamsızlaşmıyor — doğru receiver hangisi? Beklenen: başarısız çağrıdan sonra `ad()` eski değeri döndürür.

↳ Kaynak: [Book ch11-01 — Writing Tests](https://doc.rust-lang.org/book/ch11-01-writing-tests.html) · [Book ch05-03 — Method Syntax](https://doc.rust-lang.org/book/ch05-03-method-syntax.html)

> **Gelecek bölüme bağlantı:** `PasifKullanici` ile "durumu türle ifade etme"nin ilk adımını attık; ama aktif ve pasif kullanıcıyı aynı listede tutamıyoruz, çünkü bunlar iki ayrı tür. `enum Hesap { Aktif(..), Pasif(..) }` tam bunu çözer. `KullaniciKurucu`'daki `Option` ve `olustur()`'un döndürdüğü `Result` da birer enum.

## Özet ve sonraki adım

- Private alan + doğrulayan yapıcı, değişmezi tek yerde denetler; okuyan kod güvenle varsayabilir.
- Receiver bir sözleşmedir: `&self` okur, `&mut self` değiştirir, `self` eski türü geçersiz kılar.
- `..taban` yalnız alınan non-Copy alanları taşır; kopya gerekliyse açıkça istenir, kaynak bütün olarak korunmaz.

Sıradaki bölüm: [5. Enum'lar ve Desen Eşleme](05-enums.md).
