# 8. Hata Yönetimi

> Kaynak crate: `learn/error-handling` · Çalıştır: `cargo run -p error-handling`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

## Neden bu bölüm?

Mutfakta kek yaparken ocak tutuşursa keke devam etmezsin; her şeyi bırakır, ocağı kapatır ve mutfaktan çıkarsın. Ama süt kalmadıysa bu bir felaket değildir: ya durursun ya da annene sorarsın. Rust'ta bu iki durum ayrı ayrı yazılır: biri `panic!`, diğeri `Result`. Try/catch yoktur; "olmayabilir" bilgisi dönüş türünün içine konur, derleyici de o kutuya bakmanı hatırlatır.

## 5 yaşındaki çocuğa anlatır gibi

Tarif kartını okuyorsun. "Un 2 bardak" yazan satır yoksa yemek yapamazsın; ya durursun ya da annene sorarsın. Annene sormak `?` gibidir: "bunu ben çözemediğim, sen devam et". Kart tamamen boşsa zorunlu anahtarlar eksik sayılır, biri mutlaka haber verir; tek bir boş satır sorun değildir.

## Konu anlatımı (madde madde)

1. **`panic!` kurtarılamaz hatadır.** O iş parçacığını sonlandırır. Varsayılan davranış *unwind*'tir: yığın geri sarılır, yoldaki değerlerin `Drop`'ları çalışır, sonra iş kolu biter. `panic = "abort"` profilinde anında çıkılır, `Drop` çalışmaz ve ikili küçülür.
   ↳ Kaynak: [Book ch09-01 — panic!](https://doc.rust-lang.org/book/ch09-01-unrecoverable-errors-with-panic.html) · [Book ch14-01 — Release Profiles](https://doc.rust-lang.org/book/ch14-01-release-profiles.html)

2. **`Result<T, E>` kurtarılabilir hatayı dönüş türüne kodlar.** `enum Result { Ok(T), Err(E) }`: ya sonuç ya nedeni gelir. Rust'ta exception (try/catch) yoktur; çağıran kutuyu açmadan içindeki değeri kullanamaz.
   ↳ Kaynak: [Book ch09-02 — Recoverable Errors with Result](https://doc.rust-lang.org/book/ch09-02-recoverable-errors-with-result.html) · [Rustdoc — Result](https://doc.rust-lang.org/std/result/enum.Result.html)

3. **`Result` tür olarak `#[must_use]` taşır.** Sonucu yok sayarsan "unused `Result` that must be used" uyarısı gelir; bilerek yok saymak için `let _ = ...;` yazılır. `Option` türü bu etiketi taşımaz, yalnız bazı metotları taşır.
   ↳ Kaynak: [Rustdoc — Result](https://doc.rust-lang.org/std/result/enum.Result.html) · [rustc 1.99.1 — late.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_lint/src/late.rs)

4. **`match` kutunun hangi hâlde olduğuna bakar.** `Ok(değer)` ve `Err(hata)` kolları ayrı yazılır. `unwrap()` / `expect()` kutuyu sormadan açar; içinde `Err` varsa panikler, `expect` mesaj verdirir. İkisi de "Err olamaz" dediklerin içindir.
   ↳ Kaynak: [Book ch09-02 — Matching on Result](https://doc.rust-lang.org/book/ch09-02-recoverable-errors-with-result.html#matching-on-result) · [Rustdoc — Result::unwrap](https://doc.rust-lang.org/std/result/enum.Result.html#method.unwrap)

5. **`?` "hata gelirse hemen yukarı gönder" der.** `Ok` ise içindeki değeri verir, `Err` ise fonksiyondan o `Err` ile erken döner. Yalnız `Result`, `Option` (veya `FromResidual` uygulayan bir tür) dönen fonksiyonda kullanılabilir; `fn main()` varsayılan olarak `()` döndüğünden içinde doğrudan `?` kullanmak **E0277** verir. Çözüm: `match` ile ele almak ya da `fn main() -> Result<(), E>` yazmaktır.
   ↳ Kaynak: [Book ch09-02 — The ? Operator](https://doc.rust-lang.org/book/ch09-02-recoverable-errors-with-result.html#the-operator-that-can-be-used-with-result) · [Rustdoc — FromResidual](https://doc.rust-lang.org/std/ops/trait.FromResidual.html)

6. **`?` `Option` üzerinde de çalışır.** `None` gelirse fonksiyondan hemen `None` döner. Ama `?` dönüş türünün ailesine bakar: `Result` dönen fonksiyonda `Option` ya da `Option` dönen fonksiyonda `Result` karışımı **E0277**'dir.
   ↳ Kaynak: [Rustdoc — Option](https://doc.rust-lang.org/std/option/enum.Option.html) · [Book ch09-02](https://doc.rust-lang.org/book/ch09-02-recoverable-errors-with-result.html)

7. **Farklı hata türleri tek bir türde toplanır.** Alt fonksiyonlar `ParseIntError`, IO hatası gibi çeşitli hatalar döndürür; kendi enum'un (`UygulamaHatasi::Ayristirma`, `UygulamaHatasi::Mantik`) hepsini taşır. `impl From<ParseIntError>` tanımlayınca `?` çeviriyi kendisi yapar, elle dönüştürme gerekmez.
   ↳ Kaynak: [Book ch09-02 — Using ? with Result](https://doc.rust-lang.org/book/ch09-02-recoverable-errors-with-result.html) · [Rustdoc — From](https://doc.rust-lang.org/std/convert/trait.From.html)

8. **`Display` kullanıcıya, `Debug` geliştiriciye yazılır.** `{}` tek satırlık okunaklı mesajı, `{:?}` bütün ayrıntıyı (hangi varyant, hangi alanlar) gösterir. Hata türü için ikisini de uygulamak yaygındır.
   ↳ Kaynak: [Rustdoc — std::fmt](https://doc.rust-lang.org/std/fmt/index.html) · [Book ch09-02](https://doc.rust-lang.org/book/ch09-02-recoverable-errors-with-result.html)

9. **Panik mi, `Result` mı? Karar ölçütü "devam edilebilir mi?"dir.** Bozulmuş bir değişmez (invariant) ya da imkânsız durum varsa durmak daha iyidir; kullanıcı girdisi, dosya, ağ gibi dış dünyadan gelen başarısızlıklar beklenen durumdur ve çağıranın karar vermesi için `Result` olarak döner.
   ↳ Kaynak: [Book ch09-03 — To panic or not to panic](https://doc.rust-lang.org/book/ch09-03-to-panic-or-not-to-panic.html)

## Kodda nasıl görünür?

```rust
use std::num::ParseIntError;

fn ikiye_bol(a: i32, b: i32) -> Result<i32, String> {
    if b == 0 {
        Err(String::from("sıfıra bölme"))
    } else {
        Ok(a / b)
    }
}

fn metni_sayiya(x: &str) -> Result<i32, ParseIntError> {
    let n: i32 = x.parse()?; // Err olursa buradan erken Err dönülür
    Ok(n * 2)
}

fn propagasyon() -> Result<i32, ParseIntError> {
    let a = metni_sayiya("21")?; // 42
    // let _b = metni_sayiya("xx")?; // açık olsaydı: Err → propagasyon da hemen Err dönerdi
    Ok(a)
}
```

## Sık yapılan hatalar

| Kod | Hata | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| `fn oku() { let n: i32 = "5".parse()?; }` | **E0277** | `?` yalnız `Result`/`Option`/`FromResidual` dönen fonksiyonda kullanılır; imzayı `Result` yap ya da sınırda `match` ile ele al. | [Book ch09-02](https://doc.rust-lang.org/book/ch09-02-recoverable-errors-with-result.html) |
| `fn main() { let n = metni_sayiya("21")?; }` | **E0277** | `main` varsayılan olarak `()` döner; `fn main() -> Result<(), E>` yaz ya da `match` kullan. | [Book ch09-02](https://doc.rust-lang.org/book/ch09-02-recoverable-errors-with-result.html) |
| `Result` dönen çağrıyı sonuçsuz bırakmak | uyarı: `unused Result` | `Result` `#[must_use]`'tır; bilerek yok sayacaksan `let _ = ...;`. | [rustc 1.99.1 — late.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_lint/src/late.rs) |
| `fn f() -> Option<i32> { let n: i32 = s.parse()?; .. }` | **E0277** | `?` dönüş türünün ailesine bakar; burada `.ok()?` gerekir. | [Rustdoc — Option](https://doc.rust-lang.org/std/option/enum.Option.html) |
| `ikiye_bol(10, 0).unwrap()` | panik | `Err` içindeyken `unwrap` panikler; hata ele alınacaksa `match` veya `?` kullan. | [Rustdoc — Result::unwrap](https://doc.rust-lang.org/std/result/enum.Result.html#method.unwrap) |

## Derleyici perspektifi

- `Result<T, E>` ve `Option<T>` sıradan enum'lardır; özel bir çalışma-anı mekanizması yoktur. "Hata olabilir" bilgisi dönüş türüne kodlandığı için çağıran `Err`'i ele almak zorundadır.
  ↳ Kaynak: [Book ch09-00 — Error Handling](https://doc.rust-lang.org/book/ch09-00-error-handling.html) · [Rustdoc — Result](https://doc.rust-lang.org/std/result/enum.Result.html)

- `#[must_use]` tür olarak yalnız `Result`'tadır; `Option` türü değildir. Denetim derleme sırasında lint aşamasında yapılır; `Option`'ın yalnız bazı metotları tek tek bu özniteliği taşır.
  ↳ Kaynak: [rustc 1.99.1 — late.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_lint/src/late.rs) · [Rustdoc — Result](https://doc.rust-lang.org/std/result/enum.Result.html)

- `?` operatörünün indirgenmesi (lowering) AST → HIR aşamasında kabaca şuna açılır: `match Try::branch(<expr>) { Continue(v) => v, Break(residual) => return FromResidual::from_residual(residual) }`. `Result` için `Break` yolu hatayı `From` ile dönüştürür; bu yüzden `From<ParseIntError>` tanımı `?` tarafından kullanılır ve dönüş türü `FromResidual` uygulamıyorsa **E0277** çıkar.
  ↳ Kaynak: [Rustdoc — Try](https://doc.rust-lang.org/std/ops/trait.Try.html) · [Rustdoc — FromResidual](https://doc.rust-lang.org/std/ops/trait.FromResidual.html)

- Panik davranışı derleme profilinde seçilir: `unwind` yığını geri sarıp `Drop`'ları çalıştırır, `abort` hemen sonlandırır ve `Drop` çalışmaz. `RUST_BACKTRACE=1` çağrı yığınını basar.
  ↳ Kaynak: [Book ch09-01 — panic!](https://doc.rust-lang.org/book/ch09-01-unrecoverable-errors-with-panic.html) · [Book ch14-01 — Release Profiles](https://doc.rust-lang.org/book/ch14-01-release-profiles.html)

## Özet ve sonraki adım

- Kurtarılamaz hata `panic!` (unwind/abort), kurtarılabilir hata `Result<T, E>` ile taşınır; try/catch yoktur.
- `?` hatayı yukarı iletir; `From` dönüşümüyle tek hata türünde toplama yapılır; `Result` `#[must_use]`'tır.
- `Display` kullanıcıya, `Debug` geliştiriciye; panik ve `Result` arasındaki karar "devam edilebilir mi?" sorusuna dayanır.

Sıradaki bölüm: [8.1 Hata Yönetimi: Derinleşme](08-error-handling-derinlesme.md) — özel hata enum'u, `source()` zinciri, `Option`↔`Result` köprüleri ve `Box<dyn Error>` kararını göreceğiz.
