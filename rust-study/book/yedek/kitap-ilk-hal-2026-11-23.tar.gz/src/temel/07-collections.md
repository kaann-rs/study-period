# 7. Koleksiyonlar

> Kaynak crate: `learn/collections` · Çalıştır: `cargo run -p collections`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

## Neden bu bölüm?

Dizilerin uzunluğu baştan belliydi; ya kaç eleman geleceğini bilmiyorsan? Birden çok değeri bir arada tutmanın üç yaygın yolu vardır: uzayıp giden sıralı liste (Vec), yazı (String) ve "etiket → değer" eşlemesi (HashMap). Bunlar standart kütüphane türleridir, derleyici sihiri değildir; ama Vec'in güvenliği gibi kurallar yine borrow checker tarafından zorlanır.

## 5 yaşındaki çocuğa anlatır gibi

Oyuncak treninin vagonlarını uzatıp kısaltabilirsin. Yazı boncuk kolye gibidir; boncuğun ortasından kesince kolyeyi bozarsın. Çekmecelere isim yapıştırırsın: "çorap" yazana çorap koyarsın, sonra aynı isimle bulursun.

## Konu anlatımı (madde madde)

1. **Üç kap: Vec, String, HashMap.** Koleksiyon, birden çok değeri bir arada tutan türdür. Vec sıralı liste, String büyüyebilen yazı, HashMap ise anahtardan değere giden eşlemedir; hepsi sahipli ve heap'te yaşar.
   ↳ Kaynak: [Book ch08-01 — Vectors](https://doc.rust-lang.org/book/ch08-01-vectors.html) · [Book ch08-02 — Strings](https://doc.rust-lang.org/book/ch08-02-strings.html) · [Book ch08-03 — Hash Maps](https://doc.rust-lang.org/book/ch08-03-hash-maps.html)

2. **`Vec<T>` büyüyebilen, aynı türden eleman sırasıdır.** `Vec::new()` boş tren kurar, `push(10)` sona vagon ekler, `vec![1, 2, 3]` makrosu hazır tren verir. Kaç eleman olacağını çoğu zaman önceden bilemeyiz; sabit uzunluklu dizi bu yüzden yetmez.
   ↳ Kaynak: [Book ch08-01 — Vectors](https://doc.rust-lang.org/book/ch08-01-vectors.html) · [Rustdoc — Vec](https://doc.rust-lang.org/std/vec/struct.Vec.html)

3. **İki erişim biçimi: indeks panikler, `get` güvenlidir.** `v[0]` sıra numarasıyla bakar; sınır dışına çıkarsa program durur (panik). `v.get(99)` ise `Option` verir: eleman varsa `Some(x)`, yoksa `None` — program sürer.
   ↳ Kaynak: [Book ch08-01 — Vectors](https://doc.rust-lang.org/book/ch08-01-vectors.html) · [Rustdoc — Vec::get](https://doc.rust-lang.org/std/vec/struct.Vec.html#method.get)

4. **Gezinme: `&v` bakar, `&mut v` değiştirir.** `for x in &v { toplam += x; }` paylaşımlı ödünçle her vagona bakar; `for x in &mut v { *x += 1; }` ise `*x` ile dereference edip içini yazar. İkisi aynı anda olamaz.
   ↳ Kaynak: [Book ch08-01 — Vectors](https://doc.rust-lang.org/book/ch08-01-vectors.html) · [Book ch04-02 — The Rules of References](https://doc.rust-lang.org/book/ch04-02-references-and-borrowing.html)

5. **Vec tek türe izin verir; karışık değerler enum kutusuna konur.** `vec![3, "top"]` derlenmez. `enum Hucre { Sayi(i32), Metin(String), Bos }` tanımlayıp `vec![Hucre::Sayi(3), Hucre::Metin(String::from("merhaba")), Hucre::Bos]` yazarsan hepsi aynı türdür (Hucre). Payload'ları `match` ile gerçekten okumak gerekir; yoksa `derive(Debug)` dead_code analizinde sayılmadığı için "field never read" uyarısı çıkar.
   ↳ Kaynak: [Book ch08-01 — Vectors](https://doc.rust-lang.org/book/ch08-01-vectors.html) · [Book ch06-01 — Defining an Enum](https://doc.rust-lang.org/book/ch06-01-defining-an-enum.html)

6. **Bir elemana `&` borç tutarken `push` yasaktır (E0502).** `let ilk = &v[0]; v.push(40);` derlenmez. Vec = (pointer, len, cap); kapasite dolunca `push` heap'i yeniden tahsis eder, eski blok serbest bırakılır ve `ilk` boşu gösterirdi. Borrow checker bunu derleme anında yasaklar; böylece iterator invalidation kaynakta önlenir.
   ↳ Kaynak: [Book ch08-01 — Vectors](https://doc.rust-lang.org/book/ch08-01-vectors.html) · [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs)

7. **String büyüyebilen sahipli UTF-8 metin, `&str` ödünç dilimdir.** `s.push_str("haba")` yazı ekler, `s.push('!')` tek char ekler. `+` soldaki String'i TÜKETİR ve sağda `&str` ister (bu yüzden `s.clone()` kullanıldı); `format!` ise hiçbir şeyi tüketmez, yepyeni String üretir — tercih edilen birleştirme budur.
   ↳ Kaynak: [Book ch08-02 — Strings](https://doc.rust-lang.org/book/ch08-02-strings.html) · [Rustdoc — String](https://doc.rust-lang.org/std/string/struct.String.html)

8. **String'de integer index yoktur (E0277).** `t[0]` yazılamaz; `str` tipi `{integer}` ile indekslenemez. char'lar 1–4 byte tutar: `"şema"` 5 byte ama 4 karakterdir. "İlk byte mı, ilk harf mi?" belirsizdir ve n. karaktere O(1) erişim mümkün değildir. Rust maliyeti gizlemek yerine integer index'i hiç sunmaz; `t.chars()` kullanılır.
   ↳ Kaynak: [Book ch08-02 — Strings](https://doc.rust-lang.org/book/ch08-02-strings.html) · [Rustdoc — str](https://doc.rust-lang.org/std/primitive.str.html)

9. **Byte aralığı dilimi alınabilir ama char sınırına denk gelmelidir.** `'ş'` byte 0..2 arasını kapladığı için `&t[0..1]` çalışma anında panik verir: "byte index 1 is not a char boundary". Karakter bazlı işlem için `t.chars().take(1).collect()` kullanılır; ham byte'lar için `.bytes()` vardır.
   ↳ Kaynak: [Book ch08-02 — Strings](https://doc.rust-lang.org/book/ch08-02-strings.html) · [Rustdoc — str](https://doc.rust-lang.org/std/primitive.str.html)

10. **`HashMap<K, V>` etiketten değere gider; non-Copy anahtar taşınır.** `puan.insert(String::from("mavi"), 10)` anahtarın sahibi HashMap olur; aynı `k`'yı insert ettikten sonra kullanmak **E0382** verir. `get("mavi")` → `Option<&V>` döndürür. Vec'te baştan sona bakarsın; etiketli çekmecede doğrudan gidersin.
    ↳ Kaynak: [Book ch08-03 — Hash Maps](https://doc.rust-lang.org/book/ch08-03-hash-maps.html) · [Book ch04-01 — What is Ownership?](https://doc.rust-lang.org/book/ch04-01-what-is-ownership.html)

11. **`entry().or_insert()` deyimsel güncellemedir; gezinme sırası garantili değildir.** `*puan.entry(kelime).or_insert(0) += 1;` "varsa artır, yoksa 0 ile aç" der; kelime saymanın klasik yoludur. Varsayılan hash'leyici SipHash ve her HashMap'in rastgele tohumu (seed) nedeniyle sıra her çalıştırmada değişebilir (HashDoS engeli). Sıra gerekiyorsa `BTreeMap` ya da çıktı öncesi `sort` kullanılır.
    ↳ Kaynak: [Book ch08-03 — Hash Maps](https://doc.rust-lang.org/book/ch08-03-hash-maps.html) · [Rustdoc — HashMap](https://doc.rust-lang.org/std/collections/struct.HashMap.html)

## Kodda nasıl görünür?

Aşağıdaki parçalar `learn/collections/src/main.rs` dosyasından alınmıştır.

```rust
use std::collections::HashMap;

fn vektorler() {
    let mut v: Vec<i32> = Vec::new();
    v.push(10);
    v.push(20);
    let v2 = vec![1, 2, 3];

    println!("v[0] = {}", v[0]);
    println!("{:?}", v.get(99)); // None → program durmaz

    let mut toplam = 0;
    for x in &v {
        toplam += x; // paylaşımlı ödünç
    }
    for x in &mut v {
        *x += 1; // dereference edip yaz
    }
    println!("{v:?} {v2:?}");
}

fn stringler() {
    let mut s = String::from("mer");
    s.push_str("haba");
    let t = "şema";
    println!("'{t}': bytes={} chars={}", t.len(), t.chars().count()); // 5, 4
    let ilk_char: String = t.chars().take(1).collect();
    println!("ilk karakter: {ilk_char}");
}

fn hashmapler() {
    let mut puan: HashMap<String, i32> = HashMap::new();
    puan.insert(String::from("mavi"), 10);
    println!("{:?}", puan.get("mavi"));
    *puan.entry(String::from("mavi")).or_insert(0) += 1;
}
```

## Sık yapılan hatalar

| Kod / durum | Sonuç | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| `let ilk = &v[0]; v.push(40);` | **E0502** | `push` `&mut` ister; realloc eski bloğu serbest bırakır. Önce `ilk`'i kullan, sonra push. | [Book ch08-01](https://doc.rust-lang.org/book/ch08-01-vectors.html) · [rustc borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs) |
| `let c = t[0];` | **E0277** | `str` integer ile indekslenemez; `t.chars()` kullan. | [Book ch08-02](https://doc.rust-lang.org/book/ch08-02-strings.html) · [Rustdoc — str](https://doc.rust-lang.org/std/primitive.str.html) |
| `&t[0..1]` (`t = "şema"`) | Çalışma anı panik | "byte index 1 is not a char boundary"; `'ş'` 0..2 arası. Karakter bazlı işlem yap. | [Book ch08-02](https://doc.rust-lang.org/book/ch08-02-strings.html) · [Rustdoc — str](https://doc.rust-lang.org/std/primitive.str.html) |
| `puan.insert(k, 5); println!("{k}");` | **E0382** | Non-Copy anahtar insert'te taşınır; HashMap artık sahibi. | [Book ch08-03](https://doc.rust-lang.org/book/ch08-03-hash-maps.html) · [Book ch04-01](https://doc.rust-lang.org/book/ch04-01-what-is-ownership.html) |
| `let karisik = vec![3, "top"];` | Derlenmez | Vec hepsi aynı türden olmalı; farklı türler için enum kutusu kullan. | [Book ch08-01](https://doc.rust-lang.org/book/ch08-01-vectors.html) |
| HashMap üzerinde sıralı çıktı beklemek | Sıra garantili değil | SipHash + rastgele seed; sıra için `sort` ya da `BTreeMap`. | [Rustdoc — HashMap](https://doc.rust-lang.org/std/collections/struct.HashMap.html) |

## Derleyici perspektifi

- **Vec** bellekte üç alandır: heap'e pointer, `len` (eleman sayısı), `cap` (ayrılmış yer). `push`, cap dolunca daha büyük blok ayırır, elemanları bit düzeyinde taşır (pedagojik olarak "kopyalar"; Copy trait'iyle ilgisi yoktur), eskiyi serbest bırakır — amortize O(1). Bu yeniden tahsis yüzünden `&` borç tutarken `push` yasaktır; güvenlik kütüphanede değil, dilin ödünç kurallarında ve borrow checker'da (**E0502**) durur.
  ↳ Kaynak: [Book ch08-01](https://doc.rust-lang.org/book/ch08-01-vectors.html) · [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs)

- **String**, içinde geçerli UTF-8 olduğu garanti edilen bir `Vec<u8>`'dir. `Index<usize>` impl EDİLMEMİŞTİR; bu yüzden `s[0]` bir tür hatasıdır (**E0277**), çalışma anı kontrolü değil. Byte aralığı dilimi alınabilir ama sınır bir char ortasına düşerse çalışma anında panik olur. Üç bakış: `.bytes()` (ham byte), `.chars()` (Unicode scalar), grapheme (harici crate).
  ↳ Kaynak: [Book ch08-02](https://doc.rust-lang.org/book/ch08-02-strings.html) · [Rustdoc — str](https://doc.rust-lang.org/std/primitive.str.html)

- **`HashMap<K, V>`** anahtar ve değerlerin SAHİBİdir; non-Copy anahtarlar `insert`'te taşınır (**E0382**). Gezinme sırası bilinçli olarak belirsizdir: varsayılan hash'leyici SipHash'tir ve her HashMap rastgele bir tohumla başlar; bu, kötü niyetli girdilerin kasıtlı çakışma üretip performansı düşürmesini (HashDoS) engeller.
  ↳ Kaynak: [Book ch08-03](https://doc.rust-lang.org/book/ch08-03-hash-maps.html) · [Rustdoc — HashMap](https://doc.rust-lang.org/std/collections/struct.HashMap.html)

## Özet ve sonraki adım

- Vec uzayabilen sıralı liste, String UTF-8 yazı, HashMap "etiket → değer" eşlemesidir; üçü de sahipli koleksiyonlardır.
- `v[0]` panikler, `get` Option verir; `t[0]` yoktur (E0277), char sınırı dışındaki dilim panikler; `push` ile `&` borç aynı anda olamaz (E0502).
- `entry().or_insert()` deyimsel güncellemedir; HashMap sırası belirsizdir, deterministik çıktı için sırala.

Sıradaki bölüm: [8. Hata Yönetimi](08-error-handling.md).
