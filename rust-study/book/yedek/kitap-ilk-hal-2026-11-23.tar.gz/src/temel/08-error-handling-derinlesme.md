# 8.1 Hata Yönetimi: Derinleşme

> Kaynak dosya: `learn/error-handling/src/derinlesme.rs` · Test: `cargo test -p error-handling`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

Önceki sayfada `Result`, `?` ve tek bir `From` dönüşümünü ayrı ayrı gördük. Burada hepsini küçük ama gerçekçi bir işte birleştiriyoruz: bir ayar dosyasını oku → satır satır ayrıştır → değerleri doğrula. İyi bir hata "olmadı" demekle kalmaz; **ne** olmadığını, **nerede** olmadığını ve **neden** olmadığını da söyler.

## Neden bu sayfa?

`Result<i32, String>` gerçek kodda yetmez: `String`'in içine bakmadan "dosya mı yok, biçim mi bozuk?" ayırt edilemez. Ayrıca her katmanın bildiği bilgi farklıdır; alt katman "sayıya çevrilemedi" der, üst katman "hangi satır, hangi anahtar" diye ekler. Bu sayfa o iki ihtiyacın — türle ayırt etme ve bağlam ekleme — nasıl karşılandığını gösterir.

## 1. Kendi hata türün: enum + Display + Error + From

Tarif kartından kek yapacaktın ve olmadı. "Olmadı" demek yetmez; kart mı kayıp, bir satır mı okunmuyor, "3 yumurta" yerine "üç tane işte" mi yazıyor, yoksa şeker satırı hiç mi yok? Dört ayrı sorun, dört ayrı çözüm. Rust'ta her sorun için enum'a ayrı bir varyant yazarsın; çağıran `match` ile hangisi olduğuna bakar.

```rust
#[derive(Debug)]
pub enum AyarHatasi {
    Gc(io::Error),                  // alt katmanın hatasını sarar
    Bicim { satir: usize, icerik: String },
    Sayi { anahtar: &'static str, deger: String, kaynak: ParseIntError },
    Eksik(&'static str),
}

impl Error for AyarHatasi {
    fn source(&self) -> Option<&(dyn Error + 'static)> {
        match self {
            AyarHatasi::Gc(e) => Some(e),
            AyarHatasi::Sayi { kaynak, .. } => Some(kaynak),
            AyarHatasi::Bicim { .. } | AyarHatasi::Eksik(_) => None,
        }
    }
}
```

1. `String` hata ile çağıran tahmin yürütür; bir harf değişince tahmin bozulur. Enum her biçimi ayrı varyant yapar; yeni varyant eklenince derleyici eksik `match` kolunu hatırlatır.
   ↳ Kaynak: [Book ch06-01 — Defining an Enum](https://doc.rust-lang.org/book/ch06-01-defining-an-enum.html) · [Book ch06-02 — match](https://doc.rust-lang.org/book/ch06-02-match.html)

2. `Display` son kullanıcıya tek satırlık mesajı, `Debug` (`{:?}`) geliştiriciye bütün ayrıntıyı verir. İşletim sisteminin mesajı platforma göre değiştiği için `Gc` kolunda tam mesaj değil `e.kind()` basılır; tam mesaj `source()` üzerinden erişilebilir.
   ↳ Kaynak: [Rustdoc — Display](https://doc.rust-lang.org/std/fmt/trait.Display.html) · [Rustdoc — Debug](https://doc.rust-lang.org/std/fmt/trait.Debug.html)

3. `Error` trait'i `Debug + Display` ister. `source()` "bu hataya yol açan alttaki hata hangisi?" sorusunu yanıtlar ve hataları bağlı liste gibi zincirler; kural şudur: `source()` ile verdiğin hatayı `Display`'de tekrar yazma, yoksa raporlayıcı aynı mesajı iki kez basar. `Eksik` varyantının altında başka hata yoktur, o yüzden `None` döner.
   ↳ Kaynak: [Rustdoc — Error::source](https://doc.rust-lang.org/std/error/trait.Error.html#method.source)

4. `impl From<io::Error> for AyarHatasi` tanımlayınca `?` dosya hatasını otomatik `Gc`'ye çevirir. `From`'un sınırı şudur: yalnız hatanın kendisini görür, "hangi satır, hangi anahtar" bilgisini ekleyemez; bağlam gereken yerde `map_err` kullanılır.
   ↳ Kaynak: [Rustdoc — From](https://doc.rust-lang.org/std/convert/trait.From.html) · [Rustdoc — Result::map_err](https://doc.rust-lang.org/std/result/enum.Result.html#method.map_err)

5. `zinciri_yaz` yardımcısı `std::iter::successors` ile "neden?" sorusunu kök nedene kadar sorar ve cevapları `" <- "` ile birleştirir: `` `port` sayı olmalı, bulunan "seksen" <- invalid digit found in string ``.
   ↳ Kaynak: [Rustdoc — std::iter::successors](https://doc.rust-lang.org/std/iter/fn.successors.html)

## 2. Option ↔ Result köprüleri

Boş raf sana yalnız "yok" der (`Option: None`); kek yapacaksan bu bir sorundur ve adını koyman gerekir (`Result: Err`). Tersi de olur: nedeni önemsemiyorsan notu atar, yalnız "var mı, yok mu" bilgisini tutarsın. Yokluk bazen hata değildir — tek bir boş satır sorun değildir.

```rust
fn satir_ayristir(no: usize, satir: &str) -> Result<Option<(String, String)>, AyarHatasi> {
    let satir = satir.trim();
    if satir.is_empty() || satir.starts_with('#') {
        return Ok(None);              // boş/yorum satırı: hata DEĞİL
    }
    let (anahtar, deger) = satir.split_once('=').ok_or_else(|| AyarHatasi::Bicim {
        satir: no,
        icerik: satir.to_string(),
    })?;
    Ok(Some((anahtar.trim().to_string(), deger.trim().to_string())))
}

fn tabloya_ayristir(metin: &str) -> Result<BTreeMap<String, String>, AyarHatasi> {
    metin
        .lines()
        .enumerate()
        .filter_map(|(i, satir)| satir_ayristir(i + 1, satir).transpose())
        .collect()
}
```

1. `ok_or(hata)` / `ok_or_else(|| hata)` `Option`'ı `Result`'a çevirir: `None` ise verdiğin hata konur. `ok_or_else` closure'ı yalnız `None` olursa çalıştırır; `ok_or` olsaydı `to_string` tahsisi başarılı her satırda boşuna yapılırdı.
   ↳ Kaynak: [Rustdoc — Option::ok_or_else](https://doc.rust-lang.org/std/option/enum.Option.html#method.ok_or_else) · [Rustdoc — Option::ok_or](https://doc.rust-lang.org/std/option/enum.Option.html#method.ok_or)

2. `.ok()` ters yöndeki köprüdür: `Result`'ı `Option`'a çevirir, hata varsa nedeni bilerek atar. `transpose` ise `Result<Option<T>, E>` → `Option<Result<T, E>>` sırasını değiştirir; böylece `filter_map` `Ok(None)`'ları (boş satırları) atar ama `Err`'leri kaybetmez.
   ↳ Kaynak: [Rustdoc — Result::ok](https://doc.rust-lang.org/std/result/enum.Result.html#method.ok) · [Rustdoc — Result::transpose](https://doc.rust-lang.org/std/result/enum.Result.html#method.transpose)

3. `sayi_al<T>` fonksiyonu iki köprüyü birlikte kullanır: `tablo.get(anahtar).ok_or(AyarHatasi::Eksik(anahtar))?` yokluğu hataya çevirir, `ham.parse().map_err(|kaynak| AyarHatasi::Sayi { anahtar, deger: ham.clone(), kaynak })` ise alttaki `ParseIntError`'ı saklayıp üstüne bağlam ekler. `T: FromStr<Err = ParseIntError>` şartı sayesinde aynı fonksiyon hem `u16` hem `u32` okur.
   ↳ Kaynak: [Rustdoc — FromStr](https://doc.rust-lang.org/std/str/trait.FromStr.html) · [Rustdoc — Result::map_err](https://doc.rust-lang.org/std/result/enum.Result.html#method.map_err)

## 3. İlk hatada dur mu, hepsini topla mı?

Derleyici ilk hatada durmaz, bulabildiği kadarını listeler; kullanıcı düzelt-çalıştır döngüsünü her hata için tekrarlamak istemez. Ayar dosyası doğrulayıcı da böyle olmalı. Bir ödeme işleminde ise ilk hatada durmak (yarım iş yapmamak) doğrudur. `?` ve `collect` ilk hatada durur; hepsini görmek istersen hataları bir `Vec`'te biriktirirsin.

1. `collect`, `Result` akışını `Result<Koleksiyon, E>`'ye toplar ve ilk `Err`'de akışı keser. Örnekte "port = 1 / bozuk satır / ad = x / bir bozuk daha" metni için 2. satırda durur.
   ↳ Kaynak: [Rustdoc — Iterator::collect](https://doc.rust-lang.org/std/iter/trait.Iterator.html#method.collect) · [Rustdoc — FromIterator for Result](https://doc.rust-lang.org/std/result/enum.Result.html#impl-FromIterator%3CResult%3CT%2C%20E%3E%3E-for-Result%3CV%2C%20E%3E)

2. `hatalari_topla` döngüsü `match` ile `Ok(Some)`, `Ok(None)` ve `Err` kollarını ayırır; `Err` gelince durmaz, kaydedip devam eder. Sonuç `(gecerli_sayisi, Vec<AyarHatasi>)` olur: aynı metin için 2 geçerli satır, 2 hata.
   ↳ Kaynak: [Book ch06-02 — match](https://doc.rust-lang.org/book/ch06-02-match.html) · [Rustdoc — Vec::push](https://doc.rust-lang.org/std/vec/struct.Vec.html#method.push)

## 4. Gerçek dosya senaryosu

İş iki adımdır: önce kartı çekmeceden çıkar (dosyayı oku), sonra satırlarını anla (ayrıştır). Çekmece boşsa ikinci adıma hiç geçilmez. `dosyadan_yukle` bu iki adımı art arda yapar; hangisi bozulursa bozulsun dışarıya aynı türden hata çıkar.

```rust
pub fn dosyadan_yukle(yol: &Path) -> Result<Ayarlar, AyarHatasi> {
    let metin = fs::read_to_string(yol)?;   // io::Error → From → Gc
    ayarlari_coz(&metin)
}
```

1. Üst katmanda `io::Error`, `?` + `From` ile `AyarHatasi::Gc`'ye dönüşür; ayrıştırma hataları zaten bizim türümüzdür. En dış katman varyanta bakıp karar verir: `Err(AyarHatasi::Gc(e)) if e.kind() == io::ErrorKind::NotFound` ise "varsayılan ayarlarla devam" denir — düz yazı hata ile bu mümkün olmazdı.
   ↳ Kaynak: [Rustdoc — fs::read_to_string](https://doc.rust-lang.org/std/fs/fn.read_to_string.html) · [Rustdoc — io::ErrorKind](https://doc.rust-lang.org/std/io/enum.ErrorKind.html)

2. `gecici_dosya_ile` yardımcısı dosyayı yazar, verilen işi çalıştırır, sonra siler. `Err` sıradan bir değerdir; akışı kesmez, bu yüzden `is(&yol)` başarısız olsa bile `fs::remove_file` satırına gelinir. Panik öyle değildir: sonraki satırlar atlanır, o garanti için `Drop`'lu bir koruyucu (RAII guard) gerekir.
   ↳ Kaynak: [Book ch09-01 — panic!](https://doc.rust-lang.org/book/ch09-01-unrecoverable-errors-with-panic.html) · [Book ch15-00 — Smart Pointers](https://doc.rust-lang.org/book/ch15-00-smart-pointers.html)

## 5. `Box<dyn Error>` ne zaman, özel enum ne zaman?

Mutfakta iki çeşit kap vardır: üstünde "un", "şeker" yazan etiketli kavanozlar ve içine her şey atılabilen "karışık" kutu. Özel hata enum'u etiketli kavanozdur; `Box<dyn Error>` karışık kutudur. `Box<dyn Error>`, `Error` sözünü veren her türü kabul eden bir **trait object**'tir (Rust Book Böl. 18 — [Book ch18-02 — Trait Objects](https://doc.rust-lang.org/book/ch18-02-trait-objects.html)); tür silinir, çağıran `match` yapamaz, ancak `downcast_ref` ile "içindeki şu tür müydü?" diye sorabilir.

1. Kütüphane (başkası çağıracak, hataya göre davranacak) → özel enum: sözleşme imzadadır. Uygulama / `main` / betik / prototip (hata yalnız raporlanacak) → `Box<dyn Error>` yeter. Yaygın kalıp ikisinin birleşimidir: iç katmanlar enum, en dıştaki `fn main() -> Result<(), Box<dyn Error>>`.
   ↳ Kaynak: [Book ch18-02 — Trait Objects](https://doc.rust-lang.org/book/ch18-02-trait-objects.html) · [Rustdoc — Error](https://doc.rust-lang.org/std/error/trait.Error.html)

2. `hizli_toplam` örneğinde `parse::<u32>()?` gelen `ParseIntError` kutuya girer, `"toplam sıfır olamaz".into()` da `&str`'dan kutuya çevrilir. Çağıran `e.downcast_ref::<ParseIntError>()` ile türü sorabilir; bedel bir heap tahsisidir.
   ↳ Kaynak: [Rustdoc — Box](https://doc.rust-lang.org/std/boxed/struct.Box.html) · [Rustdoc — Error::downcast_ref](https://doc.rust-lang.org/std/error/trait.Error.html#method.downcast_ref)

## 6. unwrap / expect ne zaman meşru?

Ölçüt tek soru: "Bu başarısızlığın sorumlusu kim?" Dış dünya (kullanıcı girdisi, dosya, ağ) → beklenen durum → `Result`, çağıran karar versin. Programcı (bozulmuş invariant, "buraya asla gelinmez") → hata bir bug → panik; sessizce devam etmek bozuk veriyle çalışmak demektir.

1. Meşru yerler: (a) testler ve örnek kod, (b) prototip (sonra `?`'e çevrilir), (c) derleyicinin göremediği ama senin kanıtlayabildiğin durumlar — `expect` mesajına o kanıtı yaz. Örnekte `"127.0.0.1".parse().expect("sabit literal geçerli bir IPv4")` ve boş olamayacak dizide `max().expect("dizi boş değil")` böyledir.
   ↳ Kaynak: [Book ch09-03 — To panic or not to panic](https://doc.rust-lang.org/book/ch09-03-to-panic-or-not-to-panic.html) · [Rustdoc — Result::expect](https://doc.rust-lang.org/std/result/enum.Result.html#method.expect)

## Sık yapılan hatalar

| Yanlış kullanım | Hata | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| `fn oku() { let n: i32 = "5".parse()?; }` | **E0277** | `?` Result/Option dönen fonksiyon ister; imzayı `Result` yap ya da sınırda `match` ile ele al. | [Book ch09-02](https://doc.rust-lang.org/book/ch09-02-recoverable-errors-with-result.html) |
| `fn f(s: &str) -> Result<i32, AyarHatasi> { let n = s.parse::<i32>()?; .. }` | **E0277** | `AyarHatasi` için `From<ParseIntError>` yok; bağlam gerekmiyorsa `From` ekle, gerekiyorsa `map_err`. | [Rustdoc — From](https://doc.rust-lang.org/std/convert/trait.From.html) |
| `fn f(s: &str) -> Option<i32> { let n: i32 = s.parse()?; .. }` | **E0277** | `?` dönüş türünün ailesine bakar; burada `.ok()?` gerekir. | [Rustdoc — Option](https://doc.rust-lang.org/std/option/enum.Option.html) |
| `fn g(v: &[i32]) -> Result<i32, String> { let n = v.first()?; .. }` | **E0277** | `Result` içinde `Option` kullanılamaz; `v.first().ok_or("liste boş")?` yaz. | [Rustdoc — Option::ok_or](https://doc.rust-lang.org/std/option/enum.Option.html#method.ok_or) |
| Yeni varyant ekleyip `Display`/`source()` kollarını unutmak | **E0004** | Exhaustiveness denetimi eksik kolları gösterir; bütün kolları tamamla. | [Book ch06-02 — match](https://doc.rust-lang.org/book/ch06-02-match.html) |

## Derleyici perspektifi

- `?` burada da aynı indirgemeyle çalışır: `Break` yolu `FromResidual::from_residual` ile döner. `Result` için bu, gelen hatayı ilan edilen tek türe `From` ile köprüler; `From` yoksa **E0277** çıkar.
  ↳ Kaynak: [Rustdoc — FromResidual](https://doc.rust-lang.org/std/ops/trait.FromResidual.html) · [Rustdoc — From](https://doc.rust-lang.org/std/convert/trait.From.html)

- `Option` ve `Result` ayrı residual aileleridir; `?` dönüş türünün ailesine bakar. Bu yüzden karışık kullanım tip denetiminde yakalanır, çalışma anına kalmaz.
  ↳ Kaynak: [Rustdoc — Try](https://doc.rust-lang.org/std/ops/trait.Try.html) · [Reference](https://doc.rust-lang.org/reference/)

- `Box<dyn Error>` dinamik dispatch kullanır: asıl tür vtable arkasında silinir, bedeli heap tahsisi ve bir pointer dolaylamasıdır. `downcast_ref` ile tür geri sorulabilir.
  ↳ Kaynak: [Book ch18-02 — Trait Objects](https://doc.rust-lang.org/book/ch18-02-trait-objects.html) · [Rustdoc — Error](https://doc.rust-lang.org/std/error/trait.Error.html)

- `Err` bir değerdir, akışı kesmez; panik ise sonraki satırları atlar ve yığını geri sararken `Drop`'ları çalıştırır. Temizlik garantisi isteniyorsa `Drop` uygulayan bir koruyucu (RAII) gerekir.
  ↳ Kaynak: [Book ch09-01 — panic!](https://doc.rust-lang.org/book/ch09-01-unrecoverable-errors-with-panic.html) · [Rustdoc — Drop](https://doc.rust-lang.org/std/ops/trait.Drop.html)

## Özet ve sonraki adım

- Hata türü bir API sözleşmesidir: enum → çağıran ayırt edebilir; `Box<dyn Error>` → yalnız raporlar (Rust Book Böl. 18'in trait object bölümü).
- `From` bağlamsız otomatik dönüşüm, `map_err` bağlam ekleyerek dönüşümdür; `source()` kök nedene götürür.
- Hata, en çok bilgiye sahip katmanda zenginleştirilir; karar verebilen katmanda ele alınır.

Alıştırmalar kaynak dosyadadır: `Aralik` varyantı eklemek, `sayi_al`'a satır numarası bağlamı koymak ve `hatalari_topla`'yı `partition` ile yeniden yazmak. Çözümler `cargo test -p error-handling` ile sınanabilir.

Sıradaki bölüm: [9. Generic, Trait ve Lifetime](../orta/09-generics-traits-lifetimes.md). Buradaki `sayi_al<T: FromStr<Err = ParseIntError>>` bir trait bound + associated type kısıtıdır; `Box<dyn Error>` ise dinamik dispatch'in hata hâlidir.
