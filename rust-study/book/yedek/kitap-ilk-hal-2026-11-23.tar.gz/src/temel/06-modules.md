# 6. Modüller

> Kaynak crate: `learn/modules` · Çalıştır: `cargo run -p modules`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

## Neden bu bölüm?

Kod büyüyünce her şeyi tek bir dosyaya yığmak işleri karıştırır; tıpkı evde mutfağı, yatak odasını ve oyun odasını ayırmak gibi. Rust'ta bu odalara modül denir ve her odanın kapısı kapalı gelir. Bu bölümde kapıyı kimin açacağını (`pub`), bir eşyaya nasıl adres verileceğini (path) ve uzun adresin nasıl kısaltılacağını (`use`) görüyoruz.

## 5 yaşındaki çocuğa anlatır gibi

Evde odalar var: mutfak, yatak odası, oyun odası. Her odanın kapısı kapalı; "girebilirsin" etiketi yapıştırdığın eşyayı alabilirsin. "Mutfak → bardak" demek, hangi odada ne arayacağını söylemektir.

## Konu anlatımı (madde madde)

1. **Package, crate ve crate root.** `Cargo.toml` içeren klasör bir package'dır; bir veya daha çok crate barındırır. Crate tek derleme birimidir (binary `main.rs` ya da library `lib.rs`); bu örnekte `main.rs` binary crate'in köküdür ve modül ağacı buradan başlar.
   ↳ Kaynak: [Book ch07-01 — Packages and Crates](https://doc.rust-lang.org/book/ch07-01-packages-and-crates.html) · [Reference](https://doc.rust-lang.org/reference/)

2. **Modül bir odadır; varsayılan her şey private.** `mod lokanta { pub mod salon { … } mod mutfak { … } }` içinde `mutfak`, lokantanın dışından görünmez. Private öğeler tanımlandığı modülden ve alt modüllerinden görülür.
   ↳ Kaynak: [Book ch07-02 — Defining Modules](https://doc.rust-lang.org/book/ch07-02-defining-modules-to-control-scope-and-privacy.html) · [Reference — Visibility and privacy](https://doc.rust-lang.org/reference/visibility-and-privacy.html)

3. **`pub` dışarıya açar, `pub(crate)` yalnız bu crate'e açar.** `pub mod salon` müşteriye açık salon demektir; `pub(crate) fn ic_rapor()` ise "lokantanın bütün çalışanlarına açık, müşteriye kapalı" gibidir — programın her yerinden çağrılır, onu kitaplık olarak kullanan başka kod göremez.
   ↳ Kaynak: [Book ch07-02 — Defining Modules](https://doc.rust-lang.org/book/ch07-02-defining-modules-to-control-scope-and-privacy.html) · [Reference — Visibility and privacy](https://doc.rust-lang.org/reference/visibility-and-privacy.html)

4. **Yol (path) bir adrestir: absolute ya da relative.** `crate::lokanta::ac();` kökten başlayan tam adrestir; `lokanta::ac();` bulunduğun yerden tariftir. `self::` "bu odadan", `super::` "bir üst odadan", `crate::` "kökten başla" demektir; hiçbiri yazılmazsa yol bulunduğun modülden başlar.
   ↳ Kaynak: [Book ch07-03 — Paths for Referring to an Item](https://doc.rust-lang.org/book/ch07-03-paths-for-referring-to-an-item-in-the-module-tree.html) · [Reference](https://doc.rust-lang.org/reference/)

5. **`super::` ile kardeş modüle erişilebilir.** `salon::masa_ayarla()` gövdesindeki `super::mutfak::hazirla();` bir üst oda olan `lokanta`'ya çıkıp oradan devam eder. `mutfak`'ın kendisi private olsa da içindeki `fn pub` olduğu için lokanta ve torunları onu çağırabilir.
   ↳ Kaynak: [Book ch07-03 — Paths for Referring to an Item](https://doc.rust-lang.org/book/ch07-03-paths-for-referring-to-an-item-in-the-module-tree.html) · [Reference — Visibility and privacy](https://doc.rust-lang.org/reference/visibility-and-privacy.html)

6. **Struct alanları tek tek açılır; bu encapsulation'dır.** `pub struct Fis { pub urun: String, tutar: u32 }` içinde `urun` herkese açık, `tutar` kapalıdır. Dışarıdan doğrudan kuramadığın için `Fis::yeni` yapıcısı, okumak için ise `tutar()` getter'ı sunulur; böylece tutarın herhangi bir yerden 0 yapılması engellenir.
   ↳ Kaynak: [Book ch05-01 — Defining Structs](https://doc.rust-lang.org/book/ch05-01-defining-structs.html) · [Book ch07-02 — Defining Modules](https://doc.rust-lang.org/book/ch07-02-defining-modules-to-control-scope-and-privacy.html)

7. **`use` uzun adresi kısa isme bağlar; kopya ya da taşıma değildir.** `use lokanta::salon;` ve `use lokanta::salon::masa_ayarla as hazirla_masa;` satırları yalnız yerel kısa isimler yaratır. Arkadaşının numarasını rehbere kaydetmek gibi: numara yerinde durur, `use` hiçbir şeyi çoğaltmaz.
   ↳ Kaynak: [Book ch07-04 — Bringing Paths into Scope with `use`](https://doc.rust-lang.org/book/ch07-04-bringing-paths-into-scope-with-the-use-keyword.html) · [Reference](https://doc.rust-lang.org/reference/)

8. **Re-export (`pub use`) derindeki öğeyi dış API yapar.** `pub use crate::derin::cok::ic::eylem;` sayesinde `cephe::eylem();` yazılabilir; tatlı deponun dibinden alınıp girişteki vitrine konmuştur. Yarın eşya başka rafa taşınsa yalnız vitrindeki satır değişir, onu kullanan kod değişmez.
   ↳ Kaynak: [Book ch07-04 — Bringing Paths into Scope with `use`](https://doc.rust-lang.org/book/ch07-04-bringing-paths-into-scope-with-the-use-keyword.html) · [Reference — Visibility and privacy](https://doc.rust-lang.org/reference/visibility-and-privacy.html)

9. **Modüller çalışma anı maliyeti taşımaz.** Onlar yalnız derleme zamanında isimleri düzenler ve API yüzeyini (neyin dışarı açık olduğunu) tanımlar. Çalışma anında "salon" diye bir nesne gezmez; bu bir kod düzenleme aracıdır.
   ↳ Kaynak: [Book ch07-02 — Defining Modules](https://doc.rust-lang.org/book/ch07-02-defining-modules-to-control-scope-and-privacy.html) · [Reference](https://doc.rust-lang.org/reference/)

10. **Gövdesiz `mod salon;` dosyaya bölünür.** Derleyici modülü `src/salon.rs` ya da `src/salon/mod.rs` dosyasından yükler; modül ağacı aynı kalır, yalnız kaynak birden çok dosyaya dağılır.
    ↳ Kaynak: [Book ch07-02 — Defining Modules](https://doc.rust-lang.org/book/ch07-02-defining-modules-to-control-scope-and-privacy.html) · [Reference](https://doc.rust-lang.org/reference/)

## Kodda nasıl görünür?

Aşağıdaki parçalar `learn/modules/src/main.rs` dosyasından alınmıştır.

```rust
mod lokanta {
    pub mod salon {
        pub fn masa_ayarla() {
            println!("salon: masa ayarlandı");
            super::mutfak::hazirla();
        }
    }

    mod mutfak {
        pub fn hazirla() {
            println!("mutfak: hazır");
        }
    }

    pub fn ac() {
        self::salon::masa_ayarla();
        mutfak::hazirla();
    }

    pub(crate) fn ic_rapor() {
        println!("lokanta: iç rapor (yalnız crate içi)");
    }
}

mod siparis {
    #[derive(Debug)]
    pub struct Fis {
        pub urun: String,
        tutar: u32,
    }

    impl Fis {
        pub fn yeni(urun: &str, tutar: u32) -> Fis {
            Fis {
                urun: urun.to_string(),
                tutar,
            }
        }

        pub fn tutar(&self) -> u32 {
            self.tutar
        }
    }

    pub fn demo() {
        let f = Fis::yeni("çay", 15);
        println!("fiş: {} = {}", f.urun, f.tutar());
    }
}

use lokanta::salon;
use lokanta::salon::masa_ayarla as hazirla_masa;

fn main() {
    crate::lokanta::ac();
    salon::masa_ayarla();
    hazirla_masa();
    lokanta::ic_rapor();
    siparis::demo();
}
```

## Sık yapılan hatalar

| Kod / durum | Sonuç | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| `lokanta::kasayi_say();` (`pub` yok) | **E0603** | Öğe dışarıya kapalı; `pub` ekle ya da aynı modülden çağır. | [Book ch07-02](https://doc.rust-lang.org/book/ch07-02-defining-modules-to-control-scope-and-privacy.html) · [Reference — Visibility](https://doc.rust-lang.org/reference/visibility-and-privacy.html) |
| `Fis { urun: ..., tutar: 15 }` dışarıdan | **E0451** | `tutar` private; `Fis::yeni` yapıcısını kullan. | [Book ch05-01](https://doc.rust-lang.org/book/ch05-01-defining-structs.html) · [Reference — Visibility](https://doc.rust-lang.org/reference/visibility-and-privacy.html) |
| `let _ = f.tutar;` dışarıdan | **E0616** | Modül bazlı gizlilik; alan okunamaz, getter `f.tutar()` kullan. | [Reference — Visibility](https://doc.rust-lang.org/reference/visibility-and-privacy.html) |
| `ac();` (kök modülde) | Derlenmez | Kökte `ac` diye bir şey yok; `lokanta::ac()` ya da `use` ile kısa ad gerekir. | [Book ch07-03](https://doc.rust-lang.org/book/ch07-03-paths-for-referring-to-an-item-in-the-module-tree.html) |
| `pub use` yerine `use` ile derin öğeyi sunmak | Dışarıdan görünmez | `use` yalnız bu modülde kısa isim yaratır; dışarı açmak için `pub use` gerekir. | [Book ch07-04](https://doc.rust-lang.org/book/ch07-04-bringing-paths-into-scope-with-the-use-keyword.html) |

## Derleyici perspektifi

- Modüller çalışma anı maliyeti taşımaz; yalnız derleme zamanında isimleri düzenler ve API yüzeyini tanımlar. Görünürlük, "güvenle değiştirilebilir iç detay" ile "dış sözleşme" arasındaki sınırı çizer.
  ↳ Kaynak: [Book ch07-02](https://doc.rust-lang.org/book/ch07-02-defining-modules-to-control-scope-and-privacy.html) · [Reference — Visibility and privacy](https://doc.rust-lang.org/reference/visibility-and-privacy.html)

- İsim çözümleme (name resolution) path'leri, `use`'ları ve isimleri tür denetiminden ÖNCE çözülür; kaynak crate `rustc_resolve`'dur. Rust'ta 5 namespace vardır: tür, değer, makro, lifetime ve label; bu örnekte çakışmayı önleyenler tür ve değer namespace'leridir (`struct S;` hem tür hem değer tanımlar, çakışmaz).
  ↳ Kaynak: [Reference](https://doc.rust-lang.org/reference/) · [Book ch07-03](https://doc.rust-lang.org/book/ch07-03-paths-for-referring-to-an-item-in-the-module-tree.html)

- Görünürlük denetimi ayrı bir geçişte (crate: `rustc_privacy`) zorlanır. Hataların yayın yeri farklıdır: **E0603** çoğunlukla `rustc_resolve`'da (tuple struct constructor için `rustc_hir_typeck`'te de), **E0616** typeck/lower'da, **E0451** `rustc_privacy`'de.
  ↳ Kaynak: [Reference — Visibility and privacy](https://doc.rust-lang.org/reference/visibility-and-privacy.html) · [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs)

- Neden varsayılan private? Her şey otomatik public olsaydı modülün tüm iç detayları dış API sayılır, birini değiştirmek uzaktaki kodları kırardı. Çözüm encapsulation: dışa açtığını `pub` ile bilinçli seçersin; `pub(crate)` / `pub(super)` ile açıklığı daha ince ayarlarsın.
  ↳ Kaynak: [Book ch07-02](https://doc.rust-lang.org/book/ch07-02-defining-modules-to-control-scope-and-privacy.html) · [Reference — Visibility and privacy](https://doc.rust-lang.org/reference/visibility-and-privacy.html)

## Özet ve sonraki adım

- Package bir veya daha çok crate içerir; `main.rs` crate root'tur ve modül ağacı orada başlar. Kapalı gelen her şeyi `pub` ile bilinçli açarsın.
- Yol bir adrestir: `crate::` tam adres, `self::` bu oda, `super::` bir üst oda; `use` kısa isim verir, `pub use` o kısa ismi dışarıya sunar.
- Modüller çalışma anı maliyeti eklemez; gizlilik derleme zamanında zorlanır (E0603, E0451, E0616).

Sıradaki bölüm: [7. Koleksiyonlar](07-collections.md).
