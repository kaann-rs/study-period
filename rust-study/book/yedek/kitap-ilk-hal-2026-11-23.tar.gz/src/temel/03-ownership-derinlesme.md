# 3.1 Ownership: Derinleşme

> Kaynak dosya: `learn/ownership/src/derinlesme.rs` · Test: `cargo test -p ownership`

Önceki sayfada kuralları öğrendik. Bu sayfada aynı kuralların gerçek kodda nasıl karşılık bulduğunu, özellikle de **fonksiyon imzalarının birer sahiplik sözleşmesi** olduğunu göreceğiz.

## Neden bu sayfa?

Bir fonksiyonun parametre türünü yazarken aslında şunu söylersin: "Bu veriyi alıyorum ve onunla şunu yapacağım." Çağıran kişi gövdeyi okumadan, yalnızca imzaya bakarak verisinin geri gelip gelmeyeceğini bilir. Bu, Rust'ın API tasarımını bu kadar öngörülebilir kılan şeydir.

## İmza bir sözleşmedir

| İmza | Anlamı | Benzetme |
| --- | --- | --- |
| `fn f(s: String)` | Sahipliği alır, geri vermez | Kitabı bağışla |
| `fn f(s: &String)` | Yalnızca okur | Kütüphanede oku |
| `fn f(s: &mut String)` | Geçici olarak değiştirir | Not defterine ödünç ver |

1. **İmza olmasaydı**, kitabın geri alınıp alınmayacağını görevlinin yaptıklarından çıkarmak gerekirdi; bu da her çağrıda belirsizlik yaratırdı.
   ↳ Kaynak: [Book ch04-02 — References and Borrowing](https://doc.rust-lang.org/book/ch04-02-references-and-borrowing.html) · [Book ch05-01 — Structs and Methods](https://doc.rust-lang.org/book/ch05-01-defining-structs.html)

## Kısmi move (partial move)

Move yalnız değişkenin tamamına değil, **alanlarına** da uygulanır. Bir struct'ın bir alanını taşırsan diğer alanlarını kullanmaya devam edebilirsin — ama struct'ın tamamını artık kullanamazsın.

```rust
struct Kisi { ad: String, yas: u8 }
let k = Kisi { ad: String::from("Ada"), yas: 36 };
let ad = k.ad;          // ad alanı taşındı
println!("{}", k.yas);  // ✓ diğer alan hâlâ geçerli
// println!("{:?}", k); // ✗ struct'ın tamamı artık geçerli değil
```

1. Kısmi move, taşınan alanın yerini "başlatılmamış" bırakır; bu yüzden `k` artık bir bütün olarak kullanılamaz. Derleyici hangi alanların taşındığını MIR veri akışıyla izler.
   ↳ Kaynak: [Book ch05-01 — Using Structs to Structure Related Data](https://doc.rust-lang.org/book/ch05-01-defining-structs.html) · [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs)

## Gerçek senaryo: kullanıcı deposu

Tasarım sorusu her zaman aynıdır: "Bu verinin **tek sahibi** kim olmalı?" Burada cevap depodur. Depo kullanıcıları tutar; `ekle` sahipliği devralır, `bul` yalnız ödünç verir.

1. Sahibi belli olmayan bir verinin kimin kaldıracağı da belli olmaz; ya ortada unutulur ya da iki kez silinmeye çalışılır. Tek sahip kuralı bu belirsizliği kökten çözer.
   ↳ Kaynak: [Book ch04-01 — What is Ownership?](https://doc.rust-lang.org/book/ch04-01-what-is-ownership.html) · [Reference — Ownership](https://doc.rust-lang.org/reference/ownership.html)

## Sık yapılan beş hata ve deyimsel çözümü

1. **Döngüde koleksiyonu tüketmek (`E0382`).** `for x in v` vektörü tüketir; sadece okuyacaksan `for x in &v` yaz.
   ↳ Kaynak: [Book ch04-04 — Slices / iterators](https://doc.rust-lang.org/book/ch04-03-slices.html) · [Rustdoc — IntoIterator](https://doc.rust-lang.org/std/iter/trait.IntoIterator.html)

2. **Üzerinde dolaşırken değiştirmek (`E0502`).** `push` yeniden tahsis ederse döngünün iterator'ı serbest bırakılmış belleği gösterir. Önce karar ver, sonra uygula; ya da `retain` kullan.
   ↳ Kaynak: [Rustdoc — Vec::retain](https://doc.rust-lang.org/std/vec/struct.Vec.html#method.retain) · [Book ch04-02 — The Rules of References](https://doc.rust-lang.org/book/ch04-02-references-and-borrowing.html#the-rules-of-references)

3. **Aynı anda iki `&mut` (`E0499`).** Derleyici iki indeksin farklı olduğunu kanıtlayamaz. `split_at_mut`, `iter_mut`, `chunks_mut` gibi API'ler "bu parçalar çakışmıyor" bilgisini türle ifade eder.
   ↳ Kaynak: [Rustdoc — slice::split_at_mut](https://doc.rust-lang.org/std/primitive.slice.html#method.split_at_mut) · [Nomicon — Subtyping and Variance](https://doc.rust-lang.org/nomicon/subtyping.html)

4. **Ödünç verilmişken taşımak (`E0505`).** Referansın son kullanımını taşımadan önceye al; NLL ödüncü o noktada bitmiş sayar.
   ↳ Kaynak: [Book ch04-02 — NLL](https://doc.rust-lang.org/book/ch04-02-references-and-borrowing.html) · [rustc 1.99.1 — nll.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/nll.rs)

5. **Referansın ardındaki değeri almak (`E0507`).** `&` yalnız bakma hakkıdır; üç seçenek vardır: bak (`&v[0]`), kopyala (`.clone()`), ya da koleksiyondan çıkararak al (`swap_remove`).
   ↳ Kaynak: [Rustdoc — std::mem::take](https://doc.rust-lang.org/std/mem/fn.take.html) · [Rustdoc — Vec::swap_remove](https://doc.rust-lang.org/std/vec/struct.Vec.html#method.swap_remove)

## Yerinden alma araçları

`&mut T` varken içindeki değeri boşluk bırakmadan almak için:

- `std::mem::take(&mut x)` — değeri alır, yerine `Default::default()` koyar.
- `std::mem::replace(&mut x, y)` — değeri alır, yerine `y` koyar.
- `Option::take(&mut opt)` — `Some(v)'yi alır, yerine `None` koyar.

↳ Kaynak: [Rustdoc — std::mem::take](https://doc.rust-lang.org/std/mem/fn.take.html) · [Rustdoc — std::mem::replace](https://doc.rust-lang.org/std/mem/fn.replace.html) · [Rustdoc — Option::take](https://doc.rust-lang.org/std/option/enum.Option.html#method.take)

Böylece "her yer her an geçerli bir değer tutar" değişmezi hiç bozulmaz.

## Derleyici perspektifi

- Hata kodlarının tamamı (`E0382`, `E0499`, `E0502`, `E0505`, `E0507`) rustc 1.99 ile derlenerek doğrulandı; üretilen yer `rustc_borrowck` ve MIR dataflow aşamalarıdır.
  ↳ Kaynak: [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs) · [rustc 1.99.1 — borrow_set.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrow_set.rs)

## Özet ve sonraki adım

- İmza = sahiplik sözleşmesi; `String` alır, `&String` ödünç alır, `&mut String` değiştirir.
- Kısmi move alan bazında çalışır; beş klasik hatanın deyimsel çözümü vardır.
- `take`/`replace` ile yer her zaman geçerli kalır.

Sıradaki bölüm: [4. Struct'lar](04-structs.md).
