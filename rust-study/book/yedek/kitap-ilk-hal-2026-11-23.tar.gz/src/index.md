# Rust Yolculuğu

Bu kitap, `learn/` altındaki çalışmaların bir **kitap biçimine** dönüştürülmüş hâlidir. Aynı içerik parçalı crate'ler yerine, birbirini izleyen sayfalarda anlatılır: temelden başlar, Rust Book'un kavramsal bölümlerini sırayla işler, sonra zor mekanizmaların köküne iner.

## Kitabın üç katmanı

1. **Temeller (1–8)** — Değişkenler, sahiplik, struct/enum, modüller, koleksiyonlar, hata yönetimi.
2. **Orta seviye (9–20)** — Jenerikler, trait'ler, closure/iterator, akıllı işaretçiler, eşzamanlılık, async, desenler, makrolar.
3. **İleri konular (21–29)** — Variance, DST, coherence, deref çözümü, Send/Sync, drop check, HRTB/GAT, Future'ın iç yapısı, mini runtime.

Zor konularda ana bölümün ardından bir **Derinleşme** sayfası gelir. Ana sayfa kavramı tanıtır; derinleşme sayfası aynı konuyu gerçekçi bir senaryoda, adım adım kod analizi ve sık yapılan hatalarla pekiştirir.

## Her maddenin kaynağı var

Anlatım maddde maddedir ve her maddenin altında bir **↳ Kaynak:** satırı bulunur. Bu satır, o cümlenin dayandığı belgeye (Rust Book, Reference, Nomicon, std dokümanı) ya da derleyici kaynak koduna (rustc 1.99.1, GitHub etiketli link) götürür. Kısaltmalar ve link biçimi için [Kaynak gösterimi](kaynaklar.md) sayfasına bakın.

## Doğruluk ilkesi

İçerik, resmî dokümanlar, internet ve yerel `guide/rust` derleyici kaynağıyla denetlendi. Kanıt bulunamayan iddialar **DOĞRULANAMADI** olarak işaretlendi ya da metinden çıkarıldı; sessizce doğru sayılmadı. Ayrıntılı denetim raporu depoda `reports/Rust dersleri doğruluk denetimi.md` dosyasındadır.

Hiçbir kaynak, tek başına %100 doğruluk garantisi vermez; sürümler değiştikçe satır numaraları kayabilir. Bu yüzden derleyici linklerinde sürüm etiketi (1.99.1) açıkça yazılır.

## Kod örnekleri

Örnekler `learn/` crate'lerinden gelir ve `cargo check` ile doğrulanmıştır. Komutları kopyalamak için `Çalıştır: cargo run -p <crate>` satırlarını izleyin. Not: `learn/basic-concepts` crate'inde denetim dışında kalan önceden var olmuş derleme hataları vardır.
