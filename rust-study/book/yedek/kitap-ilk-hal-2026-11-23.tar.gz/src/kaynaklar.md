# Kaynak gösterimi

Bu kitapta her anlatım maddesinin altında bir **↳ Kaynak:** satırı vardır. Amaç: hangi cümlenin hangi kaynaktan geldiğini tek bakışta görmek ve kaynağa tıklayabilmek.

## Kısaltmalar

| Etiket | Kaynak | Tür |
| --- | --- | --- |
| **Book chXX** | [The Rust Programming Language (2024 edition)](https://doc.rust-lang.org/book/) | Resmî kitap |
| **Reference** | [The Rust Reference](https://doc.rust-lang.org/reference/) | Resmî dil referansı |
| **Nomicon** | [The Rustonomicon](https://doc.rust-lang.org/nomicon/) | Resmî unsafe/references rehberi |
| **Rustdoc** | [std / core API dokümanları](https://doc.rust-lang.org/std/) | Resmî API dokümanı |
| **Rust by Example** | [Rust by Example](https://doc.rust-lang.org/rust-by-example/) | Resmî örnekler |
| **rustc 1.99.1** | [rust-lang/rust, etiket 1.99.1](https://github.com/rust-lang/rust/tree/1.99.1) | Derleyici kaynak kodu |
| **RfR** | Jon Gjengset, *Rust for Rustaceans* | Kitap (çevrimdışı kaynak; bölüm numarası verilir) |
| **Programming Rust** | Blandy & Orendorff, *Programming Rust* | Kitap |
| **Rust Atomics and Locks** | Mara Bos, *Rust Atomics and Locks* | Kitap |

## Derleyici kaynağı link formatı

Yerel `guide/rust/` ağacı **rustc 1.99.1** sürümüdür. Kod yorumlarında geçen `dosya.rs:satır` atıfları şu biçimde linklenir:

```
[rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs)
```

Satır bilgisi varsa linkin sonuna `#L170` eklenir:

```
[cell.rs:917-922](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/cell.rs#L917-L922)
```

> **Not:** Satır numaraları 1.99.1'e göredir; daha yeni sürümlerde kayabilir. Bu yüzden her linkte sürüm etiketi açıkça yazılır.

## Sık kullanılan rustc dosyaları

| Kısa ad | Tam yol (1.99.1) |
| --- | --- |
| `borrowck_errors.rs` | `compiler/rustc_borrowck/src/borrowck_errors.rs` |
| `borrow_set.rs` | `compiler/rustc_borrowck/src/borrow_set.rs` |
| `nll.rs` | `compiler/rustc_borrowck/src/nll.rs` |
| `elaborate_drops.rs` | `compiler/rustc_mir_transform/src/elaborate_drops.rs` |
| `check_unsafety.rs` | `compiler/rustc_mir_build/src/check_unsafety.rs` |
| `check_match.rs` | `compiler/rustc_mir_build/src/thir/pattern/check_match.rs` |
| `collector.rs` | `compiler/rustc_monomorphize/src/collector.rs` |
| `upvar.rs` | `compiler/rustc_hir_typeck/src/upvar.rs` |
| `probe.rs` | `compiler/rustc_hir_typeck/src/method/probe.rs` |
| `late.rs` | `compiler/rustc_lint/src/late.rs` |
| `cell.rs` | `library/core/src/cell.rs` |
| `marker.rs` | `library/core/src/marker.rs` |
| `deref.rs` | `library/core/src/ops/deref.rs` |
| `drop.rs` | `library/core/src/ops/drop.rs` |
| `future.rs` | `library/core/src/future/future.rs` |
| `wake.rs` | `library/core/src/task/wake.rs` |
| `poll.rs` | `library/core/src/task/poll.rs` |
| `mutex.rs` | `library/std/src/sync/poison/mutex.rs` |
| `boxed.rs` | `library/alloc/src/boxed.rs` |
| `arc.rs` | `library/alloc/src/rcs/arc.rs` |
| `rc.rs` | `library/alloc/src/rcs/rc.rs` |

## Doğruluk notu

Bu kitabın kaynağı, aynı depodaki `learn/` crate'leri ve onların doğrulanmış yorumlarıdır. Bir iddia için birincil kaynak bulunamadıysa metinde **DOĞRULANAMADI** etiketiyle işaretlenir; sessizce doğru sayılmaz. Denetim raporu: [`reports/Rust dersleri doğruluk denetimi.md`](https://github.com/kaann-rs/study-period/blob/main/rust-study/reports/Rust%20dersleri%20doğruluk%20denetimi.md).
