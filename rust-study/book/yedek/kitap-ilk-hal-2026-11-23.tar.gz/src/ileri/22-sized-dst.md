# 22. Boyut, DST ve Şişman İşaretçi

> Kaynak crate: `learn/advanced-concepts/ileri-sized-dst` · Çalıştır: `cargo run -p ileri-sized-dst`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

## Neden bu bölüm?

Kargo şirketi rafına koyacağı her kutunun boyunu önceden bilmek ister; bilmezse ne kadar yer ayıracağını bilemez. Rust da bir değeri saklamadan önce boyutunu ister, ama yazılar, dilimler ve `dyn Trait` bu bilgiyi türlerinde taşımaz. Çözüm, eksik bilgiyi işaretçinin kendisine eklemektir: adresin yanında uzunluk ya da metot listesi durur. Bu bölüm neden bazı işaretçiler tek, bazıları çift kâğıt olduğunu anlatır.

## 5 yaşındaki çocuğa anlatır gibi

Bir kutuya ne koyacağını bilmiyorsan kutuyu sabit büyüklükte yapamazsın. Bu yüzden kutunun yerine üzerinde "şu adreste, şu kadar uzunlukta" yazan bir etiket verirsin. Etiket küçük ama iki bilgi taşır; tek adres yetmez.

## Konu anlatımı (madde madde)

1. **Sized, boyu derleme anında bilinen türlerin işaret trait'idir.** `i32`, `String`, `Dugme` gibi çoğu tür otomatik Sized alır; derleyici bu bilgiyi alan offset'lerini ve ayrılacak bayt sayısını hesaplamak için kullanır.
   ↳ Kaynak: [Rustdoc — Sized](https://doc.rust-lang.org/std/marker/trait.Sized.html) · [rustc 1.99.1 — marker.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/marker.rs)

2. **DST'lerin boyutu çalışma anına kadar bilinmez.** İki yaygın örnek dilim `[T]` / `str` ve trait object `dyn Trait`'tir: elindeki `dyn Ciz` değerinin 8 mi 200 bayt mı olduğunu derleyici bilemez. Bu yüzden DST'ler hep bir işaretçinin ardında durur.
   ↳ Kaynak: [Nomicon — Sized](https://doc.rust-lang.org/nomicon/sized.html) · [Reference — Dynamically sized types](https://doc.rust-lang.org/reference/dynamically-sized-types.html)

3. **Her tür sınırı örtük olarak `T: Sized` içerir.** Struct alanı, fonksiyon argümanı/dönüşü, yerel değişken ve dizi elemanı gibi neredeyse her konumda Sized istenir; `T: ?Sized` yazmak bu örtük sınırı gevşetir. Gevşetince `T` yalnızca `&T` ya da `Box<T>` ardında kullanılabilir, çünkü işaretçinin kendisi Sized'dır.
   ↳ Kaynak: [Reference — Sized](https://doc.rust-lang.org/reference/trait-bounds.html#sized) · [Rustdoc — Sized](https://doc.rust-lang.org/std/marker/trait.Sized.html)

4. **DST doğrudan değer olarak kullanılamaz.** `fn al(_x: str)` yazımı E0277 verir ("the trait `Sized` is not implemented for `str`"); çözüm DST'yi bir işaretçi ardına koymaktır: `&str`, `Box<[T]>`, `&dyn Trait`. `tek_satir<T: Debug + ?Sized>(x: &T)` ise `str`, `[i32]` ve `dyn Ciz` için çalışır.
   ↳ Kaynak: [Reference — Sized](https://doc.rust-lang.org/reference/trait-bounds.html#sized) · [Rustdoc — Box](https://doc.rust-lang.org/std/boxed/struct.Box.html)

5. **İnce (thin) pointer tek word taşır.** 64-bit platformda `size_of::<usize>()` 8 bayttır ve `&i32`, `&Dugme`, `Box<i32>` gibi boyu bilinen türlere giden işaretçiler de 8 bayttır: yalnız adres.
   ↳ Kaynak: [Nomicon — Sized](https://doc.rust-lang.org/nomicon/sized.html) · [Rustdoc — Box](https://doc.rust-lang.org/std/boxed/struct.Box.html)

6. **Şişman (fat / wide) pointer adres + metadata taşır.** `&str`, `&[i32]`, `&dyn Ciz`, `Box<str>` ve `Box<dyn Ciz>` ölçüldüğünde 16 bayttır; kaynaklarda bu durum `"twice the size of a usize"` biçiminde tarif edilir (bu ifadenin RfR'den birebir alıntı olduğu **DOĞRULANAMADI**; 2×usize olgusu ölçümle doğrudur).
   ↳ Kaynak: [Nomicon — Sized](https://doc.rust-lang.org/nomicon/sized.html) · [Rustdoc — slice](https://doc.rust-lang.org/std/primitive.slice.html)

7. **İkinci word'ün içeriği türe göre değişir.** Dilim ve `str` için metadata uzunluktur (`&dizi[..3]` ile `&dizi[2..]` aynı dizinin farklı parçalarını gösterir); trait object için metadata vtable adresidir, böylece `n.ciz()` çağrısı doğru metoda gider.
   ↳ Kaynak: [Nomicon — Data](https://doc.rust-lang.org/nomicon/data.html) · [Rustdoc — slice](https://doc.rust-lang.org/std/primitive.slice.html)

8. **Vtable somut türün metot adreslerini, layout/alignment bilgisini ve drop yordamını tutar.** Metot çağrısı bu tablodan adresi okuyup atlar (dinamik dispatch, küçük bir dolaylama). `ileri-future`'daki `RawWakerVTable` benzer bir fikir olarak verilebilir; birebir karşılık **DOĞRULANAMADI**.
   ↳ Kaynak: [Nomicon — Data](https://doc.rust-lang.org/nomicon/data.html) · [Rustdoc — std](https://doc.rust-lang.org/std/)

9. **Metadata'ya programdan erişim kararlı Rust'ta yoktur.** `std::ptr::Pointee` ve `std::ptr::metadata` yalnızca `ptr_metadata` özellik bayrağı altında (issue #81513) kullanılabilir; kararlı derleyici E0658 verir. Fat pointer'ın kendisi ise Sized'dır (2×usize), bu yüzden değişkende ya da yapı alanında tutulabilir.
   ↳ Kaynak: [rustc — issue #81513](https://github.com/rust-lang/rust/issues/81513) · [Rustdoc — std::ptr](https://doc.rust-lang.org/std/ptr/index.html)

10. **Generic ve `dyn` aynı sorunu iki şekilde çözer.** `fn f<T>(x: T)` her kullanılan somut tür için kod kopyası üretir (monomorphization, yalnızca kullanılan parçalar), `dyn Trait` ise tek kod + vtable kullanır. Biri kod boyutu/hız, diğeri esneklik + küçük dolaylama sağlar; Sized/DST ayrımı bunların alt yapısıdır.
    ↳ Kaynak: [Book ch10-01 — Generic Data Types](https://doc.rust-lang.org/book/ch10-01-syntax.html) · [Book ch18-02 — Trait Objects](https://doc.rust-lang.org/book/ch18-02-trait-objects.html)

## Kodda nasıl görünür?

```rust
use std::mem::size_of;

trait Ciz {
    fn ciz(&self) -> String;
}
struct Dugme {
    ad: String,
}
impl Ciz for Dugme {
    fn ciz(&self) -> String {
        format!("[{}]", self.ad)
    }
}

fn boyutlar() {
    let usize_boyu = size_of::<usize>();
    println!("usize (bir word) = {usize_boyu} bayt\n");
    println!("  &i32       = {}", size_of::<&i32>());       // 8
    println!("  &str       = {}", size_of::<&str>());       // 16: ptr + uzunluk
    println!("  &dyn Ciz   = {}", size_of::<&dyn Ciz>());   // 16: ptr + vtable
}

fn tek_satir<T: std::fmt::Debug + ?Sized>(x: &T) {
    println!("  ?Sized ile: {x:?}");
}

fn fat_pointer_anlami() {
    let dizi = [10, 20, 30, 40, 50];
    let d1: &[i32] = &dizi[..3];
    let d2: &[i32] = &dizi[2..];
    println!("slice fat pointer: d1.len()={} d2.len()={} (ikinci word = uzunluk)", d1.len(), d2.len());

    let nesneler: Vec<Box<dyn Ciz>> = vec![
        Box::new(Dugme { ad: String::from("Tamam") }),
        Box::new(Dugme { ad: String::from("İptal") }),
    ];
    for n in &nesneler {
        println!("trait object (vtable ile dispatch): {}", n.ciz());
    }
}
```

## Sık yapılan hatalar

| Kod | Hata | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| `fn al(_x: str) {}` | **E0277** | `str` Sized değil; DST'yi `&str` ya da `Box<str>` ardına koy. | [Reference — Sized](https://doc.rust-lang.org/reference/trait-bounds.html#sized) |
| `fn yaz2<T: Debug>(x: &T)` içinde `yaz2("yazı")` | **E0277** | Örtük `T: Sized` kaldırılmamış; `T: ?Sized` yaz. | [Reference — Sized](https://doc.rust-lang.org/reference/trait-bounds.html#sized) |
| Kararlı Rust'ta `std::ptr::metadata(x)` / `Pointee` | **E0658** | `ptr_metadata` geceli, issue #81513; yalnız nightly'de özellik bayrağıyla erişilebilir. | [rustc — issue #81513](https://github.com/rust-lang/rust/issues/81513) |
| `dyn Ciz` değerinin `Dugme` alanına erişmeye çalışmak | — (derleme hatası) | Trait object yalnız trait'in metotlarını bilir; somut alanlar görünmez. | [Nomicon — Data](https://doc.rust-lang.org/nomicon/data.html) |

## Derleyici perspektifi

- `Sized` (core::marker::Sized) derleyici tarafından otomatik uygulanan bir işaret trait'idir. DST'lerde boyut çalışma anı bilgisine bağlı olduğu için geçerli kod üretilemez: tuple'a kaç bayt ayrılacağı, dördüncü alanın offset'i belirsiz kalır.
  ↳ Kaynak: [rustc 1.99.1 — marker.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/marker.rs) · [Nomicon — Sized](https://doc.rust-lang.org/nomicon/sized.html)

- `T: ?Sized` örtük sınırı kaldırır; derleyici artık `T` için yer açmaz, yalnızca `&T` / `Box<T>` gibi boyutu bilinen işaretçiyi kullanır. `Box` ve `Arc` da fat pointer saklayabildiği için `T: ?Sized` destekler (`Box<str>`, `Arc<dyn Trait>`).
  ↳ Kaynak: [Reference — Sized](https://doc.rust-lang.org/reference/trait-bounds.html#sized) · [rustc 1.99.1 — boxed.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/alloc/src/boxed.rs)

- DST'ye referans alındığında derleyici iki word'lük işaretçiyi otomatik kurar: bir word veriye, bir word metadata'ya (uzunluk veya vtable adresi). Metadata'ya programatik erişim `ptr_metadata` ile nightly'e açıktır; kararlı Rust'ta değildir.
  ↳ Kaynak: [Nomicon — Sized](https://doc.rust-lang.org/nomicon/sized.html) · [rustc — issue #81513](https://github.com/rust-lang/rust/issues/81513)

- Generic kod monomorphize edilirken her somut `T` için ayrı kopya üretilir; `dyn Trait` çağrıları ise vtable üzerinden tek kodla çözülür. Bu ayrım, Boyut/DST kurallarının doğrudan sonucudur.
  ↳ Kaynak: [Book ch18-02 — Trait Objects](https://doc.rust-lang.org/book/ch18-02-trait-objects.html) · [Nomicon — Data](https://doc.rust-lang.org/nomicon/data.html)

> **Kaynak notu:** RfR Böl. 2 ("Dynamically Sized Types and Wide Pointers"); "fat pointer" ile "wide pointer" aynı şeyin iki adıdır ve bölüm başlığı yayıncının ayrıntılı içindekiler listesiyle doğrulandı. `RawWakerVTable` benzetmesinin birebir karşılığı **DOĞRULANAMADI**.
> ↳ Kaynak: [Nomicon — Sized](https://doc.rust-lang.org/nomicon/sized.html) · [Nomicon — Data](https://doc.rust-lang.org/nomicon/data.html)

## Özet ve sonraki adım

- Boyut derleme anında bilinmek zorundadır; DST'ler (`str`, `[T]`, `dyn Trait`) yalnızca işaretçi ardında tutulur.
- İnce pointer 8, fat pointer 16 bayttır (64-bit): ikinci word uzunluk ya da vtable adresidir.
- `?Sized` örtük sınırı gevşetir; metadata API'si nightly'de `ptr_metadata` + issue #81513, kararlıda yok.

Sıradaki bölüm: [23. Tutarlılık ve Yetim Kuralı](23-coherence.md).
