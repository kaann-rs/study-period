# 29.1 Thread'ler ve Zamanlayıcı

> Kaynak dosya: `learn/advanced-concepts/ileri-eszamanlilik-async/src/threadler.rs` · Test: `cargo test -p ileri-eszamanlilik-async`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

29. bölümün A katmanı, yani "beklerken ne yapalım?" sorusunun thread tarafı. Burada kilidin **türünü** yüke göre seçmek, koşul için işlemciyi yakmadan beklemek ve derleyicinin yakalayamadığı deadlock'u tasarımla önlemek var. Kaynak: `threadler.rs` yorumları (RfR Böl. 10, Rust Atomics and Locks).

## Neden bu sayfa?

Müfredat Böl. 16 (kursun kendi numarası; RfR'de karşılığı Böl. 10) `Mutex` + kanal + `scope` ile "veri yarışı olmayan" kod yazmayı öğretti. Burada bir adım ötesi var: çok okuyucu için `RwLock`, koşul için `Condvar`, kilitler için global sıra ve tek bir sayı için atomik. Bu sayfa teknik odaklıdır; sade benzetmeler ana sayfada ve kaynak dosyadaki "SADE ANLATIM" kutularındadır.

## A1) RwLock — okuma ağırlıklı paylaşımlı durum

1. **`RwLock<T>` borrow kuralının çalışma anındaki karşılığıdır.** `read()` çok sayıda `RwLockReadGuard` (`&T` gibi) verir; `write()` tek `RwLockWriteGuard` (`&mut T` gibi) verir. On thread yalnız okumak istese bile Mutex hepsini sıraya sokar; yapılandırma, yönlendirme tablosu ve önbellek gibi çok okunup seyrek yazılan verilerde RwLock kazanır.
   ↳ Kaynak: [Rustdoc — std::sync::RwLock](https://doc.rust-lang.org/std/sync/struct.RwLock.html) · [Book ch16-03](https://doc.rust-lang.org/book/ch16-03-shared-state.html)

2. **Guard dışarı verilmez; kilit yükseltme yoktur.** `AyarDeposu::oku` değeri klonlayıp kilidi hemen bırakır, aksi hâlde unutulan bir okuma guard'ı bütün yazarları bekletirdi. Okuma guard'ı elindeyken aynı thread'de `write()` istemek derlenir ama thread kendi kendini bekler; doğru yol guard'ı bırakıp koşulu kilit altında **yeniden** denetlemektir.
   ↳ Kaynak: [Rustdoc — RwLock](https://doc.rust-lang.org/std/sync/struct.RwLock.html) · [Rustdoc — MutexGuard](https://doc.rust-lang.org/std/sync/struct.MutexGuard.html)

## A2) Condvar — sınırlı kuyruk ve geri basınç

3. **`wait` "kilidi bırak + uyu"yu atomik yapar; koşul her zaman döngüde denetlenir.** Araya boşluk olsaydı bildirim kaybolur (lost wakeup) ve tüketici sonsuza dek uyurdu. `wait_while` bu döngüyü senin yerine yazar; uyanınca kilidi geri alır ve sebepsiz uyanmalarda (spurious wakeup) yeniden bekler.
   ↳ Kaynak: [Rustdoc — std::sync::Condvar](https://doc.rust-lang.org/std/sync/struct.Condvar.html) · [Rustdoc — Condvar::wait_while](https://doc.rust-lang.org/std/sync/struct.Condvar.html#method.wait_while)

4. **İki Condvar'lı `SinirliKuyruk` geri basıncı (backpressure) uygular.** `bos_degil` tüketicileri, `dolu_degil` üreticileri bekletir; kapasite dolunca hızlı üretici de durur ve yavaş tüketicinin belleği şişiremez. `kapat()` her iki zilde de `notify_all()` çağırır, çünkü kapanış bekleyen **herkesi** ilgilendirir; `notify_one()` ötekileri uyutmaya devam ederdi.
   ↳ Kaynak: [Rustdoc — std::sync::Condvar](https://doc.rust-lang.org/std/sync/struct.Condvar.html) · [Rustdoc — std::collections::VecDeque](https://doc.rust-lang.org/std/collections/struct.VecDeque.html)

5. **Bildirimden önce kilidi bırakmak bir verim inceliğidir.** Kilit eldeyken bildirilirse uyanan taraf hemen kilidi ister, alamaz ve yeniden uyur — boşa bir uyanma. Doğruluk açısından iki sıra da geçerlidir, çünkü koşul kilit altında değiştirilmiştir.
   ↳ Kaynak: [Rustdoc — std::sync::Condvar::notify_one](https://doc.rust-lang.org/std/sync/struct.Condvar.html#method.notify_one) · [Book ch16-03](https://doc.rust-lang.org/book/ch16-03-shared-state.html)

## A3) Deadlock ve kilit sıralaması

6. **Derleyici veri yarışını yakalar, deadlock'u yakalamaz.** "Önce kaynağı, sonra hedefi kilitle" yazan saf transfer, karşılıklı çağrılarda kilitlenir. Çözüm global sıradır: bütün kod kilitleri hesap numarasına göre (küçük önce) alır; aynı hesap ve negatif tutar önceden reddedilir. İki kilidin ikisi de elde olmadan bakiyeye dokunulmaz, böylece yarım transfer dışarıdan görülemez.
   ↳ Kaynak: [Book ch16-03](https://doc.rust-lang.org/book/ch16-03-shared-state.html) · [Rustdoc — std::sync::Mutex](https://doc.rust-lang.org/std/sync/struct.Mutex.html) · Rust Atomics and Locks

## A4) Atomikler — kilitsiz tek adımlık işlemler

7. **`compare_exchange` "oku → karar ver → yaz" üçlüsünü tek hamleye indirir.** `lider_sec` içinde yalnız ilk gelen `0` değerini görüp kimliğini yazar; geç kalanlar `Err(mevcut_lider)` alır ve kazanan sayısı ayrı bir `AtomicU32` ile `Relaxed` izlenir — bağımsız sayaç için daha güçlü sıralama gerekmez.
   ↳ Kaynak: [Rustdoc — AtomicU32::compare_exchange](https://doc.rust-lang.org/std/sync/atomic/struct.AtomicU32.html#method.compare_exchange) · [Rustdoc — Ordering](https://doc.rust-lang.org/std/sync/atomic/enum.Ordering.html)

8. **`Ordering` bir izindir; zayıflatmak ölçüm ister.** `Relaxed` yalnız atomikliği garanti eder; `Release` (yazarken) / `Acquire` (okurken) o yazmadan önce yapılanları öteki thread'e görünür kılar; `SeqCst` tüm SeqCst işlemler için tek global sıra verir. Emin değilsen SeqCst kullan; yanlış zayıflatma testle yakalanmayabilir.
   ↳ Kaynak: [Rustdoc — std::sync::atomic::Ordering](https://doc.rust-lang.org/std/sync/atomic/enum.Ordering.html) · [Nomicon — Atomics](https://doc.rust-lang.org/nomicon/) · Rust Atomics and Locks

## A5) Send / Sync — pratik tablo

9. **Aynı iç tür kilit değişince Sync olur ya da olmaz.** `Mutex<Cell<u8>>` Sync'tir (erişim teke iner, `Cell`'in `Send` olması yeter); `RwLock<Cell<u8>>` ise Sync **değildir** — iki okuyucu aynı `Cell`'e yazabilirdi ve **E0277** alınır. `MutexGuard` kilit alan thread'de bırakılmalı, `Arc<Mutex<Vec<u8>>>` ise thread'ler arası paylaşımın klasik kalıbıdır.
   ↳ Kaynak: [Book ch16-04](https://doc.rust-lang.org/book/ch16-04-extensible-concurrency-sync-and-send.html) · [rustc 1.99.1 — mutex.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/std/src/sync/poison/mutex.rs) · [Reference — auto traits](https://doc.rust-lang.org/reference/)

## Adım adım kod

Sınırlı kuyrukta üretici, yer açılana dek bekler; kapanış hâlinde öğeyi geri verir:

```rust
pub fn koy(&self, oge: T) -> Result<(), T> {
    let kilit = self.durum.lock().unwrap();
    let mut durum = self
        .dolu_degil
        .wait_while(kilit, |d| d.ogeler.len() >= self.kapasite && !d.kapali)
        .unwrap();
    if durum.kapali {
        return Err(oge);
    }
    durum.ogeler.push_back(oge);
    durum.en_yuksek_doluluk = durum.en_yuksek_doluluk.max(durum.ogeler.len());
    drop(durum);
    self.bos_degil.notify_one();
    Ok(())
}
```

Transferde sıra yöne değil hesap numarasına göre belirlenir:

```rust
pub fn transfer(kimden: &Hesap, kime: &Hesap, tutar: i64) -> bool {
    if kimden.no == kime.no { return false; }
    if tutar <= 0 { return false; }
    let kaynak_once = kimden.no < kime.no;
    let (ilk, ikinci) = if kaynak_once { (kimden, kime) } else { (kime, kimden) };
    let mut ilk_kilit = ilk.bakiye.lock().unwrap();
    let mut ikinci_kilit = ikinci.bakiye.lock().unwrap();
    let (kaynak, hedef) = if kaynak_once {
        (&mut *ilk_kilit, &mut *ikinci_kilit)
    } else {
        (&mut *ikinci_kilit, &mut *ilk_kilit)
    };
    if *kaynak < tutar { return false; }
    *kaynak -= tutar;
    *hedef += tutar;
    true
}
```

## Sık yapılan hatalar

| Hata | Belirti | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| Okuma guard'ı varken `write()` | Derlenir; kendi kendini bekletir | RwLock'ta yükseltme yok; guard'ı bırak, koşulu yeniden denetle. | [Rustdoc — RwLock](https://doc.rust-lang.org/std/sync/struct.RwLock.html) |
| `sync_ister::<RwLock<Cell<u8>>>()` | **E0277** | İki okuyucu aynı `Cell`'e yazabilir; `Mutex<Cell<u8>>` Sync'tir. | [Reference — auto traits](https://doc.rust-lang.org/reference/) |
| `send_ister::<MutexGuard<'static, u8>>()` | **E0277** | Kilidi alan thread guard'ı bırakmalı; kilidi kilit altında tutan veriyi gönder. | [Rustdoc — MutexGuard](https://doc.rust-lang.org/std/sync/struct.MutexGuard.html) |
| Kapanışta `notify_one()` | Bekleyenlerden biri sonsuza dek uyur | Kapanış herkesi ilgilendirir → `notify_all()`. | [Rustdoc — Condvar::notify_all](https://doc.rust-lang.org/std/sync/struct.Condvar.html#method.notify_all) |
| Sayaç için yanlış `Ordering` | x86'da sorunsuz görünür, ARM'da bozulur | Ölçmeden zayıflatma; bağımsız sayaçta Relaxed yeter. | [Rustdoc — Ordering](https://doc.rust-lang.org/std/sync/atomic/enum.Ordering.html) |

↳ Kaynak: [Rustdoc — std::sync::Condvar](https://doc.rust-lang.org/std/sync/struct.Condvar.html) · [Rustdoc — std::sync::atomic::Ordering](https://doc.rust-lang.org/std/sync/atomic/enum.Ordering.html)

## Derleyici perspektifi

- Kilitler derleyicinin bildiği türler değildir; güvenlik guard'ın ömrü (RAII + borrow checker) ve `Send`/`Sync` auto-trait'lerinden gelir. "Kilidi almadan veriye dokundum" yazılamaz; "kilitleri yanlış sırayla aldım" yazılabilir.
  ↳ Kaynak: [Book ch16-04](https://doc.rust-lang.org/book/ch16-04-extensible-concurrency-sync-and-send.html) · [Reference — auto traits](https://doc.rust-lang.org/reference/)

- Trait sınırlarındaki fark std kaynağında görülür: `Mutex<T>` için `unsafe impl Sync` `T: Send` yeter; `RwLock<T>` için `T: Send + Sync` gerekir, çünkü aynı anda çok okuyucu `&T` görür.
  ↳ Kaynak: [rustc 1.99.1 — mutex.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/std/src/sync/poison/mutex.rs) · [Rustdoc — RwLock](https://doc.rust-lang.org/std/sync/struct.RwLock.html)

- Üyelik testleri (`send_ister`, `sync_ister`) çalışma anında değil derleme anında çalışır; E0277 mesajları rustc 1.99 ile doğrulandı. `Ordering` seçimi ise derleyicinin denetlemediği bir izindir.
  ↳ Kaynak: [Reference — traits](https://doc.rust-lang.org/reference/items/traits.html) · [Rustdoc — Ordering](https://doc.rust-lang.org/std/sync/atomic/enum.Ordering.html)

## Özet ve sonraki adım

- RwLock çok okuyucuya izin verir; yükseltme yoktur ve `T: Sync` şartı Mutex'ten farklıdır.
- Condvar kilidi bırakıp uyur, koşul döngüde denetlenir; sınırlı kuyruk üreticiye geri basınç uygular.
- Deadlock tasarımla önlenir; atomiklerde sıralama ölçülmeden zayıflatılmaz.

Sıradaki sayfa: [29.2 Çalışma Zamanı: Görev Kuyruğu ve Backpressure](29-calisma-zamani.md).
