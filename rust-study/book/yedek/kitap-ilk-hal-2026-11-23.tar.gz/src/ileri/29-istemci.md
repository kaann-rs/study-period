# 29.3 Asenkron API İstemcisi

> Kaynak dosya: `learn/advanced-concepts/ileri-eszamanlilik-async/src/istemci.rs` · Test: `cargo test -p ileri-eszamanlilik-async`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

29. bölümün C katmanı: önceki iki sayfadaki parçaları (`baslat`, `Uyku`, `zaman_asimi`) bir araya getiren gerçeğe yakın bir istemci. Kaynak `istemci.rs` yorumları; kavramsal arka plan RfR Böl. 8 ve müfredat Böl. 17 (kursun kendi numarası).

## Neden bu sayfa?

Bir istemcinin üç temel ihtiyacı vardır: istekleri eşzamanlı atmak, yavaş isteği zaman aşımıyla kesmek ve geçici hatada yeniden denemek. Burada ağ yerine gecikmeli sahte bir sunucu var; kodun şekli tokio + reqwest ile yazılanla aynıdır. Aynı dosya async kodun en yaygın iki hatasını da gösterir: thread'i bloklamak ve kilidi `.await` boyunca tutmak.

## C1) Sahte sunucu ve istemci

1. **İstemci üç ihtiyacı üç mekanizmayla karşılar.** Eşzamanlı istek için `baslat` (≈ `tokio::spawn`), yavaş isteği kesmek için `zaman_asimi` (≈ `tokio::time::timeout`), geçici hatada yeniden denemek için `yeniden_dene`. Ağ yerine `SahteSunucu` gecikme taklit eder, böylece davranış deterministik karşılaştırmalarla izlenir.
   ↳ Kaynak: [Book ch17-03](https://doc.rust-lang.org/book/ch17-03-more-futures.html) · [Rustdoc — std::future::Future](https://doc.rust-lang.org/std/future/trait.Future.html)

2. **Görev sınırı yüzünden imza `Arc<SahteSunucu>` ve `&'static str` olur.** `istek` bir görev olacak; görevler `'static` olduğu için `&SahteSunucu` alsaydı future o referansı içinde taşır ve sınırı sağlayamazdı. Paylaşılan durumu görevlere vermenin yolu thread'lerdekiyle aynıdır: `Arc`. Hata türü üç durumu ayırır: `Gecici(503)` yeniden denemeye değer, `Bulunamadi` (404) kalıcıdır, `ZamanAsimi` sürenin dolduğunu söyler.
   ↳ Kaynak: [Reference — traits](https://doc.rust-lang.org/reference/items/traits.html) · [Book ch16-01](https://doc.rust-lang.org/book/ch16-01-threads.html) · RfR Böl. 8

3. **Pano üç kaynağı aynı anda yükler; toplam süre en uzun isteğe yaklaşır.** Üç `baslat` çağrısı istekleri hemen kuyruğa koyar; `.await` yalnız **sonucu** bekler. Sıralı yapılsaydı 20 + (10+5+10+10+10) + 60 ≈ 125 ms sürerdi; eşzamanlıda en uzun görev (~60 ms) belirler. Kesin süre makineye göre değiştiği için yalnız karşılaştırma sonucu yazdırılır.
   ↳ Kaynak: [Book ch17-02](https://doc.rust-lang.org/book/ch17-02-async-await.html) · [Rustdoc — std::thread::sleep](https://doc.rust-lang.org/std/thread/fn.sleep.html)

## C2) Yeniden deneme ve backoff

4. **`yeniden_dene` hazır future değil, future üreten bir closure ister.** Bir future yalnız bir kez tamamlanır; bittikten sonra yeniden poll EDİLMEMELİDİR — bu bir sözleşme ihlalidir, derlenir ama panik/askıda kalma olabilir. Her deneme taze bir future ister, bu yüzden imza `F: FnMut() -> Fut, Fut: Future<...>` olur.
   ↳ Kaynak: [Rustdoc — Future, Panics](https://doc.rust-lang.org/std/future/trait.Future.html#panics) · [Rustdoc — Future::poll](https://doc.rust-lang.org/std/future/trait.Future.html#the-poll-method)

5. **Bekleme async uykuyla yapılır; `thread::sleep` değil.** Denemeler arası artan bekleme (backoff) `uyu_ms(5 * u64::from(deneme))` ile kurulur: hata veren servise hemen yeniden yüklenmek yerine her denemede biraz daha uzun beklenir. Rust 1.85+'ta aynı bound `impl AsyncFnMut() -> Result<T, IstekHatasi>` olarak da yazılabilir; kaynak, "closure çağrılır → future döner → future beklenir" iki adımını görünür tutmak için klasik biçimi seçer.
   ↳ Kaynak: [Rustdoc — std::thread::sleep](https://doc.rust-lang.org/std/thread/fn.sleep.html) · [Rustdoc — std::future::Future](https://doc.rust-lang.org/std/future/trait.Future.html) · [Rust 1.85.0 — async closures](https://blog.rust-lang.org/2025/02/20/Rust-1.85.0/)

6. **Yalnız geçici hata ve hak kaldıysa yeniden denenir.** `Err(hata) if hata.gecici_mi() && deneme < en_fazla` kolu beklemeyi artırır; başarı, kalıcı hata ya da hakkın bitmesi sonucu olduğu gibi döndürür. Böylece 404 gibi bir hata ikinci kez denenmez, hak bitince son hata korunur.
   ↳ Kaynak: [Rustdoc — std::future::Future](https://doc.rust-lang.org/std/future/trait.Future.html) · [Reference — traits](https://doc.rust-lang.org/reference/items/traits.html)

## C3) Yaygın hata: async içinde thread'i bloklamak

7. **Poll içinde uzun süre kalmak bütün görevleri durdurur.** Çalıştırıcı tek thread'de poll eder; `thread::sleep`, bloklayan dosya/ağ çağrısı, ağır hesap ya da std `Mutex`'te uzun bekleme o thread'deki öteki görevleri bekletir. Derleyici bunu yakalamaz: kod derlenir, doğru sonucu da verir, yalnız eşzamanlılık kaybolur. İki `.await` arası kısa olmalı; beklemek için runtime'ın async araçları kullanılmalıdır.
   ↳ Kaynak: [Rustdoc — Future — Runtime characteristics](https://doc.rust-lang.org/std/future/trait.Future.html#runtime-characteristics) · [Rustdoc — std::thread::sleep](https://doc.rust-lang.org/std/thread/fn.sleep.html)

8. **Kaçınılmaz bloklayan iş ayrı thread'e verilir.** `ayri_threadde` (≈ tokio'da `spawn_blocking`) işi yeni bir thread'de çalıştırır; paylaşılan yuva + waker ile bitince haber verir, `poll_fn` ise sonuç ya da waker kaydını tek kilit altında yapar. Ölçümde `thread::sleep` ile üç görev ≥ 90 ms (sıraya girdi), async uyku ve ayrı thread ile < 90 ms (birlikte ilerledi) çıkar.
   ↳ Kaynak: [Rustdoc — std::future::poll_fn](https://doc.rust-lang.org/std/future/fn.poll_fn.html) · [Rustdoc — std::thread::spawn](https://doc.rust-lang.org/std/thread/fn.spawn.html) · [Rustdoc — Future — Runtime characteristics](https://doc.rust-lang.org/std/future/trait.Future.html#runtime-characteristics)

## C4) Yaygın hata: kilidi `.await` boyunca tutmak

9. **`MutexGuard` await noktasında canlı kalırsa future `Send` olmaz.** `baslatici.baslat(sayaci_artir(...))` şu mesajı verir: `future cannot be sent between threads safely` — bu hatanın E-kodu yoktur. Async fn'in state machine'i await anında canlı her yereli içinde saklar; `MutexGuard` `!Send` olduğu için future da `!Send` olur ve `baslat`ın `F: Send` sınırı sağlanmaz. Çözüm guard'ı bir blok içinde bırakıp sonra `.await` etmektir; kilidi bekleme boyunca gerçekten tutmak gerekiyorsa `tokio::sync::Mutex` gibi async farkındalığı olan bir kilit gerekir.
   ↳ Kaynak: [Book ch16-04](https://doc.rust-lang.org/book/ch16-04-extensible-concurrency-sync-and-send.html) · [Reference — async bloklar](https://doc.rust-lang.org/reference/) · [Rustdoc — std::sync::MutexGuard](https://doc.rust-lang.org/std/sync/struct.MutexGuard.html)

10. **Send şartı olmayan tek thread'li runtime'da aynı kod derlenir ama deadlock'a yol açabilir.** Görev A kilidi alıp await'te bekler; görev B `lock()` der ve thread'i bloklar; A artık poll edilemez, kilidi bırakamaz. Aynı aileden üç hata daha vardır: yereli ödünç alan görev (**E0373**, çözümü `async move`), `Rc`'yi await boyunca taşımak (E-kodu yok, yine "future cannot be sent") ve waker'ı kaydetmeden `Pending` dönen elle yazılmış future (derlenir, `calistir()` dönmez). Sonuncusunda kural şudur: `cx.waker()`'ı olayı bilecek tarafa teslim et ve denetimle kaydı aynı kilit altında yap.
    ↳ Kaynak: [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs) · [Rustdoc — Future::poll, Return value](https://doc.rust-lang.org/std/future/trait.Future.html#return-value) · [Rustdoc — std::sync::Condvar](https://doc.rust-lang.org/std/sync/struct.Condvar.html)

## Adım adım kod

Yeniden deneme: her çağrı taze future üretir, yalnız geçici hatada bekleyip tekrar dener.

```rust
pub async fn yeniden_dene<F, Fut, T>(en_fazla: u32, mut dene: F) -> Result<T, IstekHatasi>
where
    F: FnMut() -> Fut,
    Fut: Future<Output = Result<T, IstekHatasi>>,
{
    let mut deneme = 1;
    loop {
        match dene().await {
            Err(hata) if hata.gecici_mi() && deneme < en_fazla => {
                uyu_ms(5 * u64::from(deneme)).await;
                deneme += 1;
            }
            sonuc => return sonuc,
        }
    }
}
```

Doğru kilit kullanımı: guard blok içinde düşer, awaite kilitsiz girilir.

```rust
pub async fn sayaci_artir(sayac: Arc<Mutex<u32>>) -> u32 {
    let yeni_deger = {
        let mut kilit = sayac.lock().unwrap();
        *kilit += 1;
        *kilit
    }; // ← guard burada düştü
    uyu_ms(5).await;
    yeni_deger
}
```

## Sık yapılan hatalar

| Hata | Belirti | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| `async { println!("{ad}") }` ile yerel ödünç | **E0373** | Görev yerel değişkenden uzun yaşayabilir; `async move` ile sahipliği göreve ver. | [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs) |
| `MutexGuard` / `Rc` / `Ref` taşımak | E-kodu yok: `future cannot be sent between threads safely` | Guard'ı await'ten önce bırak; paylaşım için `Arc`, gerekirse async kilit. | [Book ch16-04](https://doc.rust-lang.org/book/ch16-04-extensible-concurrency-sync-and-send.html) |
| `thread::sleep` içeren görev | Derlenir; eşzamanlılık kaybolur | `uyu_ms(..).await` ya da bloklayan işi ayrı thread'e ver. | [Future — Runtime characteristics](https://doc.rust-lang.org/std/future/trait.Future.html#runtime-characteristics) |
| Bitmiş future'ı yeniden poll etmek | Panik/askıda kalma olabilir (E-kodu yok) | Future yeniden poll EDİLMEMELİDİR; her denemede taze future üret. | [Future — Panics](https://doc.rust-lang.org/std/future/trait.Future.html#panics) |
| Waker'sız `Pending` | `calistir()` dönmez | Waker'ı teslim et; denetim + kayıt aynı kilit altında. | [Future::poll — Return value](https://doc.rust-lang.org/std/future/trait.Future.html#return-value) |

↳ Kaynak: [Rustdoc — std::future::Future](https://doc.rust-lang.org/std/future/trait.Future.html) · [Rustdoc — std::sync::Mutex](https://doc.rust-lang.org/std/sync/struct.Mutex.html)

## Derleyici perspektifi

- `async fn` bir state machine'e dönüşür; await anında canlı olan her yerel bir alan olarak saklanır. `Send`, `Sync`, `Unpin` auto-trait'leri bu alanlardan türetilir; `MutexGuard`, `Rc` ya da `Ref` oradaysa future gerekli sınırı karşılamaz.
  ↳ Kaynak: [Reference — async bloklar](https://doc.rust-lang.org/reference/) · [Reference — auto traits](https://doc.rust-lang.org/reference/)

- `baslat`ın `F: Future + Send + 'static` sınırı, görev thread'ler arasında taşınabildiği ve çağıran fonksiyondan uzun yaşayabildiği için vardır. E0373 ve "future cannot be sent" mesajları rustc 1.99 ile doğrulandı; ikincisinin E-kodu yoktur.
  ↳ Kaynak: [Reference — traits](https://doc.rust-lang.org/reference/items/traits.html) · [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs)

- Waker `Send + Sync` olduğu için bir thread'den başlatılan görev başka thread'den uyandırılabilir; bu, `ayri_threadde` ve zamanlayıcı desenlerinin temelidir.
  ↳ Kaynak: [rustc 1.99.1 — wake.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/task/wake.rs) · [Rustdoc — std::task::Waker](https://doc.rust-lang.org/std/task/struct.Waker.html)

- `poll_fn`, bir closure'dan elle küçük bir future üretir; iptal ise future'ı düşürmektir. Bu yüzden bir future her await noktasında yarıda kesilmeye hazır olmalı ve bir kez tamamlandıktan sonra yeniden poll EDİLMEMELİDİR.
  ↳ Kaynak: [Rustdoc — std::future::poll_fn](https://doc.rust-lang.org/std/future/fn.poll_fn.html) · [Rustdoc — Future, Panics](https://doc.rust-lang.org/std/future/trait.Future.html#panics)

- Rust 1.85+ async closure'ları (`AsyncFn`, `AsyncFnMut`, `AsyncFnOnce`) prelude'a girdi; kaynak yorumunda klasik `FnMut() -> Fut` biçiminin korunması bilinçli bir pedagojik tercihtir.
  ↳ Kaynak: [Rust 1.85.0 — async closures](https://blog.rust-lang.org/2025/02/20/Rust-1.85.0/) · [Reference — traits](https://doc.rust-lang.org/reference/items/traits.html)

## Özet ve sonraki adım

- Eşzamanlı istekler, zaman aşımı ve yeniden deneme aynı görev kuyruğunun üstüne kurulur; bekleme her zaman async uykuyla yapılır.
- Bloklayan iş ayrı thread'e verilir; kilit guard'ı `.await`den önce bırakılır, aksi hâlde future `Send` olmaz.
- Future yeniden poll EDİLMEMELİDİR; taze future, doğru waker kaydı ve tek kilit altında denetim bu bölümün ortak invariantıdır.

Seri burada biter: [Kaynaklar ve doğruluk notu](../kaynaklar.md). Dilersen [29. İleri Eşzamanlılık ve Async](29-ileri-eszamanlilik-async.md) ana sayfasına dönebilirsin.
