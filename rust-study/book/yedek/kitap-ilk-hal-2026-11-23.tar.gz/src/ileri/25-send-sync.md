# 25. Send / Sync'in İç Yüzü

> Kaynak crate: `learn/advanced-concepts/ileri-send-sync` · Çalıştır: `cargo run -p ileri-send-sync`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

## Neden bu bölüm?

Bir işi iki işçi arasında paylaştırmak istediğinde "bu veriyi öteki işçiye verebilir miyim?" sorusu ortaya çıkar. Rust bu soruyu çalışma anında denemek yerine, türün içindeki parçalara bakıp derleme anında yanıtlar. Bu bölümde o etiketlerin (Send, Sync) nereden geldiğini ve iç değişkenliğin tek yasal kapısı olan `UnsafeCell`'in neden kendi başına paylaşılamadığını görüyoruz.

## 5 yaşındaki çocuğa anlatır gibi

Bir kutuya "başka odaya götürülebilir" etiketi (Send) ya da "birden çok kişi aynı anda bakabilir" etiketi (Sync) yapıştırılır. Etiketi sen yazmazsın; kutunun içine bakıp öğretmen karar verir. İçinde boya olan kutu taşınabilir ama iki kişi aynı anda boyaya dokunmasın diye ikinci etiket verilmez.

## Konu anlatımı (madde madde)

1. **İç değişkenliğin (interior mutability) tek yasal temeli `UnsafeCell`'dir.** Normalde `&T` üzerinden veri değiştirilemez; derleyici "no-alias" varsayımıyla optimizasyon yapar. `UnsafeCell::get(&self) -> *mut T` bu garantiden muaf tutulan tek kapıdır; `Cell`, `RefCell`, `Mutex` ve atomikler onun üstüne kurulur.
   ↳ Kaynak: [Book ch15-05 — Interior Mutability](https://doc.rust-lang.org/book/ch15-05-interior-mutability.html) · [Nomicon — Aliasing](https://doc.rust-lang.org/nomicon/aliasing.html) · [rustc 1.99.1 — cell.rs:2313](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/cell.rs#L2313)

2. **Her sarmalayıcı, `UnsafeCell`'in üstüne kendi disiplinini ekler.** `Cell` `Copy` değerlerle değiştirir, `RefCell` borrow sayacı tutar (ihlali çalışma anında yakalar), `Mutex` erişimi kilitle serileştirir; hepsi aynı temeli paylaşır.
   ↳ Kaynak: [Book ch15-05 — Interior Mutability](https://doc.rust-lang.org/book/ch15-05-interior-mutability.html) · [Rustdoc — std::cell](https://doc.rust-lang.org/std/cell/) · [Book ch16-03 — Shared State](https://doc.rust-lang.org/book/ch16-03-shared-state.html)

3. **`Send` ve `Sync` auto-trait'tir; sen yazmazsın.** Derleyici türün tüm alanlarına bakar, uygunluk varsa otomatik ekler; tek bir uygunsuz alan bütün türü dışarıda bırakır. Bu "gizli söz" neredeyse her tipin parçasıdır (*Rust for Rustaceans*, Böl. 3).
   ↳ Kaynak: [Book ch16-04 — Sync and Send](https://doc.rust-lang.org/book/ch16-04-extensible-concurrency-sync-and-send.html) · [Rustdoc — Send](https://doc.rust-lang.org/std/marker/trait.Send.html) · [rustc 1.99.1 — marker.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/marker.rs)

4. **İki trait arasındaki bağ: `T: Sync ⇔ &T: Send`.** `Send`, değerin başka bir thread'e taşınabilir olduğunu; `Sync`, aynı değere birçok thread'in `&` ile bakabildiğini söyler. `Rc<T>` sayacı atomik olmadığı için ne `Send` ne `Sync`'tir; ham pointer (`*const T`, `*mut T`) taşıyan bir struct da `Send` olmaz.
   ↳ Kaynak: [Book ch16-04 — Sync and Send](https://doc.rust-lang.org/book/ch16-04-extensible-concurrency-sync-and-send.html) · [Rustdoc — Sync](https://doc.rust-lang.org/std/marker/trait.Sync.html) · [Reference — Ownership and Borrowing](https://doc.rust-lang.org/reference/ownership.html#borrowing)

5. **`UnsafeCell` tek başına `Sync` değildir.** std'de `impl<T: ?Sized> !Sync for UnsafeCell<T> {}` diye açık bir negatif impl vardır (cell.rs:2318); auto-trait "her şey Sync olurdu" diyecekken bu kayıt araya girer. Bu yüzden `Cell`/`RefCell` !Sync'tir ve örneğin `Arc<RefCell<T>>` thread'e geçmez (**E0277**); aksi hâlde iki thread aynı anda yazar ve veri yarışı olurdu.
   ↳ Kaynak: [cell.rs:2318](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/cell.rs#L2318) · [Rustdoc — RefCell](https://doc.rust-lang.org/std/cell/struct.RefCell.html)

6. **İçinde `UnsafeCell` olan bir tür yine de paylaşılabilir: `Mutex`.** std, `unsafe impl Sync for Mutex` ile "erişimi kilit serileştirir, yarış olmaz" sözünü verir; bu yüzden `Arc<Mutex<T>>` çalışır. Yani `UnsafeCell` içermek tek başına paylaşımı yasaklamaz, yalnızca ek bir güvenlik disiplini gerektirir.
   ↳ Kaynak: [Rustdoc — Mutex](https://doc.rust-lang.org/std/sync/struct.Mutex.html) · [rustc 1.99.1 — mutex.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/std/src/sync/poison/mutex.rs) · [Book ch16-03 — Shared State](https://doc.rust-lang.org/book/ch16-03-shared-state.html)

7. **`UnsafeCell`, `T` açısından invariant'tır.** Mutasyon içerdiği için içindeki ömür/tür esnetilemez (`#[rustc_assert_variance(invariant)]`); bu kuralın ayrıntısı ileri-variance bölümündedir.
   ↳ Kaynak: [Nomicon — Subtyping and Variance](https://doc.rust-lang.org/nomicon/subtyping.html) · [rustc 1.99.1 — cell.rs:2313](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/cell.rs#L2313)

8. **Üyelik testi derleme anında yapılır, kod çalıştırmaz.** `fn send_ister<T: Send>() {}` / `fn sync_ister<T: Sync>() {}` çağrısı derleniyorsa üyelik vardır; RfR'nin `is_normal<T: Send + Sync + Unpin>()` hilesi aynı fikirdir (*Rust for Rustaceans*, Böl. 3).
   ↳ Kaynak: [Rustdoc — Send](https://doc.rust-lang.org/std/marker/trait.Send.html) · [Rustdoc — Sync](https://doc.rust-lang.org/std/marker/trait.Sync.html)

9. **Public bir tipin private alanı sessizce üyeliği bozabilir.** Alan !Send olursa tipin kendisi de !Send olur; bu eski kodu derlenmez yapan kırıcı bir değişikliktir (semver). Bunu bir `#[test]` içinde üyelik testiyle erkenden yakalayabilirsin.
   ↳ Kaynak: [Reference — Visibility and Privacy](https://doc.rust-lang.org/reference/visibility-and-privacy.html) · [rustc 1.99.1 — marker.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/marker.rs)

## Kodda nasıl görünür?

```rust
use std::cell::UnsafeCell;

struct MiniCell<T> {
    v: UnsafeCell<T>,
}
impl<T: Copy> MiniCell<T> {
    fn yeni(v: T) -> MiniCell<T> {
        MiniCell { v: UnsafeCell::new(v) }
    }
    fn al(&self) -> T {
        unsafe { *self.v.get() }
    }
    fn yaz(&self, yeni: T) {
        unsafe { *self.v.get() = yeni } // &self ile mutasyon: UnsafeCell olmadan derlenmez
    }
}

fn send_ister<T: Send>() {}
fn sync_ister<T: Sync>() {}

fn main() {
    let c = MiniCell::yeni(5);
    let r1 = &c;
    let r2 = &c;                  // iki paylaşımlı referans
    r1.yaz(10);                   // paylaşımlı referansten YAZ (iç değişkenlik)
    println!("MiniCell: r1.yaz(10) sonrası r2.al() = {}", r2.al()); // 10

    send_ister::<i32>();
    sync_ister::<i32>();
    println!("i32: Send + Sync ✓ (sıradan değer)");

    send_ister::<MiniCell<i32>>();
    println!("MiniCell<i32>: Send ✓  (ama Sync değil — derleme-testi yorumda)");
    // sync_ister::<MiniCell<i32>>();  // ✗ DERLENMEZ: UnsafeCell !Sync → MiniCell !Sync
}
```

Buradaki `unsafe` genel bir çözüm önerisi değil, tek yasal kaçış kapısıdır: "aynı anda çakışan erişim olmayacak" garantisini `MiniCell` verir. `RefCell` bunu borrow sayacıyla, `Mutex` kilit ile denetler; kaynak koddaki `send_ister::<MiniCell<i32>>()` çağrısı yalnızca derleme anı üyelik testidir.

## Sık yapılan hatalar

| Kod / durum | Hata | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| `sync_ister::<RefCell<i32>>()`, `Arc<RefCell<T>>` thread'e geçirme | **E0277** | `UnsafeCell` !Sync → `RefCell` !Sync; `Mutex` ile sar ya da paylaşımı thread içinde tut. | [cell.rs:2318](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/cell.rs#L2318) |
| `send_ister::<Rc<i32>>()` | **E0277** | `Rc` sayacı atomik değil; thread'ler arası için `Arc` gerekir. | [Book ch16-03 — Shared State](https://doc.rust-lang.org/book/ch16-03-shared-state.html) |
| `*mut T` / `*const T` alan struct'ı thread'e taşıma | **E0277** | Ham pointer ne `Send` ne `Sync`'tir; tek alan bile tüm tipi dışarıda bırakır. | [Nomicon — What Unsafe Does](https://doc.rust-lang.org/nomicon/what-unsafe-does.html) |
| `impl Send` / `impl Sync` yazmaya çalışmak | derleme hatası | Bunlar auto-trait'tir; elle uygulama gerekiyorsa ancak gerekçesiyle `unsafe impl` yazılır. | [rustc 1.99.1 — marker.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/marker.rs) |

## Derleyici perspektifi

- `core/src/cell.rs` içindeki `UnsafeCell` no-alias varsayımını kaldırır; `get(&self) -> *mut T` paylaşımlı referanstan yazılabilir pointer üreten tek yasal yoldur ve tür `T`'de invariant tutulur.
  ↳ Kaynak: [rustc 1.99.1 — cell.rs:2313](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/cell.rs#L2313) · [Nomicon — What Unsafe Does](https://doc.rust-lang.org/nomicon/what-unsafe-does.html)

- Negatif impl `impl<T: ?Sized> !Sync for UnsafeCell<T> {}` (cell.rs:2318), `Cell`/`RefCell`'in !Sync olmasının kök sebebidir; ek eşzamanlama olmadan paylaşım derleme hatasına dönüşür (*Rust for Rustaceans*, Böl. 9 — UnsafeCell, Unsafe Code).
  ↳ Kaynak: [cell.rs:2318](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/cell.rs#L2318) · [Rustdoc — Sync](https://doc.rust-lang.org/std/marker/trait.Sync.html)

- Auto-trait'ler `core::marker`'da tanımlıdır; derleyici alanlara bakarak üyeliği otomatik verir ve `impl Trait`/closure gibi tür-silinmiş türlere de yayar (propagation).
  ↳ Kaynak: [rustc 1.99.1 — marker.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/marker.rs) · [Reference — Traits](https://doc.rust-lang.org/reference/items/traits.html)

- `Mutex`'in `unsafe impl Sync` sözü std'nin kilit modülündedir: erişim serileştirildiği için içindeki `UnsafeCell` güvenle paylaşılabilir.
  ↳ Kaynak: [rustc 1.99.1 — mutex.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/std/src/sync/poison/mutex.rs) · [Rustdoc — Mutex](https://doc.rust-lang.org/std/sync/struct.Mutex.html)

## Özet ve sonraki adım

- `UnsafeCell` iç değişkenliğin tek temeli; `Cell`/`RefCell`/`Mutex`/atomikler onun üzerine kurulu.
- `Send`/`Sync` auto-trait'tir: derleyici içeriğe bakar; `UnsafeCell` !Sync, ama `Mutex` gibi türler ek disiplinle paylaşılabilir.
- Üyelik derleme anında test edilir; bir private alanın üyeliği bozması kırıcı değişikliktir.

Sıradaki bölüm: [26. Silme Kontrolü (Drop Check)](26-dropck.md).
