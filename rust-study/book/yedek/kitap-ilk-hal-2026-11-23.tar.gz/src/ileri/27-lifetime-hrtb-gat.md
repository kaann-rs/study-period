# 27. İleri Lifetime, HRTB ve GAT

> Kaynak crate: `learn/advanced-concepts/ileri-lifetime-hrtb-gat` · Çalıştır: `cargo run -p ileri-lifetime-hrtb-gat`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

## Neden bu bölüm?

Bir biletin tarihini genelde sana veren kişi yazar; bazen de sen girişte tarihi seçersin ve görevli "hangi tarih olursa olsun kabulüm" der. Rust'ta lifetime etiketleri tam olarak bu "kim seçer" sorusunu taşır. Bu bölümde iki süre arasındaki ilişkiyi ne zaman elle yazacağını, `for<'a>`'nın hangi yönü tersine çevirdiğini ve GAT'ın bir ilişkili türe her kullanımda yeni bir süre hanesi eklediğini görüyoruz.

## 5 yaşındaki çocuğa anlatır gibi

Bir kural düşün: "bu bilet bugün geçerli". Normalde bileti veren kişi tarihi yazar. Bazen de sen girişte tarihi seçersin ve görevli "hangi tarih olursa olsun kabulüm" der. Bazen de biletin içindeki koltuk numarası her seferinde farklı olur; ona ayrı bir kutu gerekir.

## Konu anlatımı (madde madde)

1. **Bağımsız yaşayan veriye bağımsız etiketler ver.** `struct Arayici<'m, 'k> { metin: &'m str, kelime: &'k str }` içinde sonuç yalnızca `metin`'e bağlıdır; tek `'a` kullanılsaydı covariance iki süreyi ortak kısa süreye indirger ve sonuç gereksiz yere `kelime`'ye de bağlanırdı (**E0597**).
   ↳ Kaynak: [Book ch10-03 — Lifetime Syntax](https://doc.rust-lang.org/book/ch10-03-lifetime-syntax.html) · [Nomicon — Subtyping and Variance](https://doc.rust-lang.org/nomicon/subtyping.html)

2. **`'uzun: 'kisa` bir kapsama sözüdür.** "'uzun, 'kisa bitmeden bitmez" demektir; iki farklı süreli referanstan birini döndüren `bos_ise_varsayilan<'kisa, 'uzun: 'kisa>` imzasında bu söz olmadan derleyici `lifetime may not live long enough` verir ve genellikle eksik bound'u `help` ile söyler.
   ↳ Kaynak: [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html) · [Book ch10-03 — Lifetime Syntax](https://doc.rust-lang.org/book/ch10-03-lifetime-syntax.html)

3. **`T: 'a`, T'nin içindeki tüm referanslar en az `'a` kadar yaşar demektir.** `Box<dyn Debug + 'a>` döndürürken `T: 'a` eksikse **E0309** çıkar; `&'a T` alan struct'larda derleyici bunu alan türünden çıkarır (implied bounds). `T: 'static` "sonsuza dek yaşar" değil, "geçici hiçbir şeye borçlu değil" anlamına gelir; `String` bu şartı sağlar.
   ↳ Kaynak: [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html) · [Rustdoc — Box](https://doc.rust-lang.org/std/boxed/struct.Box.html)

4. **`&mut` arkındaki tür invarianttır.** `sakla<'a>(liste: &mut Vec<&'a str>, s: &'a str)` imzasında iki yere aynı `'a` yazılır: içine yazılabildiği için eklenen referans, listedekilerle tam aynı süreye uymak zorundadır; yoksa `lifetime may not live long enough` alınır.
   ↳ Kaynak: [Nomicon — Subtyping and Variance](https://doc.rust-lang.org/nomicon/subtyping.html) · [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html)

5. **Kritik ayrım — süreyi kim seçer? `fn f<'a>(..)` dersen `'a`'yı çağıran seçer** ve gövde içinde o süre sabittir. `F: for<'a> Fn(&'a T)` dersen süreyi `F`'yi çağıran (yani gövdenin içinden biz) seçeriz; **F her süreye razı olmak zorundadır**. HRTB bu yönü tersine çevirmenin sözdizimidir (*Rust for Rustaceans*, Böl. 1–2).
   ↳ Kaynak: [Nomicon — Higher-Rank Trait Bounds](https://doc.rust-lang.org/nomicon/hrtb.html) · [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html)

6. **Fonksiyonun içinde üretilen veri için `for<'a>` gerekir.** `fn uygula<'a, F: Fn(&'a str) -> &'a str>` ile `'a`'yı çağıran seçer; `yerel` ise fonksiyon çağrılmadan önce yoktur, bu yüzden **E0597** çıkar. `F: for<'a> Fn(&'a str) -> &'a str` çalışır; üstelik `Fn(&str) -> &str` yazdığında derleyici bu HRTB'yi kendiliğinden ekler — iki imza birebir aynıdır.
   ↳ Kaynak: [Book ch20-04 — Advanced Functions and Closures](https://doc.rust-lang.org/book/ch20-04-advanced-functions-and-closures.html) · [Nomicon — Higher-Rank Trait Bounds](https://doc.rust-lang.org/nomicon/hrtb.html)

7. **`let` ile tanımlı closure'da dönüş elision'ı işlemez.** Derleyici girdi ve çıktıya iki ayrı süre verip bağ kurmaz; doğrudan HRTB bekleyen parametreye yazılırsa beklenen imzadan öğrenir, yoksa `imza_dayat` gibi bir kimlik fonksiyonuyla imzayı dayatmak gerekir. Fonksiyon işaretçisinde de aynı eşitlik geçerlidir: `fn(&str) -> &str` = `for<'a> fn(&'a str) -> &'a str`.
   ↳ Kaynak: [Book ch20-04 — Advanced Functions and Closures](https://doc.rust-lang.org/book/ch20-04-advanced-functions-and-closures.html) · [rustc 1.99.1 — upvar.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_hir_typeck/src/upvar.rs)

8. **HRTB yalnız `Fn` için değildir.** serde'nin `DeserializeOwned = for<'de> Deserialize<'de>` sözü "her girdi süresi için çözülebilen", yani girdiye ödünç bağlanmayan türleri anlatır. Kaynak crate'deki `T: for<'g> Coz<'g>` modeli aynı şeyi yapar; ihlal edildiğinde `implementation of X is not general enough` hatası (E-kodsuz) çıkar ve neredeyse her zaman bir `for<'a>` bound'ına işaret eder.
   ↳ Kaynak: [Reference — Traits](https://doc.rust-lang.org/reference/items/traits.html) · [Nomicon — Higher-Rank Trait Bounds](https://doc.rust-lang.org/nomicon/hrtb.html)

9. **GAT, ilişkili türe kendi süre hanesini ekler.** `Iterator::Item`, `&mut self`'in süresine bağlı olmadığı için örtüşen değiştirilebilir pencereler (`windows_mut`) yazılamaz; `type Oge<'a> where Self: 'a` ve `fn sonraki<'a>(&'a mut self) -> Option<Self::Oge<'a>>` ile öğe bu çağrının ödüncü kadar yaşar ve öğe elindeyken iterator kilitli kalır (aksi hâlde **E0499**).
   ↳ Kaynak: [Reference — Traits](https://doc.rust-lang.org/reference/items/traits.html) · [Rustdoc — Iterator](https://doc.rust-lang.org/std/iter/trait.Iterator.html)

10. **GAT tür parametresi de alabilir: `type Isaretci<T>`.** Bu, `Rc<_>` ya da `Arc<_>` gibi henüz doldurulmamış bir tür ailesini tek bound ile soyutlar; aynı `Belge` kodu tek thread'de `RcAilesi`, çok thread'de `ArcAilesi` ile kullanılır ve auto-trait'ler alan türünden çıkar. Ödünç veren iterator'lar `for`/`collect` zincirlerini kullanamaz ve GAT'lı trait'ler dyn-uyumlu değildir (**E0038**).
    ↳ Kaynak: [Reference — Traits](https://doc.rust-lang.org/reference/items/traits.html) · [Rustdoc — Send](https://doc.rust-lang.org/std/marker/trait.Send.html)

## Kodda nasıl görünür?

```rust
struct Arayici<'m, 'k> {
    metin: &'m str,
    kelime: &'k str,
}
impl<'m, 'k> Arayici<'m, 'k> {
    fn eslesmeler(&self) -> Vec<&'m str> {
        self.metin
            .match_indices(self.kelime)
            .map(|(i, _)| &self.metin[i..i + self.kelime.len()])
            .collect()
    }
}

fn bos_ise_varsayilan<'kisa, 'uzun: 'kisa>(
    girdi: &'kisa str,
    varsayilan: &'uzun str,
) -> &'kisa str {
    if girdi.trim().is_empty() {
        varsayilan
    } else {
        girdi
    }
}

// Fn(&str) -> &str  ≡  for<'a> Fn(&'a str) -> &'a str
fn satirlari_donustur<F>(ham: &str, donustur: F) -> Vec<String>
where
    F: for<'a> Fn(&'a str) -> &'a str,
{
    ham.lines()
        .map(|satir| {
            let buyuk = satir.to_uppercase(); // her turda YENİ, kısa ömürlü String
            donustur(&buyuk).to_string()
        })
        .collect()
}

fn imza_dayat<F: for<'a> Fn(&'a str) -> &'a str>(f: F) -> F {
    f
}

trait OduncVerenIterator {
    type Oge<'a>
    where
        Self: 'a;
    fn sonraki<'a>(&'a mut self) -> Option<Self::Oge<'a>>;
}
```

## Sık yapılan hatalar

| Kod / mesaj | Hata | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| Sonuç kısa ömürlü `kelime`'ye de bağlanıyor | **E0597** | Tek `'a` yerine `'m`, `'k` gibi bağımsız etiketler kullan ya da sahipli değere geç. | [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs) |
| `Box<dyn Debug + 'a>` döndüren `fn kutula<'a, T: Debug>` | **E0309** | `T: 'a` bound'u eksik; T'nin içindeki referanslar en az `'a` kadar yaşamalı. | [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html) |
| `'a` kullanılmış ama bildirilmemiş | **E0261** | `fn f<'a>` / `impl<'a>` ekle. | [Book ch10-03 — Lifetime Syntax](https://doc.rust-lang.org/book/ch10-03-lifetime-syntax.html) |
| Önceki öğeyi bırakmadan `sonraki()` çağrısı | **E0499 / E0502** | Öğe `&mut self`'e bağlı; `while let` ile her turda düşür, ya da örtüşmüyorsa `chunks_mut` kullan. | [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs) |
| `&dyn OduncVerenIterator` | **E0038** | GAT'lı trait'ler dyn-uyumlu değildir. | [Reference — Traits](https://doc.rust-lang.org/reference/items/traits.html) |
| `implementation of X is not general enough` | kodsuz | `for<'a>` istenmiş, elindeki impl yalnız belirli bir süre için; sahipli türe geç ya da tamponu çağıranda tut. | [Nomicon — Higher-Rank Trait Bounds](https://doc.rust-lang.org/nomicon/hrtb.html) |
| `missing required bound on Oge` | kodsuz | GAT bildiriminde `where Self: 'a` eksik. | [Reference — Traits](https://doc.rust-lang.org/reference/items/traits.html) |
| `lifetime may not live long enough` (notta "invariant") | kodsuz | `&mut`/`Cell` ardındaki bir lifetime esnetilemiyor; imzada süreleri eşitle (bölüm 1d). | [Nomicon — Subtyping and Variance](https://doc.rust-lang.org/nomicon/subtyping.html) |

## Derleyici perspektifi

- Erken ve geç bağlanan lifetime'lar: `fn f<'a>(x: &'a str)` içindeki `'a`, fonksiyon bir değer olarak kullanıldığında bile her çağrıda yeniden seçilir (*late-bound*); bu yüzden `f`, `for<'a> Fn(&'a str)` bound'unu tek başına sağlar. HRTB bu özelliği closure'lar ve trait bound'ları için yazılabilir kılar.
  ↳ Kaynak: [Nomicon — Higher-Rank Trait Bounds](https://doc.rust-lang.org/nomicon/hrtb.html) · [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html)

- `for<'a>` yalnızca lifetime üzerinde niceler; "her T türü için" diyen `for<T>` kararlı Rust'ta yoktur. Generic bir closure parametresi yazılamaz; onun yerine generic metotlu bir trait tanımlanır.
  ↳ Kaynak: [Reference — Traits](https://doc.rust-lang.org/reference/items/traits.html) · [Book ch20-02 — Advanced Traits](https://doc.rust-lang.org/book/ch20-02-advanced-traits.html)

- GAT 1.65'ten beri kararlıdır; çözümleyici `<I as OduncVerenIterator>::Oge<'a>`'yı her `'a` için ayrı bir projeksiyon olarak ele alır. `where Self: 'a` zorunluluğu, ileride varsayılan hâle getirilebilmesi için konmuş geçici bir kuraldır (*Rust for Rustaceans*, Böl. 1–2).
  ↳ Kaynak: [Reference — Traits](https://doc.rust-lang.org/reference/items/traits.html) · [rustc 1.99.1 — probe.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_hir_typeck/src/method/probe.rs)

- Hepsi derleme anındadır: lifetime'lar, `for<'a>` ve GAT'ın süre parametreleri kod üretiminden önce silinir (*erasure*); çalışma anında ek bir kontrol eklenmez. Kazanım hız değil, yanlış kullanımın derlenmemesidir.
  ↳ Kaynak: [Book ch10-03 — Lifetime Syntax](https://doc.rust-lang.org/book/ch10-03-lifetime-syntax.html) · [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html)

## Özet ve sonraki adım

- Bağımsız veriye bağımsız etiket; `'a: 'b` ve `T: 'a` ilişkiyi yazmanın yolları; `&mut` ardındaki süre invarianttır.
- `fn f<'a>`'da süreyi çağıran seçer ve gövde içinde sabittir; `for<'a>`'da süreyi çağıran taraf (biz) seçer ve **F her süreye razıdır**.
- GAT ilişkili türe süre/tür hanesi ekler; ödünç veren iterator ve tür ailesi bu sayede yazılabilir, ama dyn-uyumu yoktur.

Sıradaki bölüm: [28. Future'ın İç Yüzü](28-future.md).
