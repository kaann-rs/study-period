# 29. İleri Eşzamanlılık ve Async

> Kaynak crate: `learn/advanced-concepts/ileri-eszamanlilik-async` · Çalıştır: `cargo run -p ileri-eszamanlilik-async` · Test: `cargo test -p ileri-eszamanlilik-async`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

## Neden bu bölüm?

Önceki crate'ler parçaları tek tek kurdu: thread'ler, kanallar, kilitler, Future ve elle executor. Burada aynı araçlara üretim gözüyle bakıyoruz: doğru kilidi seçmek, deadlock'u tasarımla önlemek, beklerken işlemciyi yakmamak ve bir çalışma zamanının binlerce görevden yalnızca uyandırılanı poll etmesini anlamak. Thread'ler ve async görevler aynı soruya iki farklı cevaptır.

## 5 yaşındaki çocuğa anlatır gibi

Mutfafta aşçılar (thread) ve tek bir kasiyer (async) var. Kasiyer sipariş beklerken boş durmaz; zil çalan masaya gider. Herkes aynı tencereye el atmasın diye kilit koyar ve hep aynı sırayla kilitlersin; yoksa iki aşçı birbirini bekler, yemek hiç pişmez.

## Konu anlatımı (madde madde)

1. **Aynı soruya iki cevap: "beklerken ne yapalım?"** Thread tarafında işletim sistemi thread'i uyutur, başkasını koşturur; her bekleyen iş bir yığın belleği ve bağlam değişimi demektir. Async tarafında görev `Pending` deyip thread'i geri verir; birkaç işçi on binlerce bekleyen işi taşır, ama bloklayan tek görev herkesi durdurur.
   ↳ Kaynak: [Book ch16-00](https://doc.rust-lang.org/book/ch16-00-concurrency.html) · [Book ch17-00](https://doc.rust-lang.org/book/ch17-00-async-await.html) · RfR Böl. 8 ve Böl. 10

2. **Müfredat Böl. 16/17 burada üretim sorularına bağlanır.** `learn/concurrency` (müfredat Böl. 16) thread, kanal, `Arc<Mutex>`, `scope` ve işçi havuzunu; `learn/async-await` (müfredat Böl. 17) Future, elle executor, `join` ve Pin'in gündelik yüzünü kurdu. Bu 16/17 numaraları RfR bölüm numarası değil, **müfredatın kendi etiketleridir**; RfR tarafında ilgili bölümler Böl. 8 ve Böl. 10'dur.
   ↳ Kaynak: [Book ch16-00](https://doc.rust-lang.org/book/ch16-00-concurrency.html) · [Book ch17-00](https://doc.rust-lang.org/book/ch17-00-async-await.html) · RfR Böl. 8 ve Böl. 10

3. **RwLock: çok okuyucu ya da tek yazar.** `read()` `&T` gibi, `write()` `&mut T` gibi davranır; borrow kuralının thread'ler arası karşılığıdır. Kritik bölge çok kısaysa, yazma sık ise ya da `T: Sync` değilse Mutex daha iyi; RwLock'da okuma kilidini yazmaya yükseltme yoktur.
   ↳ Kaynak: [Rustdoc — std::sync::RwLock](https://doc.rust-lang.org/std/sync/struct.RwLock.html) · [Book ch16-03](https://doc.rust-lang.org/book/ch16-03-shared-state.html)

4. **Condvar: "koşul olunca beni uyandır" zili.** `wait(guard)` kilidi bırakıp uyumayı atomik yapar; `wait_while` koşulu döngüde denetleyerek spurious wakeup ve kayıp uyandırmayı (lost wakeup) önler. Sınırlı kuyrukta kapasite dolunca üretici de bekler — buna geri basınç (backpressure) denir; kapanış bildirimi `notify_all` olmalıdır.
   ↳ Kaynak: [Rustdoc — std::sync::Condvar](https://doc.rust-lang.org/std/sync/struct.Condvar.html) · [Rustdoc — Condvar::wait_while](https://doc.rust-lang.org/std/sync/struct.Condvar.html#method.wait_while)

5. **Deadlock'u derleyici yakalamaz; çözüm bir tasarım kuralıdır.** Thread 1 A'yı, Thread 2 B'yi kilitleyip ötekini beklediğinde döngüsel bekleme oluşur. Banka transferinde sıra yöne göre değil hesap numarasına göre belirlenir; diğer savunmalar tek kilit, `try_lock` + geri çekilme, kilit altında yabancı kod çağırmamak ve mesajlaşmaya geçmektir.
   ↳ Kaynak: [Book ch16-03](https://doc.rust-lang.org/book/ch16-03-shared-state.html) · [Rustdoc — std::sync::Mutex](https://doc.rust-lang.org/std/sync/struct.Mutex.html) · Rust Atomics and Locks

6. **Atomikler: tek hamlede oku–karar ver–yaz.** `compare_exchange(beklenen, yeni)` "değer hâlâ beklediğim gibiyse değiştir" der; bağımsız sayaç için `Relaxed`, başka veriyi yayımlamak için `Acquire`/`Release`, emin değilsen `SeqCst`. Yanlış zayıflatılmış bir `Ordering` çoğu x86 makinesinde "çalışıyor" görünür, ARM'da bozulur; ölçmeden zayıflatma.
   ↳ Kaynak: [Rustdoc — std::sync::atomic::Ordering](https://doc.rust-lang.org/std/sync/atomic/enum.Ordering.html) · [Nomicon — Atomics](https://doc.rust-lang.org/nomicon/) · Rust Atomics and Locks

7. **Send/Sync tablosunun en öğretici satırı Mutex/RwLock farkıdır.** `Mutex<Cell<u8>>` Sync'tir çünkü erişimi teke indirir; `RwLock<Cell<u8>>` Sync değildir çünkü iki okuyucu aynı `Cell`'e yazabilir. `MutexGuard` kilit alan thread'de bırakılmalı (!Send), `mpsc::Sender<T>` ise `T: Send` olduğunda hem Send hem Sync'tir.
   ↳ Kaynak: [Book ch16-04](https://doc.rust-lang.org/book/ch16-04-extensible-concurrency-sync-and-send.html) · [Reference — auto traits](https://doc.rust-lang.org/reference/) · [rustc 1.99.1 — mutex.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/std/src/sync/poison/mutex.rs)

8. **Runtime yalnız uyandırılan görevleri yoklar.** Böl. 17'nin basit executor'u her turda bütün future'ları yoklardı; mini runtime'da `Gorev`, hazır kuyruğu, `Calistirici` ve `Baslatici` var. `baslat` ≈ `spawn`, `Tutamac` ≈ `JoinHandle`; future tembeldir, kuyruğa girmeyen görev hiç başlamaz.
   ↳ Kaynak: [Book ch17-03](https://doc.rust-lang.org/book/ch17-03-more-futures.html) · [Rustdoc — std::sync::mpsc](https://doc.rust-lang.org/std/sync/mpsc/index.html)

9. **Kayıp uyandırma aynı invariantla önlenir: denetim + waker kaydı tek kilit altında.** `Tutamac::poll` "sonuç var mı?" sorusu ile waker'ı kaydetmeyi aynı `Mutex` içinde yapar. İki ayrı adım olsaydı bildirim araya kaçar, görev sonsuza dek `Pending` kalırdı — tıpkı Condvar'daki lost wakeup gibi.
   ↳ Kaynak: [Rustdoc — Future::poll, Return value](https://doc.rust-lang.org/std/future/trait.Future.html#return-value) · [Rustdoc — std::sync::Condvar](https://doc.rust-lang.org/std/sync/struct.Condvar.html)

10. **Yaprak future ve zamanlayıcı: waker her poll'da güncellenir.** `Uyku` ilk poll'da yardımcı thread kurar, waker'ı olayı bilecek tarafa teslim eder ve `Pending` döner; süre dolunca `wake()` görevi kuyruğa geri koyar. Eski waker'ı uyandırmak işe yaramaz, çünkü görev araya başka bir waker'la poll edilmiş olabilir; üretim runtime'ları OS olay bildirimi (epoll/kqueue/IOCP) kullanır.
    ↳ Kaynak: [Rustdoc — Future::poll, Return value](https://doc.rust-lang.org/std/future/trait.Future.html#return-value) · [Rustdoc — std::thread::sleep](https://doc.rust-lang.org/std/thread/fn.sleep.html) · RfR Böl. 8

11. **İptal = future'ı düşürmek; Pin ve Send sınırları burada birleşir.** `ZamanAsimi` iç future'ı kutuya alır; süre dolunca struct düşer ve iş iptal olur — ayrı bir "cancel" çağrısı yoktur. Bir birleştiricinin `Pin<&mut alan>` üretmesi için `Pin::new` yalnız `Unpin` türlerde derlenir (**E0277**: `cannot be unpinned`); async blokların future'ları `!Unpin`'dir, güvenli yollar `pin!`, `Box::pin` ya da pin-projeksiyonu makrosudur. Waker `Send + Sync` olduğu için görev future'ı `Mutex` ardında tutar ve `baslat` `F: Send + 'static` ister.
    ↳ Kaynak: [Rustdoc — std::pin::Pin](https://doc.rust-lang.org/std/pin/struct.Pin.html) · [rustc 1.99.1 — wake.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/task/wake.rs) · [Reference — traits](https://doc.rust-lang.org/reference/items/traits.html) · RfR Böl. 8 ve Böl. 10

## Kodda nasıl görünür?

`learn/advanced-concepts/ileri-eszamanlilik-async/src/main.rs` dosyasından alınan kısa kesit. `println!` başlıkları kaynaktaki hâliyle korunmuştur.

```rust
mod calisma_zamani;
mod istemci;
mod threadler;

fn main() {
    println!("######## A) İLERİ EŞZAMANLILIK (thread'ler) ########");
    threadler::calistir();

    println!("\n######## B) MİNİ ASYNC ÇALIŞMA ZAMANI ########");
    calisma_zamani_tanitimi();

    println!("\n######## C) UYGULAMA: API İSTEMCİSİ ve YAYGIN HATALAR ########");
    istemci::calistir();
}

fn calisma_zamani_tanitimi() {
    use calisma_zamani::{Calistirici, uyu_ms};

    let mut calistirici = Calistirici::yeni();
    let baslatici = calistirici.baslatici();
    let ic_baslatici = baslatici.clone();

    let kok = baslatici.baslat(async move {
        let yavas = ic_baslatici.baslat(async {
            uyu_ms(30).await;
            "yavaş görev (30 ms)"
        });
        let hizli = ic_baslatici.baslat(async {
            uyu_ms(10).await;
            "hızlı görev (10 ms)"
        });
        [yavas.await, hizli.await]
    });

    let poll_sayisi = calistirici.calistir();
    println!("   sonuçlar = {:?}", kok.sonucu_al().unwrap());
    println!("   toplam poll = {poll_sayisi} (3 görev; yalnız uyandırılan poll edildi)");
}
```

Toplam poll sayısı 6'dır: kök 2 (ilk poll + yavaş görev bitince), yavaş 2, hızlı 2. `hizli` bittiğinde kökü uyandırmaz, çünkü kök o sırada `hizli`'yi değil `yavas`'ı beklemektedir; 40 ms boyunca çalıştırıcı thread'i kanal `recv()` içinde uykudadır.

↳ Kaynak: [Rustdoc — std::sync::mpsc](https://doc.rust-lang.org/std/sync/mpsc/index.html) · [Rustdoc — Future::poll](https://doc.rust-lang.org/std/future/trait.Future.html#the-poll-method)

## Sık yapılan hatalar

| Hata | Belirti | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| Okuma guard'ı elindeyken `write()` istemek | Derlenir; thread kendi kendini bekler | RwLock yükseltme yapmaz; guard'ı bırak, koşulu kilit altında yeniden denetle. | [Rustdoc — RwLock](https://doc.rust-lang.org/std/sync/struct.RwLock.html) |
| `sync_ister::<RwLock<Cell<u8>>>()` | **E0277** | İki okuyucu aynı `Cell`'e yazabilir; `Mutex<Cell<u8>>` kullan. | [Reference — traits](https://doc.rust-lang.org/reference/items/traits.html) |
| `Pin::new(&mut self.ic)` ile `!Unpin` alan | **E0277** (`cannot be unpinned`) | `Box::pin`, `pin!` ya da pin-projeksiyonu kullan. | [Rustdoc — Pin](https://doc.rust-lang.org/std/pin/struct.Pin.html) |
| Koşulu `wait` döngüsü dışında denetlemek | Spurious wakeup / kayıp uyandırma | `wait_while` kullan; koşulu değiştiren taraf kilit altında bildirsin. | [Rustdoc — Condvar](https://doc.rust-lang.org/std/sync/struct.Condvar.html) |
| `Ordering::Relaxed` ile veri yayımlamak | x86'da görünmez, ARM'da bozulur | Bayrak/işaretçi için Acquire/Release; ölçmeden zayıflatma. | [Rustdoc — Ordering](https://doc.rust-lang.org/std/sync/atomic/enum.Ordering.html) |

↳ Kaynak: [Book ch16-03](https://doc.rust-lang.org/book/ch16-03-shared-state.html) · [Rustdoc — std::sync::atomic::Ordering](https://doc.rust-lang.org/std/sync/atomic/enum.Ordering.html)

## Derleyici perspektifi

- Mutex/RwLock/Condvar birer kütüphane türüdür; derleyicinin kilitlerden haberi yoktur. Güvenlik şu iki mekanizmadan gelir: veriye yalnız guard üzerinden erişim (RAII + borrow checker) ve hangi türün thread sınırını geçebileceğini belirleyen `Send`/`Sync` auto-trait'leri.
  ↳ Kaynak: [Book ch16-04](https://doc.rust-lang.org/book/ch16-04-extensible-concurrency-sync-and-send.html) · [Reference — auto traits](https://doc.rust-lang.org/reference/)

- `Ordering` işlemciye/derleyiciye verilmiş bir izindir; daha zayıf sıralama daha fazla yeniden sıralama özgürlüğü demektir. Bu sınıf hatalar testle bulunmaz.
  ↳ Kaynak: [Rustdoc — std::sync::atomic::Ordering](https://doc.rust-lang.org/std/sync/atomic/enum.Ordering.html) · [Nomicon](https://doc.rust-lang.org/nomicon/)

- `async fn` → state machine. Makine bir await noktasında canlı olan her yereli alan olarak saklar; `Send`, `Sync`, `Unpin` auto-trait'leri bu alanlardan türetilir. "future is not Send" hatasının kaynağı budur; çözüm sorunlu değeri await'ten önce düşürmektir.
  ↳ Kaynak: [Reference — async bloklar](https://doc.rust-lang.org/reference/) · [Book ch17-03](https://doc.rust-lang.org/book/ch17-03-more-futures.html)

- Waker `Send + Sync` olmak zorundadır (her thread'den uyandırılabilmeli); bu yüzden `std::task::Wake`, `Arc<W: Send + Sync>` ister ve görev future'ı bir `Mutex`'in ardında tutar. Tek thread'li runtime'lar `!Send` future'ları da koşturabilir; bedeli görevlerin o thread'den hiç ayrılamamasıdır.
  ↳ Kaynak: [Rustdoc — std::task::Waker](https://doc.rust-lang.org/std/task/struct.Waker.html) · [rustc 1.99.1 — wake.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/task/wake.rs)

- Pin bir işaretçi sarmalayıcısıdır, veri özelliği değil: `Pin<&mut T>` "bu T bir daha taşınmayacak" sözüdür. `T: Unpin` ise söz boştur; async blokların future'ı `!Unpin`'dir.
  ↳ Kaynak: [Rustdoc — std::pin::Pin](https://doc.rust-lang.org/std/pin/struct.Pin.html) · [rustc 1.99.1 — future.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/future/future.rs)

- Gerçek runtime'lar bu iskeletin üstüne çok thread'li iş çalma (work stealing) kuyruğu, OS olay bildirimiyle bütünleşik G/Ç, tek bir zamanlayıcı, adil zamanlama ve iptal güvenliği yardımcıları ekler; kavramlar (görev, waker, kuyruk, yaprak future) aynıdır.
  ↳ Kaynak: [Rustdoc — std::task::Waker](https://doc.rust-lang.org/std/task/struct.Waker.html) · RfR Böl. 8 ve Böl. 10

## Özet ve sonraki adım

- "Beklerken ne yapalım?" sorusunun iki cevabı vardır; thread tarafı doğru kilit, koşul bekleme, kilit sıralaması ve atomik ister.
- Async tarafı yalnız uyandırılan görevleri poll eder; kuyruk, spawn, zamanlayıcı ve zaman aşımı bu döngünün parçalarıdır.
- Müfredat Böl. 16/17 etiketleri kurs numaralarıdır; RfR tarafında konular Böl. 8 ve Böl. 10'dadır.

Sıradaki sayfalar bu üç katmanı ayrı ayrı açar: [29.1 Thread'ler ve Zamanlayıcı](29-threadler.md), ardından [29.2 Çalışma Zamanı: Görev Kuyruğu ve Backpressure](29-calisma-zamani.md) ve [29.3 Asenkron API İstemcisi](29-istemci.md). Serinin sonunda [Kaynaklar ve doğruluk notu](../kaynaklar.md) gelir.
