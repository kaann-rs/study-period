# 29.2 Çalışma Zamanı: Görev Kuyruğu ve Backpressure

> Kaynak dosya: `learn/advanced-concepts/ileri-eszamanlilik-async/src/calisma_zamani.rs` · Test: `cargo test -p ileri-eszamanlilik-async`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

29. bölümün B katmanı: bir async çalışma zamanı gerçekte ne yapar? Kaynak `calisma_zamani.rs` yorumları; kavramsal arka plan RfR Böl. 8 ve müfredat Böl. 17'dir (kursun kendi numarası).

## Neden bu sayfa?

Böl. 17'nin executor'u tek kök future'ı döngüde poll eder, "çok görev"i de her turda hepsini yoklayarak yürütürdü. Gerçek bir runtime böyle çalışmaz: binlerce görevden yalnız **uyandırılan** poll edilir. Bunun için üç parça yeter: görev (future + kuyruğa dönme bilgisi), çalıştırıcı (hazır kuyruğundan alır) ve olay kaynağı (zamanlayıcı/G/Ç). Sınırlı kuyruğun üreticiye geri basınç uygulaması 29.1'de görülmüştü; burada kuyruğa yalnız hazır görevlerin girmesi, bekleyen görevin tekrar tekrar poll edilmemesi aynı disiplinin görev düzeyindeki karşılığıdır.

## B1) Görev ve Waker

1. **Görev, türü silinmiş ve sabitlenmiş bir future + kuyruk göndericisidir.** `KutuluGorev = Pin<Box<dyn Future<Output = ()> + Send>>`: `dyn` farklı async bloklarının aynı kuyruğa girmesini, `Pin` poll edilebilmeyi, `Box` ise taşınırken içteki future'ın adresinin değişmemesini sağlar. `gelecek: Mutex<Option<...>>` içindeki `Option`, bitmiş bir göreve gecikmiş `wake()` gelse bile onu yeniden poll etmeyi engeller.
   ↳ Kaynak: [Rustdoc — std::boxed::Box::pin](https://doc.rust-lang.org/std/boxed/struct.Box.html#method.pin) · [Reference — trait objects](https://doc.rust-lang.org/reference/items/traits.html) · RfR Böl. 8

2. **Uyandırmak, görevi hazır kuyruğuna geri koymaktır.** `impl Wake for Gorev` içinde `kuyruk.send(self)` yeterli; alıcı kapanmışsa gönderim başarısız olur ve uyandıracak kimse de yoktur. Ham vtable yazmak yerine `std::task::Wake` kullanılır (Waker'ın "bir trait object *gibidir*" olduğu ve `RawWakerVTable` nitelendirmesi 28. bölümde açıklandı).
   ↳ Kaynak: [Rustdoc — std::task::Wake](https://doc.rust-lang.org/std/task/trait.Wake.html) · [rustc 1.99.1 — wake.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/task/wake.rs)

## B2) Çalıştırıcı ve Başlatıcı

3. **`baslat`ın bound'ları tasarım kararlarıdır: `F: Future + Send + 'static`.** Görev, Waker aracılığıyla başka thread'lerden erişilebilen bir `Arc`'ın içinde durur (`Send`); başlatan fonksiyondan uzun yaşayabilir (`'static`), bu yüzden yerel değişken ödünç alamaz — `async move` ile sahiplenilir. `'static` burada "sonsuza dek yaşar" değil, "geçici hiçbir şeye borçlu değil" demektir.
   ↳ Kaynak: [Reference — traits](https://doc.rust-lang.org/reference/items/traits.html) · [Rustdoc — std::thread::spawn](https://doc.rust-lang.org/std/thread/fn.spawn.html) · [Book ch16-01](https://doc.rust-lang.org/book/ch16-01-threads.html)

4. **Future tembeldir; kuyruğa girmeyen görev hiç başlamaz.** `baslat` sonucu `Tutamac`'a yazar, bekleyen varsa waker'ı kilit **dışında** uyandırır, `canli` sayacını artırır ve ilk poll için görevi kuyruğa koyar. `Calistirici::calistir` `recv()` ile bekler; hazır görev yoksa thread uyur, `Pending` gelen görev yerine konur, `Ready` gelen ise sayacı düşürür. Waker'ını kaydetmeden `Pending` dönen bir görev burada çalıştırıcıyı sonsuza dek uyutabilir. Sınır: sayaç 0'a inip döngü çıktıktan sonra başka thread'den başlatılan görev poll edilmez.
   ↳ Kaynak: [Rustdoc — std::sync::mpsc::Receiver](https://doc.rust-lang.org/std/sync/mpsc/struct.Receiver.html) · [Rustdoc — Future::poll, Return value](https://doc.rust-lang.org/std/future/trait.Future.html#return-value)

## B3) Tutamac — JoinHandle

5. **Tutamac hem sonuç kutusu hem Future'dır.** Çalıştırıcı durduktan sonra async bağlam dışında `sonucu_al()` ile okunur; bir görevin içinde `tutamac.await` ile beklenir. Sarıcı `async move`, asıl future bitince sonucu yazar ve tutamacı bekleyen görevi uyandırır.
   ↳ Kaynak: [Rustdoc — std::future::Future](https://doc.rust-lang.org/std/future/trait.Future.html) · [Rustdoc — std::sync::Mutex](https://doc.rust-lang.org/std/sync/struct.Mutex.html)

6. **"Hazır mı?" denetimi ile waker kaydı aynı kilit altında yapılır.** İki ayrı adım olsaydı: sonuç yok denir, görev tam o anda bitip `bekleyen`'e bakar (boş), sonra biz waker'ı kaydederiz — artık kimse çağırmaz ve görev sonsuza dek `Pending` kalır. Bu kayıp uyandırma, Condvar'daki ile aynı hatadır. Örnekte toplam poll 6'dır: kök 2, yavaş 2, hızlı 2; hızlı görev bitince kök uyanmaz, çünkü o sırada yavaşı beklemektedir.
   ↳ Kaynak: [Rustdoc — Future::poll, Return value](https://doc.rust-lang.org/std/future/trait.Future.html#return-value) · [Rustdoc — std::sync::Condvar](https://doc.rust-lang.org/std/sync/struct.Condvar.html)

## B4) Uyku — gerçek bir olay kaynağı

7. **Yaprak future waker'ı olayı bilecek tarafa teslim eder.** `Uyku` ilk poll'da zamanlayıcıyı kurar (tembellik: poll edilmeyen uyumaz), waker'ı saklar ve `Pending` döner; yardımcı thread süre dolunca `doldu`'yu işaretleyip `wake()` çağırır. `drop(uyu_ms(20))` hiç poll edilmediyse ne bekler ne de thread açar; üretim runtime'ları tek zamanlayıcı + OS olay bildirimi kullanır, ilke aynıdır.
   ↳ Kaynak: [Rustdoc — std::thread::sleep](https://doc.rust-lang.org/std/thread/fn.sleep.html) · [Rustdoc — Future::poll, Return value](https://doc.rust-lang.org/std/future/trait.Future.html#return-value) · RfR Böl. 8

8. **Waker her poll'da güncelleştirilir.** Görev araya başka bir waker'la poll edilmiş olabilir (örneğin bir birleştiricinin içine taşındıysa); eskisini uyandırmak işe yaramaz. `Uyku` bütün alanları `Unpin` olduğu için `get_mut()` ile güvenle `&mut` alır; elle yazılan, kendine referans tutmayan future'ların çoğu böyledir.
   ↳ Kaynak: [Rustdoc — std::pin::Pin](https://doc.rust-lang.org/std/pin/struct.Pin.html) · [Rustdoc — Future::poll, Return value](https://doc.rust-lang.org/std/future/trait.Future.html#return-value)

## B5) ZamanAsimi — yarıştırma, Pin ve iptal

9. **Bir birleştirici iç future'a `Pin<&mut _>` vermek zorundadır.** Kaynakta iki güvenli yol gösterilir: alanı `Pin<Box<dyn Future>>` olarak kutulamak (kutu `Unpin`'dir, struct da `Unpin` olur, `get_mut()` çalışır; bedeli heap tahsisi) ya da pin projeksiyonu (`Pin<&mut Struct>` → `Pin<&mut Alan>`; tahsis yok, doğruluk elle/unsafe ya da `pin-project` / `pin-project-lite` makrosuyla kanıtlanır). Kısayol yok: `Pin::new(&mut self.ic)` yalnız `F: Unpin` ise derlenir; async blokların future'ları `!Unpin`'dir ve **E0277** (`F cannot be unpinned`) alınır.
   ↳ Kaynak: [Rustdoc — std::pin::Pin — projection](https://doc.rust-lang.org/std/pin/struct.Pin.html) · [Reference — async bloklar](https://doc.rust-lang.org/reference/)

10. **Süre dolunca iş iptal olur: future düşürülür.** `ZamanAsimi` önce asıl işi yoklar, sonra `sayac`'ı; kum önce biterse struct ve içindeki `ic` düşer. Async'te iptal budur — ayrı bir `cancel` çağrısı yoktur — bu yüzden bir future her `.await` noktasında yarıda kesilmeye hazır olmalıdır. Aynı turda ikisi de hazırsa sonuç tercih edilir.
    ↳ Kaynak: [Rustdoc — std::future::Future](https://doc.rust-lang.org/std/future/trait.Future.html) · [Rustdoc — std::pin::Pin](https://doc.rust-lang.org/std/pin/struct.Pin.html) · RfR Böl. 8

## Adım adım kod

Çalıştırıcının çekirdeği: hazır görev al, bir kez poll et, `Pending` ise geri koy.

```rust
pub fn calistir(&mut self) -> usize {
    while self.baslatici.canli.load(Ordering::SeqCst) > 0 {
        let Ok(gorev) = self.hazir.recv() else { break };
        let mut yuva = gorev.gelecek.lock().unwrap();
        let Some(mut gelecek) = yuva.take() else {
            continue; // zaten bitmiş bir göreve gecikmiş/yinelenen wake
        };
        let waker = Waker::from(Arc::clone(&gorev));
        let mut cx = Context::from_waker(&waker);
        self.poll_sayisi += 1;
        match gelecek.as_mut().poll(&mut cx) {
            Poll::Pending => *yuva = Some(gelecek),
            Poll::Ready(()) => {
                self.baslatici.canli.fetch_sub(1, Ordering::SeqCst);
            }
        }
    }
    self.poll_sayisi
}
```

Tutamac'ın Future uygulaması — denetim ve waker kaydı tek kilit altında:

```rust
fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<T> {
    let mut durum = self.paylasilan.lock().unwrap();
    match durum.sonuc.take() {
        Some(deger) => Poll::Ready(deger),
        None => {
            durum.bekleyen = Some(cx.waker().clone());
            Poll::Pending
        }
    }
}
```

## Sık yapılan hatalar

| Hata | Belirti | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| Waker kaydetmeden `Pending` dönmek | `calistir()` dönmez; görev askıda (E-kodu yok) | Waker'ı olayı bilecek tarafa teslim et; ayrıca denetim + kayıt tek kilit altında olsun. | [Future::poll — Return value](https://doc.rust-lang.org/std/future/trait.Future.html#return-value) |
| Eski waker'ı saklamak | Görev hiç uyanmaz | En son `Context`'in waker'ını kullan; her poll'da güncelle. | [Future::poll — Return value](https://doc.rust-lang.org/std/future/trait.Future.html#return-value) |
| `Pin::new(&mut self.ic)` ile `!Unpin` | **E0277** (`cannot be unpinned`) | `Box::pin`, `pin!` ya da pin-projeksiyonu. | [Rustdoc — Pin](https://doc.rust-lang.org/std/pin/struct.Pin.html) |
| Gecikmiş `wake()` ile bitmiş future'ı poll etmek | Yeniden poll sözleşme ihlali | `Option::take()` ile yuva boşsa `continue`; future yeniden poll EDİLMEMELİDİR. | [Future — Panics](https://doc.rust-lang.org/std/future/trait.Future.html#panics) |
| Sayaç 0'a indikten sonra yeni görev başlatmak | O görev poll edilmez | Görevler `calistir()`'dan önce ya da çalışan görevin içinde başlatılmalı. | [Rustdoc — std::sync::mpsc](https://doc.rust-lang.org/std/sync/mpsc/index.html) |

↳ Kaynak: [Rustdoc — std::future::Future](https://doc.rust-lang.org/std/future/trait.Future.html) · [Rustdoc — std::pin::Pin](https://doc.rust-lang.org/std/pin/struct.Pin.html)

## Derleyici perspektifi

- Waker `Send + Sync` olmak zorundadır; `std::task::Wake` `Arc<W: Send + Sync>` ister. Bu yüzden görev future'ı `Mutex` ardında tutar ve `Arc<Gorev>` kuyrukta taşınabilir.
  ↳ Kaynak: [rustc 1.99.1 — wake.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/task/wake.rs) · [Rustdoc — std::task::Wake](https://doc.rust-lang.org/std/task/trait.Wake.html)

- `dyn Future<Output = ()> + Send` bir trait object'tir: gerçek future türü kutunun içinde saklanır, dışarıda yalnız `poll` yeteneği görünür. Farklı async blokları bu sayede tek kuyruğa sığar.
  ↳ Kaynak: [Reference — trait objects](https://doc.rust-lang.org/reference/items/traits.html) · [rustc 1.99.1 — future.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/future/future.rs)

- Pin bir işaretçi sarmalayıcısıdır; `get_mut()` yalnız `Unpin` türlerde vardır. Alan bazlı pinleme (pin projeksiyonu) tahsis gerektirmez ama doğruluğu elle kanıtlanır; kütüphane yazarken makro tercih edilir.
  ↳ Kaynak: [Rustdoc — Pin — projection](https://doc.rust-lang.org/std/pin/struct.Pin.html) · [Reference — traits](https://doc.rust-lang.org/reference/items/traits.html)

- `async fn` → state machine; `Send`/`Sync`/`Unpin` auto-trait'leri await noktalarında canlı alanlardan türetilir. Bu yüzden `baslat`ın `F: Send + 'static` sınırı, görev içinde `Rc` ya da `MutexGuard` taşınmasını derleme anında reddeder.
  ↳ Kaynak: [Reference — async bloklar](https://doc.rust-lang.org/reference/) · [Reference — traits](https://doc.rust-lang.org/reference/items/traits.html)

- Gerçek runtime'lar aynı iskelete work stealing kuyruğu, epoll/kqueue/IOCP entegrasyonu, adil zamanlama ve iptal güvenliği yardımcıları ekler; görev, waker, kuyruk ve yaprak future kavramları birebir aynıdır.
  ↳ Kaynak: [Book ch17-03](https://doc.rust-lang.org/book/ch17-03-more-futures.html) · RfR Böl. 8 ve Böl. 10

## Özet ve sonraki adım

- Görev = sabitlenmiş, türü silinmiş future + kuyruk; uyandırmak kuyruğa geri koymaktır.
- Yalnız hazır görevler poll edilir; denetim + waker kaydı aynı kilit altında olmalı, waker her poll'da güncellenir.
- Zaman aşımı iptal demektir; Pin/Unpin kuralları birleştirici yazarken belirleyicidir.

Sıradaki sayfa: [29.3 Asenkron API İstemcisi](29-istemci.md).
