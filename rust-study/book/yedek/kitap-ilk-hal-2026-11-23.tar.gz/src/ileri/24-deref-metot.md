# 24. Deref ve Metot Çözümü

> Kaynak crate: `learn/advanced-concepts/ileri-deref-metot` · Çalıştır: `cargo run -p ileri-deref-metot`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

## Neden bu bölüm?

`kutulu.len()` yazdığında sihir olmaz: derleyici kutuyu açar, içindeki vektörü bulur, gereken `&` ya da `&mut` işaretini ekler ve ilk uyan metodu seçer. Bu yüzden `(&mut *kutu).metot()` gibi işaret yığınları yazmana gerek kalmaz. Ama aynı kolaylık bazen sürpriz yapar: sarmalın kendi metodu, içindeki türün aynı adlı metodunu sessizce gölgeler. Bu bölüm nokta operatörünün perde arkasını anlatır.

## 5 yaşındaki çocuğa anlatır gibi

Kapalı bir kutu içinde oyuncak var. "Oyuncağın rengi ne?" diye sorunca önce kutuyu açarsın, sonra oyuncağa bakarsın. Kutunun kendisinde de "renk" diye bir etiket varsa önce ona bakarsın; gerçek oyuncağın rengini sormak için kutuyu açman gerekir.

## Konu anlatımı (madde madde)

1. **Deref, `*x` operatörünün anlamını belirler.** `Deref` trait'i "içimdeki değere şöyle ulaşılır" der; `*x` aslında `*(x.deref())` demektir, `DerefMut` ise `&mut` sürümüdür. `Kutu<T>` için `impl Deref for Kutu<T> { type Target = T; }` yazılır; `Deref`'in gösterdiği iç türe `Target` denir.
   ↳ Kaynak: [Book ch15-02 — The Deref Trait](https://doc.rust-lang.org/book/ch15-02-deref.html) · [Rustdoc — Deref](https://doc.rust-lang.org/std/ops/trait.Deref.html)

2. **Bir türün yalnız tek bir `Target`'ı olabilir.** "İçi" tek anlamlı olsun diye ikinci bir `Deref` impl'i yazılamaz; farklı hedef isteyen ikinci impl çakışır.
   ↳ Kaynak: [Rustdoc — Deref](https://doc.rust-lang.org/std/ops/trait.Deref.html) · [Reference — Trait implementations](https://doc.rust-lang.org/reference/items/traits.html)

3. **Deref coercion derleme anında zincirlenir.** Fonksiyon argümanı ve metot alıcısı konumunda `&T → &U` (`T: Deref<Target = U>`) dönüşümü otomatik uygulanır: `selamla(&isim)` çağrısında `&Kutu<String> → &String → &str` zinciri kurulur. Çalışma anı maliyeti yoktur; işaretçi aynı yere yeniden yorumlanır.
   ↳ Kaynak: [Reference — Deref coercions](https://doc.rust-lang.org/reference/type-coercions.html#deref-coercions) · [Book ch15-02 — Deref Coercion](https://doc.rust-lang.org/book/ch15-02-deref.html)

4. **Metot çağrısı aday alıcı listesiyle çözülür.** `alıcı.metot()` için derleyici alıcının türünden başlar, tekrar tekrar `Deref` uygulayarak zinciri çıkarır (gerekirse son adımda `[T; N] → [T]` unsize), sonra her aday `U` için sırayla `U`, `&U`, `&mut U` biçimlerini dener ve ilk eşleşmeyi seçer.
   ↳ Kaynak: [Reference — Method-call expressions](https://doc.rust-lang.org/reference/expressions/method-call-expr.html#method-call-targets) · [rustc 1.99.1 — probe.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_hir_typeck/src/method/probe.rs)

5. **Autoderef sarmalı açar, autoref `&`/`&mut` ekler.** `v.push(4)` aslında `(&mut v).push(4)` olarak okunur; `s.len()` ise `(&s).len()` olur. Autoref sihir değildir: `&mut` alıcı için değer `mut` olmalı, aksi hâlde **E0596** ("cannot borrow `v` as mutable") gelir.
   ↳ Kaynak: [Book ch05-03 — Method Syntax](https://doc.rust-lang.org/book/ch05-03-method-syntax.html) · [rustc 1.99.1 — probe.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_hir_typeck/src/method/probe.rs)

6. **`len` zinciri Vec'te durur.** `Box<Vec<i32>>` üzerinde `kutulu.len()` derleyici Box'ı açıp Vec'e iner ve Vec'in kendi (inherent) `len` metodu orada bulunduğu için zincir burada biter — yani Box → Vec, **iki seviye**. Slice'a gerçekten inen çağrılar yalnız `[T]`de tanımlı metotlardır: `kutulu.first()`, `kutulu.iter()`, `kutulu.contains(&1)`.
   ↳ Kaynak: [Rustdoc — Vec](https://doc.rust-lang.org/std/vec/struct.Vec.html) · [Rustdoc — slice](https://doc.rust-lang.org/std/primitive.slice.html)

7. **İnherent metot, Deref hedefindeki aynı adlı metodu gölgeler.** `s.ad()` çağrısında önce `Sarmal`'ın kendi `ad` metodu bulunur ve Deref'e inilmez; sonuç `SARMAL` olur. İçteki `Ic::ad`'e ulaşmak için elle deref (`(*s).ad()`) ya da tam-nitelikli çağrı (`Ic::ad(&s)`) gerekir.
   ↳ Kaynak: [Reference — Method-call expressions](https://doc.rust-lang.org/reference/expressions/method-call-expr.html#method-call-targets) · [rustc 1.99.1 — probe.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_hir_typeck/src/method/probe.rs)

8. **Öncelik sırası her aday için aynıdır.** İnherent metotlar, trait metotlarından ve bir sonraki deref adımından önce gelir. Bu yüzden sarmala sonradan aynı adlı bir metot eklenirse eskiden içeri giden çağrı sessizce yön değiştirir ve derleyici uyarmaz.
   ↳ Kaynak: [Reference — Method-call expressions](https://doc.rust-lang.org/reference/expressions/method-call-expr.html#method-call-targets) · [Book ch05-03 — Method Syntax](https://doc.rust-lang.org/book/ch05-03-method-syntax.html)

9. **Şeffaf sarmallarda inherent metottan kaçınmak gerekir.** Aynı adlı metot çakışmasının ürettiği belirsizliği önlemek için iç türe giden fonksiyonu `static` (self almayan) fonksiyon olarak sunmak daha güvenlidir.
   ↳ Kaynak: [Book ch05-03 — Method Syntax](https://doc.rust-lang.org/book/ch05-03-method-syntax.html) · [Reference — Method-call expressions](https://doc.rust-lang.org/reference/expressions/method-call-expr.html#method-call-targets)

10. **Deref kalıtım değildir.** Yalnızca metot çağrısı ve coercion ergonomisi sağlar; alt-tip ilişkisi kurmaz. `Sarmal`, `Ic` değildir; sadece `Ic`'in metotlarına `.` ile erişilebilir olur.
    ↳ Kaynak: [Book ch18-00 — Object-Oriented Programming](https://doc.rust-lang.org/book/ch18-00-oop.html) · [Reference — Deref coercions](https://doc.rust-lang.org/reference/type-coercions.html#deref-coercions)

## Kodda nasıl görünür?

```rust
use std::ops::Deref;

struct Kutu<T>(T);
impl<T> Deref for Kutu<T> {
    type Target = T;
    fn deref(&self) -> &T {
        &self.0
    }
}
fn selamla(ad: &str) {
    println!("  selam, {ad}");
}

fn deref_ve_coercion() {
    let k = Kutu(5);
    println!("*Kutu(5) = {}", *k); // *k == *(k.deref())
    let isim = Kutu(String::from("Kaan"));
    selamla(&isim); // &Kutu<String> -> &String -> &str
}

fn autoderef_autoref() {
    let kutulu = Box::new(vec![1, 2, 3]);
    println!("autoderef: Box<Vec<i32>>.len() = {}", kutulu.len()); // 3, Vec'te durur

    let mut v = vec![1, 2, 3];
    v.push(4); // (&mut v).push(4)
    println!("autoref: v.push(4) == (&mut v).push(4) -> {v:?}");
}

struct Ic;
impl Ic {
    fn ad(&self) -> &str { "IC" }
}
struct Sarmal(Ic);
impl Deref for Sarmal {
    type Target = Ic;
    fn deref(&self) -> &Ic { &self.0 }
}
impl Sarmal {
    fn ad(&self) -> &str { "SARMAL" } // Ic::ad'i GÖLGELER
}

fn inherent_golgeleme() {
    let s = Sarmal(Ic);
    println!("s.ad()      = {} (inherent kazanır, Deref'e inilmez)", s.ad());
    println!("(*s).ad()   = {} (elle deref → Ic)", (*s).ad());
    println!("Ic::ad(&s)  = {} (tam-nitelikli, &Sarmal coerce)", Ic::ad(&s));
}
```

## Sık yapılan hatalar

| Kod | Hata | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| `let w = vec![1]; w.push(2);` | **E0596** | `push(&mut self)` için autoref `&mut` ekler ama `w` mut değil; `let mut w` yaz. | [Rustdoc — Vec::push](https://doc.rust-lang.org/std/vec/struct.Vec.html#method.push) |
| Aynı türe ikinci `impl Deref` (başka `Target`) | **E0119** | Bir türün yalnız tek `Target`'ı olabilir; ikinci impl çakışır. | [Rustdoc — Deref](https://doc.rust-lang.org/std/ops/trait.Deref.html) |
| `s.ad()` ile `Ic::ad`'i beklemek | — (sessiz gölgeleme) | `Sarmal::ad` inherent metot önce gelir; `(*s).ad()` ya da `Ic::ad(&s)` kullan. | [Reference — Method-call expressions](https://doc.rust-lang.org/reference/expressions/method-call-expr.html#method-call-targets) |
| Deref zincirinin slice'a indiğini sanmak | — (yanlış zihinsel model) | `len` Vec'te durur (Box → Vec, iki seviye); slice metotları `first`/`iter`/`contains`'tır. | [Rustdoc — Vec](https://doc.rust-lang.org/std/vec/struct.Vec.html) |

## Derleyici perspektifi

- `core::ops::Deref` yalnız `*x` operatörünü tanımlar; `deref()` çağrısı ve tek `Target` kısıtı bu trait'in parçasıdır. Deref coercion ise `rustc_hir_typeck` tarafından derleme anında zincirlenerek uygulanır; çalışma anında bir dönüşüm yoktur.
  ↳ Kaynak: [rustc 1.99.1 — deref.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/ops/deref.rs) · [Reference — Deref coercions](https://doc.rust-lang.org/reference/type-coercions.html#deref-coercions)

- Metot çözümü `rustc_hir_typeck/src/method/probe.rs` içinde yapılır: aday alıcı türleri listesi kurulur, her aday için `U`, `&U`, `&mut U` sırasıyla denenir, ilk uyan aday seçilir.
  ↳ Kaynak: [rustc 1.99.1 — probe.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_hir_typeck/src/method/probe.rs) · [Reference — Method-call expressions](https://doc.rust-lang.org/reference/expressions/method-call-expr.html#method-call-targets)

- Alıcı seçimi borrow kurallarından bağımsız değildir: `&mut` isteyen metot için `mut` alınamazsa **E0596** üretilir. Autoref, derleyicinin senin yerine koyduğu bir `&`/`&mut`'tır; kural yine geçerlidir.
  ↳ Kaynak: [rustc 1.99.1 — probe.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_hir_typeck/src/method/probe.rs) · [Rustdoc — Vec::push](https://doc.rust-lang.org/std/vec/struct.Vec.html#method.push)

- `len` için zincirin Vec'te durması, Vec'in kendi inherent `len` metodu olmasındandır (Box → Vec, iki seviye); kaynak crate'de bu ayrım `first`/`iter`/`contains` örnekleriyle doğrulandı.
  ↳ Kaynak: [Rustdoc — Vec](https://doc.rust-lang.org/std/vec/struct.Vec.html) · [Rustdoc — slice](https://doc.rust-lang.org/std/primitive.slice.html)

> **Kaynak notu:** RfR Böl. 3 (Designing Interfaces → Wrapper Types; "Deref and Inherent Methods" kutusunun tam adı/yeri **DOĞRULANAMADI**) + The Rust Reference (method-call expression) + std (`core::ops::Deref`). Dersin 5. ve 15. bölümleri burada birleşir.
> ↳ Kaynak: [Reference — Method-call expressions](https://doc.rust-lang.org/reference/expressions/method-call-expr.html#method-call-targets) · [Rustdoc — Deref](https://doc.rust-lang.org/std/ops/trait.Deref.html)

## Özet ve sonraki adım

- `x.metot()` = autoderef (zinciri in) + autoref (`&`/`&mut` ekle) + ilk eşleşen metot.
- `len` Vec'te durur (Box → Vec, iki seviye); slice'a inen metotlar `first`, `iter`, `contains`'tır.
- İnherent metot gölgeler; Deref kalıtım değildir, yalnız ergonomi sağlar.

Sıradaki bölüm: [25. Send / Sync'in İç Yüzü](25-send-sync.md).
