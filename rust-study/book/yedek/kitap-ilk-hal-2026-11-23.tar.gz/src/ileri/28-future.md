# 28. Future'ın İç Yüzü

> Kaynak crate: `learn/advanced-concepts/ileri-future` · Çalıştır: `cargo run -p ileri-future`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

## Neden bu bölüm?

Müfredat Böl. 17'de `async`/`.await`'i kullandık; burada mekanizmanın kapağını açıyoruz. Bir future kendi kendine çalışmaz: biri onu `poll` eder, o da ya sonucu verir ya "henüz değil" der ve bir zil bırakır. `poll`, `Waker` ve `Pin` üçlüsünü anlayınca async kodun neden bloklamadığını ve iptalin neden "future'ı düşürmek" olduğunu görürsün.

## 5 yaşındaki çocuğa anlatır gibi

Çamaşır makinesine "bittiğinde beni ara" diye not bırakıyorsun. Sen başka iş yapıyorsun; telefon çalınca gidip çamaşırı alıyorsun. Durmadan "bitti mi?" diye bakmıyorsun. Uzun tarifin de bölünmüş sayfaları var: her `.await` bir sayfa sonu, orada durup devam edersin.

## Konu anlatımı (madde madde)

1. **Future, henüz bitmemiş bir hesaptır.** Onu oluşturmak işi başlatmaz; ancak `poll` edildiğinde ilerler. Tek zorunlu metot, `Pin<&mut Self>` ve `&mut Context<'_>` alan `poll`'dur.
   ↳ Kaynak: [Rustdoc — std::future::Future](https://doc.rust-lang.org/std/future/trait.Future.html) · [rustc 1.99.1 — future.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/future/future.rs) · [Book ch17-01](https://doc.rust-lang.org/book/ch17-01-futures-and-syntax.html)

2. **`poll` iki cevap verir: `Ready(değer)` ya da `Pending`.** `Ready` işin bittiğini ve sonucu söyler; `Pending` "şimdilik bu kadar, sonra yine bak" demektir. Sözleşme, ilerleyebildiğin kadar ilerlemektir.
   ↳ Kaynak: [rustc 1.99.1 — poll.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/task/poll.rs) · [Rustdoc — Future::poll](https://doc.rust-lang.org/std/future/trait.Future.html#the-poll-method)

3. **`Pending` dönmeden önce Waker saklanmalıdır.** Waker'ı kaydetmeden `Pending` dönmek derlenir ama executor seni bir daha poll etmez; future sonsuza dek asılı kalır. Önce zil kurulur, sonra "daha olmadı" denir.
   ↳ Kaynak: [Rustdoc — Future::poll, Return value](https://doc.rust-lang.org/std/future/trait.Future.html#return-value) · [Rustdoc — std::task::Context](https://doc.rust-lang.org/std/task/struct.Context.html)

4. **Executor döngüsü std'de yoktur.** `block_on` benzeri en yalın executor poll eder, `Pending` gelince `thread::park()` ile uyur, `wake` gelince yeniden poll eder; böylece busy-wait olmaz. Döngü + I/O entegrasyonu + zamanlayıcı tek "doğru" biçimde olmadığı için tokio/async-std gibi crate'lere bırakılmıştır (müfredat Böl. 17 tekrarı).
   ↳ Kaynak: [Book ch17-03](https://doc.rust-lang.org/book/ch17-03-more-futures.html) · [Rustdoc — std::thread::park](https://doc.rust-lang.org/std/thread/fn.park.html)

5. **Waker, "bu görevi yeniden poll et" düğmesidir; içten bakınca bir trait object *gibidir*.** Veri pointer'ı + `&'static RawWakerVTable` taşır; vtable `clone`, `wake`, `wake_by_ref`, `drop` olmak üzere dört fonksiyon pointer'ı tutar — bir nevi elle yazılmış vtable. Ham `RawWaker`/`RawWakerVTable` yazmak `unsafe`'tir; `std::task::Wake` (`Arc<impl Wake>` → `Waker`) bunu güvenli sarar; Waker `Clone` ve `Send + Sync`'tir.
   ↳ Kaynak: [Rustdoc — std::task::Waker](https://doc.rust-lang.org/std/task/struct.Waker.html) · [rustc 1.99.1 — wake.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/task/wake.rs) · RfR Böl. 8

6. **`wake` zili tüketir, `wake_by_ref` elde bırakır.** `wake()` çağrılan Waker bir daha kullanılamaz; klonlanmış bir Waker başka thread'den de çalabilir — bunu sağlayan `Send + Sync` garantisidir.
   ↳ Kaynak: [Rustdoc — Waker::wake](https://doc.rust-lang.org/std/task/struct.Waker.html#method.wake) · [Rustdoc — Waker::wake_by_ref](https://doc.rust-lang.org/std/task/struct.Waker.html#method.wake_by_ref)

7. **`async fn` bir durum makinesine (generator) çevrilir; o makine Future'ın ta kendisidir.** Makine her `.await` noktasında canlı yerel durumunu — alt-future'lar dahil — içinde saklar; bu yüzden görünmez biçimde büyüyebilir ve büyük future'ları `Box::pin` ile heap'e almak gerekebilir. Kaynak yorumundaki spesifik dizi boyu birincil kaynakta doğrulanamadı (`DOĞRULANAMADI`); bu yüzden "örneğin büyük bir dizi" ifadesi korunur, doğrulanmamış bir sayı yazılmaz.
   ↳ Kaynak: [Reference — async bloklar](https://doc.rust-lang.org/reference/) · [Rustdoc — Box::pin](https://doc.rust-lang.org/std/boxed/struct.Box.html#method.pin) · RfR Böl. 8

8. **Self-referential makineler taşınamaz; `Pin` adresi sabitler.** Bir `.await` noktasında makine kendi alanına referans tutabilir; taşınırsa iç pointer eski adrese bakar. `poll`'un `Pin<&mut Self>` alması bu garantiyi tür düzeyinde dayatır; `Unpin` türlerde kilit boştur, `PhantomPinned` bir tipi bilerek `!Unpin` yapar.
   ↳ Kaynak: [Rustdoc — std::pin::Pin](https://doc.rust-lang.org/std/pin/struct.Pin.html) · [rustc 1.99.1 — marker.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/marker.rs) · RfR Böl. 8

9. **Future bir kez tamamlanır; bittikten sonra yeniden poll EDİLMEMELİDİR.** Bu bir sözleşme ihlalidir: derlenir ama panik, askıda kalma ya da başka sorunlar olabilir. Bu yüzden yeniden deneme kodu hazır bir future'ı değil, her denemede taze future üreten bir closure ister (29.3'te görülecek).
   ↳ Kaynak: [Rustdoc — Future, Panics](https://doc.rust-lang.org/std/future/trait.Future.html#panics) · [Rustdoc — Future::poll](https://doc.rust-lang.org/std/future/trait.Future.html#the-poll-method)

## Kodda nasıl görünür?

`learn/advanced-concepts/ileri-future/src/main.rs` dosyasından alınan kısa kesit. `println!` başlıkları kaynaktaki hâliyle korunmuştur.

```rust
use std::future::Future;
use std::marker::PhantomPinned;
use std::pin::Pin;
use std::ptr;
use std::sync::Arc;
use std::task::{Context, Poll, Wake, Waker};
use std::thread::{self, Thread};

struct GecikmeliDeger { kalan: u32 }

impl Future for GecikmeliDeger {
    type Output = &'static str;
    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<&'static str> {
        println!("   [future.poll] çağrıldı — kalan = {}", self.kalan);
        if self.kalan == 0 {
            println!("   [future.poll] hazır → Poll::Ready");
            Poll::Ready("İŞ BİTTİ")
        } else {
            self.kalan -= 1;
            cx.waker().wake_by_ref();
            println!("   [future.poll] hazır değil → waker kaydedildi, Poll::Pending");
            Poll::Pending
        }
    }
}

fn main() {
    println!("== 1) poll / Pending / wake / yeniden-poll döngüsü (izlenebilir) ==");
    let sonuc = izle_block_on(GecikmeliDeger { kalan: 3 });
    println!("block_on döndü: {sonuc:?}\n");

    println!("== 2) Waker gerçekte nedir? ==");
    waker_nedir();

    println!("\n== 3) Pin ve self-referential (RfR Böl. 8) ==");
    pin_ve_self_referential();
}
```

## Sık yapılan hatalar

| Hata | Belirti | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| Waker kaydetmeden `Pending` dönmek | Derlenir; görev sonsuza dek askıda kalır (E-kodu yok) | Önce `cx.waker()`'ı olayı bilecek tarafa teslim et, sonra `Pending` dön. | [Future::poll — Return value](https://doc.rust-lang.org/std/future/trait.Future.html#return-value) |
| Bitmiş future'ı tekrar poll etmek | Panik/askıda kalma olabilir (E-kodu yok) | Future yeniden poll EDİLMEMELİDİR; yeni deneme için taze future üret. | [Future — Panics](https://doc.rust-lang.org/std/future/trait.Future.html#panics) |
| `Pin::new(&mut alan)` çağrısı `!Unpin` alan için | **E0277** (`cannot be unpinned`) | `pin!`, `Box::pin` ya da pin-projeksiyonu kullan. | [Rustdoc — Pin](https://doc.rust-lang.org/std/pin/struct.Pin.html) |
| `Poll::Pending` dönen future'ı sık döngüde yoklamak | Busy-wait; işlemci boşa yanar | Waker gelene kadar park/uyu; "yalnız hazır olunca poll". | [Future — Runtime characteristics](https://doc.rust-lang.org/std/future/trait.Future.html#runtime-characteristics) |
| Ham `RawWaker`/`RawWakerVTable` yazmak | `unsafe` sözleşmesi elle üstlenilir | `std::task::Wake` + `Arc` ile güvenli üret. | [rustc 1.99.1 — wake.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/task/wake.rs) |

↳ Kaynak: [Rustdoc — std::future::Future](https://doc.rust-lang.org/std/future/trait.Future.html) · [rustc 1.99.1 — poll.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/task/poll.rs)

## Derleyici perspektifi

- `Future` trait'i `core/src/future/future.rs:37`, zorunlu `poll` metodu `:113`; `Poll` enum'u `core/src/task/poll.rs:13` (`Ready(T) | Pending`) olarak tanımlıdır.
  ↳ Kaynak: [rustc 1.99.1 — future.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/future/future.rs) · [rustc 1.99.1 — poll.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/task/poll.rs)

- Waker `core/src/task/wake.rs`: `RawWaker` (`:22`) = `(data: *const (), &'static RawWakerVTable)`, vtable (`:113`) dört fonksiyon pointer'ı, `Waker` `:411`, `wake()` `:443`. Bu, tam anlamıyla bir trait object değil; **bir nevi elle yazılmış trait object/vtable** olarak okunmalıdır. `std::task::Wake` bu ham yapının güvenli sarmalayıcısıdır.
  ↳ Kaynak: [rustc 1.99.1 — wake.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/task/wake.rs) · [Rustdoc — std::task::Waker](https://doc.rust-lang.org/std/task/struct.Waker.html)

- `async fn`/`async {}` → state machine (generator). RfR Böl. 8'e göre makine her await noktasındaki tüm canlı yerel durumu içinde tutar; bu yüzden büyük yereller future'ı büyütür ve `Box::pin` ile heap'e almak taşımayı ucuzlatabilir. Spesifik bir dizi boyu birincil kaynakta doğrulanamadı → `DOĞRULANAMADI`; "örneğin büyük bir dizi" denir.
  ↳ Kaynak: [Reference — async bloklar](https://doc.rust-lang.org/reference/) · [Rustdoc — Box::pin](https://doc.rust-lang.org/std/boxed/struct.Box.html#method.pin) · RfR Böl. 8

- Bir future bir kez poll'landıktan sonra iç referans kurulabildiğinden sonrasında taşınmaması gerekir; `Pin<&mut Self>` bunu tür düzeyinde dayatır. `Unpin` için söz boştur; `PhantomPinned` bir tipi `!Unpin` yapar.
  ↳ Kaynak: [Rustdoc — std::pin::Pin](https://doc.rust-lang.org/std/pin/struct.Pin.html) · [rustc 1.99.1 — marker.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/marker.rs)

- Executor'ın std'de olmaması bilinçli bir ayrım: mekanizma (`Future`/`poll`/`Waker`/`Pin`) std'de, poll döngüsü ve I/O entegrasyonu crate'lerdedir. `izle_block_on` o döngünün en yalın çekirdeğidir (müfredat Böl. 17 tekrarı).
  ↳ Kaynak: [Book ch17-03](https://doc.rust-lang.org/book/ch17-03-more-futures.html) · [Book ch17-02](https://doc.rust-lang.org/book/ch17-02-async-await.html)

## Özet ve sonraki adım

- Future pasiftir: poll edilince ilerler; `Pending` dönmeden önce Waker mutlaka saklanır, busy-wait olmaz.
- Waker (bir trait object *gibi*), `Pin` ve async durum makinesi aynı sözleşmenin üç parçasıdır; RfR Böl. 8 referans alınır.
- Future bir kez tamamlanır; yeniden poll EDİLMEMELİDİR ve birincil kaynakta doğrulanmamış spesifik sayılar kullanılmaz.

Sıradaki bölüm: [29. İleri Eşzamanlılık ve Async](29-ileri-eszamanlilik-async.md).
