# 21. Alt-tip ve Değişkenlik

> Kaynak crate: `learn/advanced-concepts/ileri-variance` · Çalıştır: `cargo run -p ileri-variance`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

## Neden bu bölüm?

Bir görevli senden "bugün geçerli bilet" isterse yıllık kartı gösterebilirsin; kimse zarar görmez. Ama içine sonradan not yazılabilen bir kutunun etiketini esnetirsen, kutuya kısa süreli bir not konur ve sen onu hâlâ uzun süreli sanırsın. Lifetime hatalarının görünmez sebebi çoğu zaman yazdığın kod değil, türün (kutunun) bu esneklik kuralıdır. Bu bölümde hangi kutunun esnediğini, hangisinin tam süre istediğini öğreneceğiz.

## 5 yaşındaki çocuğa anlatır gibi

Büyük bir defteri küçük bir çantaya koyabilirsin; ama küçük defteri büyük çantaya koyup "büyük defter san" diyemezsin. Üstüne yazı yazılabilen defterlerde ise hiç karıştırma yapamazsın; yoksa yanındaki not yanlış olur.

## Konu anlatımı (madde madde)

1. **Alt-tip, "en az onun kadar işe yarayan" türdür.** Lifetime'larda `'b: 'a` (`'b`, `'a`'yı kapsar) ise `'b`, `'a`'nın alt-tipidir; uç örnek olarak `'static` her `'a`'nın alt-tipidir. Böylece uzun yaşayan referans, kısa beklenen yere verilebilir.
   ↳ Kaynak: [Reference — Subtyping](https://doc.rust-lang.org/reference/subtyping.html) · [Nomicon — Subtyping and Variance](https://doc.rust-lang.org/nomicon/subtyping.html)

2. **Covariant (esnek) taraf: `&'a T`.** Paylaşımlı referans hem `'a`'da hem `T`'de covarianttır; `&Vec<&'static str>` değeri `&Vec<&'a str>` bekleyen `oku` fonksiyonuna geçer. Yalnız okunan veride "fazladan uzun yaşamak" kimseye zarar vermez.
   ↳ Kaynak: [Nomicon — Subtyping and Variance](https://doc.rust-lang.org/nomicon/subtyping.html) · [Reference — Subtyping](https://doc.rust-lang.org/reference/subtyping.html)

3. **Invariant (katı) taraf: `&mut T`.** `&mut T`, `T`de invarianttır: ne alt-tip ne üst-tip kabul edilir, tam o tip gerekir. Çünkü `&mut` hem okur hem yazar; esneklik verilse içine kısa ömürlü bir şey yazılır, çağıran ise uzun ömürlü sanıp kullanır ve sarkan referans oluşur.
   ↳ Kaynak: [Nomicon — Subtyping and Variance](https://doc.rust-lang.org/nomicon/subtyping.html) · [Rustdoc — Cell](https://doc.rust-lang.org/std/cell/index.html)

4. **Değiştirme yeteneği olan her tür invarianttır.** `&mut T` dışında `Cell<T>`, `RefCell<T>` ve `*mut T` de `T`de invarianttır; hepsi içine yazmaya izin verir. `&Vec<&'static str>` geçerken `&mut Vec<&'static str>`, `&mut Vec<&'a str>` beklenen yere geçmez.
   ↳ Kaynak: [Nomicon — Subtyping and Variance](https://doc.rust-lang.org/nomicon/subtyping.html) · [Rustdoc — Cell](https://doc.rust-lang.org/std/cell/index.html)

5. **Contravariant (ters yön) yalnız fonksiyon argümanlarında görülür.** `fn(T)` argümanı `T`de contravarianttır: "hangi süre gelirse kabul ederim" diyen `fn(&'a str)`, yalnız `'static` kabul eden `fn(&'static str)` beklenen yere geçebilir; yön ters döner.
   ↳ Kaynak: [Nomicon — Subtyping and Variance](https://doc.rust-lang.org/nomicon/subtyping.html) · [Reference — Subtyping](https://doc.rust-lang.org/reference/subtyping.html)

6. **Variance elle yazılmaz, alanların konumundan yapısal olarak çıkarılır.** "Yalnız üret/oku" konumları covariant, "hem oku hem yaz" konumları invariant olur. Kütüphane yazarları `PhantomData<&'a T>` ya da `PhantomData<*mut T>` ile istedikleri variance'ı belirtebilir.
   ↳ Kaynak: [Nomicon — Subtyping and Variance](https://doc.rust-lang.org/nomicon/subtyping.html) · [Rustdoc — PhantomData](https://doc.rust-lang.org/std/marker/struct.PhantomData.html)

7. **Pratik çözüm: dış borrow ile iç verinin ömrünü ayır.** `struct MutStr<'a, 'b> { s: &'a mut &'b str }` iki lifetime kullanır; dış `'a` kutuyu ne kadar elinde tuttuğunu, iç `'b` yazının ne kadar geçerli olduğunu anlatır. Aynı kod tek lifetime ile yazılırsa (`&'a mut &'a str`) E0502 verir, çünkü iç konum invariant olduğu için `'a` kısalamaz.
   ↳ Kaynak: [Nomicon — Subtyping and Variance](https://doc.rust-lang.org/nomicon/subtyping.html) · [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs)

8. **Well-formedness kısıtı kısaltmaya izin verir.** `&'a mut &'b str` için örtük kısıt `'b: 'a`'dır; `'b = 'static` olunca `'static: 'a` her `'a` için doğrudur, dolayısıyla kısıt dış `'a`'ya baskı yapmaz ve dış ömür `println!`'den önce kısalarak bitebilir.
   ↳ Kaynak: [Reference — Implied bounds](https://doc.rust-lang.org/reference/trait-bounds.html#implied-bounds) · [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html)

9. **Tek lifetime neden kilitlenir?** Tek parametre hem invariant hem covariant konumda geçtiğinde invariant kazanır ve `'a = 'static`'e çivilenir; `&mut` ödüncü `println!`'e taşar, derleyici "hâlâ değiştirilebilir ödünç alınmış" der.
   ↳ Kaynak: [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs) · [rustc 1.99.1 — nll.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/nll.rs)

10. **Variance tamamen derleme zamanı kavramıdır.** Çalışma anında lifetime ya da variance diye bir şey yoktur; borrow checker ömrü kısaltmaya çalışırken kurallara uyar, invariant konumda uyamayıp çakışmayı hata olarak bildirir.
    ↳ Kaynak: [Nomicon — Subtyping and Variance](https://doc.rust-lang.org/nomicon/subtyping.html) · [rustc 1.99.1 — nll.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/nll.rs)

## Kodda nasıl görünür?

```rust
fn subtyping() {
    fn kisa_bekler(x: &str) -> usize {
        x.len()
    }
    let sabit: &'static str = "program boyu yaşarım";
    println!("subtyping: &'static → &'a kabul edildi, len = {}", kisa_bekler(sabit));
}

fn covariance() {
    fn oku(v: &Vec<&str>) -> usize {
        v.len()
    }
    let depo: Vec<&'static str> = vec!["a", "b", "c"];
    println!("covariance: paylaşımlı & esnek, eleman sayısı = {}", oku(&depo));
}

struct MutStr<'a, 'b> {
    s: &'a mut &'b str, // dış borrow 'a, içteki yazı 'b — AYRI
}

fn invariance_mutstr() {
    let mut s = "hello";
    *MutStr { s: &mut s }.s = "world"; // ✓ iki lifetime ile derlenir
    println!("invariance: MutStr<'a,'b> ile s = {s}");
    // struct MutStr<'a> { s: &'a mut &'a str } olsaydı aynı kod E0502 verirdi.
}
```

## Sık yapılan hatalar

| Kod | Hata | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| `struct Tek<'a> { s: &'a mut &'a str }` ardından okuma | **E0502** | Tek lifetime iç konumda invariant olup `'static`'e çivilenir; iki lifetime kullan (`MutStr<'a, 'b>`). | [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs) |
| `'static` etiketli kutuya yerel `&gecici` yazmak | **E0597** | `&mut` ardındaki tür invarianttır; uzun ömürlü kutuya kısa ömürlü değer yazılamaz. | [Nomicon — Subtyping](https://doc.rust-lang.org/nomicon/subtyping.html) |
| `&mut Vec<&'static str>` değerini `&mut Vec<&'a str>` bekleyen yere vermek | **E0597 / "lifetime may not live long enough"** | `&mut Vec<_>` invarianttır; paylaşımlı `&Vec<_>` olsaydı geçerdi. | [Nomicon — Subtyping](https://doc.rust-lang.org/nomicon/subtyping.html) |
| `fn f(x: &'static str)` bekleyen yere `fn(&'a str)` vermeyi beklemek | — (ters yön) | Argüman konumu contravarianttır; esnek olan fonksiyon katı olanın yerine geçer. | [Nomicon — Subtyping](https://doc.rust-lang.org/nomicon/subtyping.html) |

## Derleyici perspektifi

- Variance inference yapısal olarak yapılır: derleyici her alanın konumuna bakıp türün covariant mı invariant mı olduğunu çıkarır; `PhantomData` bu çıkarımı yönlendirmenin resmî yoludur.
  ↳ Kaynak: [Nomicon — Subtyping and Variance](https://doc.rust-lang.org/nomicon/subtyping.html) · [Rustdoc — PhantomData](https://doc.rust-lang.org/std/marker/struct.PhantomData.html)

- Borrow checker (`nll`) ömrü kısaltmaya çalışır; invariant konumda kısaltamadığı için ödünç `println!`'e taşır ve **E0502** üretilir. İki lifetime'lı `MutStr<'a, 'b>` bu baskıyı kaldırır; kaynak koddaki iki repro ile doğrulandı.
  ↳ Kaynak: [rustc 1.99.1 — nll.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/nll.rs) · [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs)

- Örtük well-formedness kısıtı (`'b: 'a`) implied bound olarak ele alınır; `'b = 'static` olduğunda kısıt her `'a` için sağlanır ve çakışma oluşmaz.
  ↳ Kaynak: [Reference — Implied bounds](https://doc.rust-lang.org/reference/trait-bounds.html#implied-bounds) · [Reference — Lifetimes](https://doc.rust-lang.org/reference/lifetimes.html)

> **Kaynak notu:** RfR Böl. 1 (Foundations → Borrowing and Lifetimes → Lifetimes). Kesin listing numarası yayıncının ayrıntılı içindekiler listesinde yer almadığı için **DOĞRULANAMADI**; bölüm numarası kaynak kodda doğrulanmıştır. Konu Rust Book'ta ayrıntılı ele alınmaz, [Nomicon — Subtyping and Variance](https://doc.rust-lang.org/nomicon/subtyping.html) sayfasında ele alınır.
> ↳ Kaynak: [Nomicon — Subtyping and Variance](https://doc.rust-lang.org/nomicon/subtyping.html) · [Reference — Subtyping](https://doc.rust-lang.org/reference/subtyping.html)

## Özet ve sonraki adım

- Uzun ömür, kısa ömür bekleyen yere geçer (alt-tip); `&` ve `&Vec<_>` covarianttır.
- `&mut`, `Cell`, `RefCell` invarianttır; fonksiyon argümanları contravarianttır.
- Gereksiz invariance'dan kaçınmak için dış borrow ve iç veri ömrünü ayrı lifetime parametrelerine böl.

Sıradaki bölüm: [22. Boyut, DST ve Şişman İşaretçi](22-sized-dst.md).
