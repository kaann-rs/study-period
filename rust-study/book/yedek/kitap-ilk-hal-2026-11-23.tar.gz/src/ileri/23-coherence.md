# 23. Tutarlılık ve Yetim Kuralı

> Kaynak crate: `learn/advanced-concepts/ileri-coherence` · Çalıştır: `cargo run -p ileri-coherence`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

## Neden bu bölüm?

Okulda aynı öğrencinin aynı dersten iki notu olsa karnede hangisinin yazılacağı bilinmezdi. Rust'ta da bir tür ile bir trait'in eşleşmesi bütün programda yalnız bir kez yazılabilir; yoksa `x.metot()` çağrısında derleyici hangi impl'i seçeceğini bilemez. Bu bölüm, o tekliği hangi kuralların koruduğunu ve kendi türünü bir kutuya koyarak kapının nasıl açıldığını anlatır.

## 5 yaşındaki çocuğa anlatır gibi

Okulda her öğrencinin tek numarası olur. İki kişi aynı numarayı alırsa yoklama karışır. Numarayı ya okul verir ya da sen kendi defterine yeni bir isim yazarsın; başkasının defterine izinsiz numara yazamazsın.

## Konu anlatımı (madde madde)

1. **Coherence (tutarlılık): her `(tür, trait)` çifti için en fazla bir impl olabilir.** Böylece `x.metot()` çağrısında tek doğru seçim vardır; ayrı derleme ve crate bağımlılıkları altında bile belirsizlik oluşmaz.
   ↳ Kaynak: [Reference — Trait implementations](https://doc.rust-lang.org/reference/items/traits.html) · [Reference — Orphan rules](https://doc.rust-lang.org/reference/items/implementations.html#orphan-rules)

2. **Blanket impl, bir trait'i bir tür ailesine tek satırda uygular.** `impl<T: Display> ToString for T` std'nin klasik örneğidir; yalnızca trait'i tanımlayan crate blanket yazabilir, aksi hâlde iki crate çakışan blanket yazabilirdi.
   ↳ Kaynak: [Reference — Trait implementations](https://doc.rust-lang.org/reference/items/traits.html) · [Rustdoc — ToString](https://doc.rust-lang.org/std/string/trait.ToString.html)

3. **Yetim kuralı (orphan rule): `impl Trait for Tip` yazmak için trait ya da tip senin crate'inde tanımlı olmalı.** İki uç da reddedilir: yalnız trait sahibi yazsa kendi türüne `Debug` ekleyemezdin; yalnız kendi türüne yazılsa bir trait crate'i std tiplerine impl veremezdi. Kural ikisini dengeler.
   ↳ Kaynak: [Reference — Orphan rules](https://doc.rust-lang.org/reference/items/implementations.html#orphan-rules) · [Book ch10-02 — Traits](https://doc.rust-lang.org/book/ch10-02-traits.html)

4. **Yabancı trait + yerel tip izinlidir.** `impl Display for Benim` yazılabilir, çünkü `Display` std'den ama `Benim` bizim crate'imizde tanımlı; aynı şekilde yerel `Etiketle` trait'i yabancı tipe (blanket olmasaydı `bool`'a) uygulanabilir.
   ↳ Kaynak: [Reference — Orphan rules](https://doc.rust-lang.org/reference/items/implementations.html#orphan-rules) · [Book ch10-02 — Implementing a Trait on a Type](https://doc.rust-lang.org/book/ch10-02-traits.html#implementing-a-trait-on-a-type)

5. **İkisi de yabancıysa kapı kapanır: E0117.** `impl Display for Vec<i32>` yazılamaz, çünkü `Display` de `Vec` de std'nindir. Çıkış yolu newtype kalıbıdır: `struct Sarmal(Vec<i32>)` diyerek yabancı türü kendi tek alanlı struct'ına sararsın ve `impl Display for Sarmal` yazabilirsin.
   ↳ Kaynak: [Reference — Orphan rules](https://doc.rust-lang.org/reference/items/implementations.html#orphan-rules) · [Book ch19-00 — Advanced Features](https://doc.rust-lang.org/book/ch19-00-advanced-features.html)

6. **Covered impl dar bir istisnadır.** `impl From<Benim> for String` örneğinde `From` ve `String` yabancı olmasına rağmen izin vardır, çünkü yerel `Benim` trait'in köşeli parantezi içinde açıkça geçer; hiçbir başka crate onu bilmediği için aynı tanımı yazamaz.
   ↳ Kaynak: [Reference — Orphan rules](https://doc.rust-lang.org/reference/items/implementations.html#orphan-rules) · [Rustdoc — From](https://doc.rust-lang.org/std/convert/trait.From.html)

7. **Covered impl'ın kesin koşulu sıralamayla ilgilidir.** `impl<P..> ForeignTrait<T1..Tn> for T0` ancak en az bir `Ti` yerel ve ilk yerel `Ti`'den önce bir generic `P` gelmiyorsa izinlidir; bir `T` başka tipe parametre olursa ("covered") kapsanır, tek başına `T` ya da `&T` kapsanmaz. Bu yüzden `From<i32> for String` yasaktır.
   ↳ Kaynak: [Reference — Orphan rules](https://doc.rust-lang.org/reference/items/implementations.html#orphan-rules) · [Rustdoc — From](https://doc.rust-lang.org/std/convert/trait.From.html)

8. **Fundamental tipler yetim kuralında "yokmuş" sayılır.** `&`, `&mut` ve `Box` (`#[fundamental]`) kontrol öncesi şeffaf geçer; bu yüzden `impl IntoIterator for &MyType` yazabilirsin — `&` ve `IntoIterator` yabancı olsa da içteki `MyType` yereldir.
   ↳ Kaynak: [Reference — Orphan rules](https://doc.rust-lang.org/reference/items/implementations.html#orphan-rules) · [Rustdoc — IntoIterator](https://doc.rust-lang.org/std/iter/trait.IntoIterator.html)

9. **Var olan bir trait'e blanket eklemek kırıcı değişikliktir.** Downstream'deki `impl MyTrait for Foo` birden **E0119** ("conflicting implementations") verir; aynı çakışma kodda blanket varken ayrıca `impl Etiketle for i32` yazıldığında da görülür.
   ↳ Kaynak: [Reference — Orphan rules](https://doc.rust-lang.org/reference/items/implementations.html#orphan-rules) · [rustc 1.99.1 — kaynak ağacı](https://github.com/rust-lang/rust/tree/1.99.1)

10. **Bütün kurallar derleme zamanındadır.** Coherence, ayrı derleme altında bile "hangi impl?" sorusunu tek yanıtla bitirir; çalışma anında coherence ya da yetim kuralı diye bir mekanizma yoktur.
    ↳ Kaynak: [Reference — Trait implementations](https://doc.rust-lang.org/reference/items/traits.html) · [Reference — Orphan rules](https://doc.rust-lang.org/reference/items/implementations.html#orphan-rules)

## Kodda nasıl görünür?

```rust
use std::fmt::Display;

trait Etiketle {
    fn etiket(&self) -> String;
}

impl<T: Display> Etiketle for T {
    fn etiket(&self) -> String {
        format!("<{self}>")
    }
}

struct Benim(i32); // YEREL tip

impl Display for Benim { // yabancı trait + yerel tip → izinli
    fn fmt(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        write!(f, "Benim#{}", self.0)
    }
}

impl From<Benim> for String { // covered impl: Benim yerel ve kapsanmış
    fn from(b: Benim) -> String {
        format!("String::from(Benim({}))", b.0)
    }
}

fn main() {
    let b = Benim(7);
    println!("orphan (yabancı trait + yerel tip): {b}");
    println!("orphan: blanket + yerel tip: {}", b.etiket());
    let s: String = Benim(9).into();
    println!("covered impl (From<Benim> for String): {s}");
}
```

## Sık yapılan hatalar

| Kod | Hata | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| Blanket varken `impl Etiketle for i32` | **E0119** | `i32: Display` olduğu için blanket zaten bu impl'i veriyor; çakışır. | [Reference — Orphan rules](https://doc.rust-lang.org/reference/items/implementations.html#orphan-rules) |
| `impl Display for Vec<i32>` | **E0117** | Trait de tip de yabancı; newtype ile sar (`struct Sarmal(Vec<i32>)`). | [Reference — Orphan rules](https://doc.rust-lang.org/reference/items/implementations.html#orphan-rules) |
| `impl From<i32> for String` | **E0117** | Yerel tür yok; `From<Benim>` gibi kendi türünü parametreye koy. | [Reference — Orphan rules](https://doc.rust-lang.org/reference/items/implementations.html#orphan-rules) |
| `impl<T> Display for Benim<T>` içinde yerel türü kapsamayan düzen | **E0117** | İlk yerel `Ti`'den önce generic gelmemeli; covered koşulu bozulur. | [Reference — Orphan rules](https://doc.rust-lang.org/reference/items/implementations.html#orphan-rules) |

## Derleyici perspektifi

- Coherence kontrolü, her `(tip, trait)` çifti için en fazla bir impl olduğunu ayrı derleme modelinde de garanti eder; olmasaydı aynı kod iki crate'in impl'i arasında seçim yapamazdı.
  ↳ Kaynak: [Reference — Trait implementations](https://doc.rust-lang.org/reference/items/traits.html) · [Rustdoc — std](https://doc.rust-lang.org/std/)

- Orphan rule denetimi `impl Trait for Tip` yazımında trait ya da tipin yerel olup olmadığına bakar; ihlal **E0117** üretir. Fundamental tipler (`&`, `&mut`, `Box`) bu kontrol öncesi kaldırılır.
  ↳ Kaynak: [Reference — Orphan rules](https://doc.rust-lang.org/reference/items/implementations.html#orphan-rules) · [rustc 1.99.1 — kaynak ağacı](https://github.com/rust-lang/rust/tree/1.99.1)

- Covered impl denetimi, generic parametrelerin "uncovered" olup olmadığını inceler; `From<Benim> for String` geçer, `From<i32> for String` geçersizdir. Bu sayede upstream'in blanket eklemesi downstream'i bozmadan yeni impl'ler yazılabilir.
  ↳ Kaynak: [Reference — Orphan rules](https://doc.rust-lang.org/reference/items/implementations.html#orphan-rules) · [Rustdoc — From](https://doc.rust-lang.org/std/convert/trait.From.html)

- Çakışan impl'ler **E0119** ile reddedilir; blanket + özel impl bir arada tutulamaz. Tüm bu denetimler derleme anında yapılır.
  ↳ Kaynak: [Reference — Trait implementations](https://doc.rust-lang.org/reference/items/traits.html) · [rustc 1.99.1 — kaynak ağacı](https://github.com/rust-lang/rust/tree/1.99.1)

> **Kaynak notu:** RfR Böl. 2 ("Coherence and the Orphan Rule"; Types → Traits and Trait Bounds); başlık yayıncının ayrıntılı içindekiler listesiyle doğrulandı. Bu bölümdeki E0117/E0119 reproları ve covered impl'ın derlenmesi kaynak crate'de doğrulandı.
> ↳ Kaynak: [Reference — Orphan rules](https://doc.rust-lang.org/reference/items/implementations.html#orphan-rules) · [Rustdoc — std](https://doc.rust-lang.org/std/)

## Özet ve sonraki adım

- Her `(tür, trait)` çifti için en fazla bir impl vardır; aksi hâlde E0119.
- trait ya da tip yerel olmalı; ikisi de yabancıysa E0117, çözüm newtype.
- Covered impl ve fundamental tipler dar istisnalardır; blanket eklemek kırıcı değişikliktir.

Sıradaki bölüm: [24. Deref ve Metot Çözümü](24-deref-metot.md).
