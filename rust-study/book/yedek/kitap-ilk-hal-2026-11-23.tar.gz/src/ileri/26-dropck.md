# 26. Silme Kontrolü (Drop Check)

> Kaynak crate: `learn/advanced-concepts/ileri-dropck` · Çalıştır: `cargo run -p ileri-dropck`
> Kaynak gösterimi kuralı: [Kaynak gösterimi](../kaynaklar.md)

## Neden bu bölüm?

Bir defteri çöpe atarken içine son bir not yazman gerekiyorsa, o notu yazmak için kullandığın kitabın hâlâ masada durması gerekir. Rust'ta silme kodu (`Drop`) tam olarak böyle bir "son not" yazabilir. Bu bölümde derleyicinin o son erişimi nasıl hesaba kattığını ve `PhantomData`'nın bu hesapta gerçekten ne işe yaradığını görüyoruz.

## 5 yaşındaki çocuğa anlatır gibi

Çöpe atmadan önce defterine son bir not yazacaksın. O notu yazmak için masadaki kitaba bakman gerekiyor. Demek ki kitap, defter çöpe atılmadan önce orada durmalı. Kitabı çok erken kaldırırsan yazacak yerin kalmaz.

## Konu anlatımı (madde madde)

1. **Drop check (dropck), borrow checker'ın silme anını da denetleyen parçasıdır.** Soru şudur: bir değer düşerken, ödünç aldığı veriye hâlâ erişebilir mi? Erişebiliyorsa ödünç alınan veri o değeri aşmak zorundadır; yoksa `drop()` sarkan bir referansı okur (*Rust for Rustaceans*, Böl. 9 — The Drop Check).
   ↳ Kaynak: [Nomicon — Drop Check](https://doc.rust-lang.org/nomicon/dropck.html) · [Reference — Destructors](https://doc.rust-lang.org/reference/destructors.html)

2. **`Drop` yazmak ödüncü uzatır; `Drop` yoksa NLL son kullanımda bitirir.** `Denetci<'a>(&'a u8)` içinde `drop()` referansı okuduğu için borrow, değerin düşme anına kadar sürer. Aynı türde `Drop` impl'i olmasaydı derleyici "düşerken dokunulmayacak" bilirdi ve ödünç son kullanımda biterdi.
   ↳ Kaynak: [Book ch15-03 — Drop](https://doc.rust-lang.org/book/ch15-03-drop.html) · [rustc 1.99.1 — nll.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/nll.rs)

3. **Düşme sırası ters tanım sırasıdır ve bu yüzden E0597 çıkar.** `let gun; let denetci = Denetci(&gun);` düzeninde `denetci` önce düşer, `gun` hâlâ durur (geçerli). Ters sırayla `let denetci; let gun = 5u8; denetci = Denetci(&gun);` yazılırsa `gun` önce silinir, `denetci.drop()` onu okumaya kalkar: **E0597** — "`gun` does not live long enough ... borrow might be used here, when `denetci` is dropped and runs the Drop code".
   ↳ Kaynak: [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs) · [Nomicon — Drop Check](https://doc.rust-lang.org/nomicon/dropck.html)

4. **`PhantomData<T>` yer kaplamayan bir işaretçidir, veri tutmaz.** Yine de derleyiciye "sanki bir T varmış" dedirttiği için variance, auto-trait (Send/Sync) ve dropck hesaplarında dikkate alınır; kullanılmayan generic parametre sorununu da çözer.
   ↳ Kaynak: [Rustdoc — PhantomData](https://doc.rust-lang.org/std/marker/struct.PhantomData.html) · [rustc 1.99.1 — marker.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/marker.rs)

5. **Hangi `PhantomData` yazıldığı anlamı belirler.** `PhantomData<T>` "T'ye sahibim" der ve dropck `T::drop`'u çağırdığını varsayar; `PhantomData<&'a T>` ödünç ilişkisi kurar (`'a` covariant, dropck T'yi okumaz); `PhantomData<*const T>` !Send + !Sync işaretçisi gibi davranır; `PhantomData<fn() -> T>` ise T'de covarianttır ama sahiplenmez.
   ↳ Kaynak: [Rustdoc — PhantomData](https://doc.rust-lang.org/std/marker/struct.PhantomData.html) · [Nomicon — Subtyping and Variance](https://doc.rust-lang.org/nomicon/subtyping.html)

6. **RFC 1238 kuralı: `Drop` impl'i olan bir tipin tüm generic parametreleri zaten canlı sayılır.** Bu yüzden `*mut T` tutan bir tipte `PhantomData<T>` eklemek dropck açısından gereksizdir; PhantomData'nın buradaki etkisi variance ve auto-trait hesabıdır.
   ↳ Kaynak: [Nomicon — Drop Check](https://doc.rust-lang.org/nomicon/dropck.html) · [Reference — Destructors](https://doc.rust-lang.org/reference/destructors.html)

7. **E0597 için gerçek bir ödünç taşınması gerekir; `PhantomData<T>` tek başına yeterli değildir.** Kaynak koddaki doğrulanmış örnek: `struct K<T>(T); impl<T> Drop for K<T> { fn drop(&mut self) {} }` ve `let k; let x = 5u8; k = K(&x);` — burada `T = &u8`, yani `k` gerçekten `x`'ten ödünç alır ve `x`'ten sonra düştüğü için **E0597** çıkar.
   ↳ Kaynak: [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs) · [Nomicon — Drop Check](https://doc.rust-lang.org/nomicon/dropck.html)

8. **PhantomData'nın bağımsız dropck etkisi dar bir alandadır.** Yalnızca `Drop` impl'i olmayan (ama drop glue'ı olan) tiplerde ve `#[may_dangle]` ile görünür; `Drop` yazılmış tipte RFC 1238 zaten parametreleri canlı sayar.
   ↳ Kaynak: [Nomicon — Drop Check](https://doc.rust-lang.org/nomicon/dropck.html) · [rustc 1.99.1 — elaborate_drops.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_transform/src/elaborate_drops.rs)

9. **`#[may_dangle]` ters yöne gider: kuralı gevşetir.** Kendi `Box<T>`/`Box<&mut T>` türünü yazıp `Drop`'un T'ye düşürmek dışında dokunmadığını garanti edersen `unsafe impl<#[may_dangle] T> Drop for KendiBox<T>` yazılabilir; bu söz ödüncün değerden önce bitmesini sağlar. Yanlış söz use-after-free demektir; unstable (`dropck_eyepatch`, nightly) olduğu için kaynak crate'de yalnızca anlatıldı, derlenmedi; std'de `Vec`/`Box` bunu `PhantomData<T>` ile birlikte kullanır (*Rust for Rustaceans*, Böl. 9).
   ↳ Kaynak: [Nomicon — Drop Check](https://doc.rust-lang.org/nomicon/dropck.html) · [rustc 1.99.1 — boxed.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/alloc/src/boxed.rs)

## Kodda nasıl görünür?

```rust
use std::marker::PhantomData;
use std::mem::size_of;

struct Denetci<'a>(&'a u8);
impl<'a> Drop for Denetci<'a> {
    fn drop(&mut self) {
        println!("  Denetci düşerken okuyor: {}", self.0);
    }
}

fn dropck_temel() {
    let gun = 5u8;               // önce bildirildi → EN SON düşer
    let denetci = Denetci(&gun);  // sonra bildirildi → ÖNCE düşer
    println!("dropck: değer = {}", denetci.0);
    // Ters sıra DERLENMEZ (E0597): denetci önce bildirilir, gun sonra;
    // denetci düşerken gun çoktan silinmiş olurdu.
}

struct Belirtec<T> {
    id: u32,
    _sahip: PhantomData<T>,       // "mantıken bir T'ye sahibim" — bellekte T YOK
}

fn phantomdata_zst() {
    let b: Belirtec<String> = Belirtec { id: 7, _sahip: PhantomData };
    println!("PhantomData ZST: Belirtec.id = {}", b.id);
    println!(
        "  size_of::<Belirtec<String>>() = {} (== u32 = {})",
        size_of::<Belirtec<String>>(),
        size_of::<u32>()
    );

    // E0597 için gerçek ödünç gerekir (RFC 1238: Drop'lı tipte T zaten canlı):
    //     struct K<T>(T); impl<T> Drop for K<T> { fn drop(&mut self) {} }
    //     let k; let x = 5u8; k = K(&x); // k, x'ten sonra düşer → E0597
}
```

## Sık yapılan hatalar

| Kod / durum | Hata | Neden / çözüm | Kaynak |
| --- | --- | --- | --- |
| `let d; let x = 5u8; d = Denetci(&x);` (`Drop` var) | **E0597** | `x` önce düşer, `d.drop()` ona bakar; ödünç alanı önce bildir ya da sahipliği ver. | [rustc 1.99.1 — borrowck_errors.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/borrowck_errors.rs) |
| `struct K<T>(T)` ile `k = K(&x)` (`Drop` var) | **E0597** | Burada `T = &u8`: gerçek ödünç var; `k` x'ten sonra düştüğü için yazılmaz. | [Nomicon — Drop Check](https://doc.rust-lang.org/nomicon/dropck.html) |
| `*mut T` alan tipe `PhantomData<T>` ekleyip dropck'i düzeltmeye çalışmak | gereksiz | RFC 1238: `Drop` impl'i olan tipte tüm generic parametreler zaten canlı; PhantomData'yı variance/Send-Sync için kullan. | [Nomicon — Drop Check](https://doc.rust-lang.org/nomicon/dropck.html) |
| `#[may_dangle]`'ı kararlı Rust'ta kullanmak | derleme hatası | `dropck_eyepatch` unstable/nightly; yanlış söz use-after-free riski. | [Nomicon — Drop Check](https://doc.rust-lang.org/nomicon/dropck.html) |

## Derleyici perspektifi

- Drop check borrowck'ın parçasıdır: `Drop` uygulayan ve ödünç aldığı lifetime'ı `drop()` içinde kullanabilen tipte, ödünç verilen veri o değeri aşmak zorundadır (*Rust for Rustaceans*, Böl. 9 — The Drop Check).
  ↳ Kaynak: [Nomicon — Drop Check](https://doc.rust-lang.org/nomicon/dropck.html) · [Reference — Destructors](https://doc.rust-lang.org/reference/destructors.html)

- `Drop` olmadığında borrow son kullanımda biter (NLL); `Drop` olduğunda `drop()` gövdesi referansı kullanabildiğinden borrow düşme çağrısına uzatılır. İzin verilseydi bu use-after-free olurdu.
  ↳ Kaynak: [rustc 1.99.1 — nll.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_borrowck/src/nll.rs) · [rustc 1.99.1 — elaborate_drops.rs](https://github.com/rust-lang/rust/blob/1.99.1/compiler/rustc_mir_transform/src/elaborate_drops.rs)

- `PhantomData<T>` ZST bir işarettir; dropck açısından belirleyici olan `Drop` impl'inin varlığıdır (RFC 1238: parametreler canlı sayılır). Bağımsız etki yalnızca `Drop`'suz tiplerde ve `#[may_dangle]` ile ortaya çıkar; std'de `Vec`/`Box` ikisini birlikte kullanır.
  ↳ Kaynak: [rustc 1.99.1 — marker.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/marker.rs) · [rustc 1.99.1 — boxed.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/alloc/src/boxed.rs)

- `#[may_dangle]` unstable `dropck_eyepatch` özelliğidir: "bu T'ye düşürmek dışında erişmeyeceğim" sözünü verir; yanlış söz use-after-free'dir, bu yüzden kaynak crate'de yalnız anlatılmış, derlenmemiştir.
  ↳ Kaynak: [Nomicon — Drop Check](https://doc.rust-lang.org/nomicon/dropck.html) · [rustc 1.99.1 — drop.rs](https://github.com/rust-lang/rust/blob/1.99.1/library/core/src/ops/drop.rs)

## Özet ve sonraki adım

- `Drop` yazmak ödüncü silme anına kadar uzatır; ters düşme sırası **E0597** üretir.
- RFC 1238 gereği `Drop`'lu tipte tüm generic parametreler canlıdır; `PhantomData` burada variance ve auto-trait aracıdır, tek başına E0597 tetiklemez.
- `#[may_dangle]` kuralı gevşeten unsafe ve nightly bir sözdir; std onu `PhantomData<T>` ile birlikte kullanır.

Sıradaki bölüm: [27. İleri Lifetime, HRTB ve GAT](27-lifetime-hrtb-gat.md).
