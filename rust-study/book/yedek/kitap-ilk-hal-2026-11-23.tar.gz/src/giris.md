# Kitabı nasıl kullanmalı?

## Her sayfanın düzeni

Bir bölüm sayfası şu bölümlerden oluşur:

| Bölüm | Ne işe yarar? |
| --- | --- |
| **Neden bu bölüm?** | Konunun hayattaki karşılığı; neden öğrenmeye değer. |
| **5 yaşındaki çocuğa anlatır gibi** | Benzetime dayalı, teknik terimsiz giriş. |
| **Konu anlatımı (madde madde)** | Asıl içerik. Her maddenin altında kaynak linki. |
| **Kodda nasıl görünür?** | Derlenmiş, çalışan örnek. |
| **Sık yapılan hatalar** | ✗ yanlış / ✓ doğru karşılaştırmaları, hata kodları. |
| **Derleyici perspektifi** | rustc'nin konuyu hangi aşamada nasıl uyguladığı. İlk okuyuşta atlanabilir. |
| **Özet ve sonraki adım** | Birkaç maddelik tekrar ve sıradaki bölüme köprü. |

## Kaynak satırlarını okumak

Bir maddeyi okuduktan sonra altındaki `↳ Kaynak:` satırına bakın:

```
1. Her değerin tek bir sahibi (owner) vardır. ...
   ↳ Kaynak: [Book ch04-01](https://doc.rust-lang.org/book/ch04-01-what-is-ownership.html)
```

- Köşeli parantez içindeki metin kaynağın kısa adıdır.
- Link sizi doğrudan ilgili belgeye götürür.
- Derleyici kaynaklarında sürüm etiketi (ör. `1.99.1`) ve satır aralığı (`#L917-L922`) bulunur.

Birden fazla kaynak varsa `·` ile ayrılır. Kısaltma tablosu: [Kaynak gösterimi](kaynaklar.md).

## Okuma yolları

**İlk kez öğreniyorsanız:** Sadece "5 yaşındaki çocuğa anlatır gibi" ve "Konu anlatımı" bölümlerini okuyun. Derleyici perspektifini sonra ekleyin.

**Bir hatayı çözmeye çalışıyorsanız:** "Sık yapılan hatalar" bölümünden başlayın; hata kodu (ör. E0382) arayın.

**Mekanizmayı anlamak istiyorsanız:** Derinleşme sayfalarını ve derleyici perspektifini okuyun; kaynak linklerini takip edin.

## Pratik

Her bölüm karşılık geldiği crate'e referans verir. Kodu çalıştırmak için depo kökünde:

```bash
cargo run -p ownership       # ana örnek
cargo test -p ownership      # doğrulama testleri
```

Derinleşme sayfaları aynı crate'in `src/derinlesme.rs` modülünü anlatır; `cargo run -p <crate>` hem ana hem derinleşme bölümünü çalıştırır.
